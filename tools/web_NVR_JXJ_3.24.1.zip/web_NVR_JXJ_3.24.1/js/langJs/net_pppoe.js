function changeTheLanguage(type){
	setLanguage(type);
	if(type==0){//英文
		$s("pppoe").innerHTML="PPPOE Setting";
		$s("pppoeOpen").innerHTML="Enable PPPOE";
		$s("pppoeUser").innerHTML="User Name";
		$s("pppoePwd").innerHTML="Password";
		$s("pppoeNetInterface").innerHTML="Enable";
		
		var netInterface=document.getElementById("pppoe_netInterface");
		netInterface.options[0].text="Ethernet";
		netInterface.options[1].text="WIFI";

		$s("savesumbit").value="Save";
	}else if(type==1){//中文
		$s("pppoe").innerHTML="PPPOE服务";
		$s("pppoeOpen").innerHTML="启用PPPOE";
		$s("pppoeUser").innerHTML="账号";
		$s("pppoePwd").innerHTML="密码";
		$s("pppoeNetInterface").innerHTML="拨号网络接口";
		
		var netInterface=document.getElementById("pppoe_netInterface");
		netInterface.options[0].text="有线";
		netInterface.options[1].text="无线";

		$s("savesumbit").value="保存";
	}else if(type==2){//韩文
		$s("pppoe").innerHTML="PPPOE 설정";
		$s("pppoeOpen").innerHTML="사용";
		$s("pppoeUser").innerHTML="사용자명";
		$s("pppoePwd").innerHTML="비밀번호";
		$s("pppoeNetInterface").innerHTML="사용";
		
		var netInterface=document.getElementById("pppoe_netInterface");
		netInterface.options[0].text="유선";
		netInterface.options[1].text="WIFI";

		$s("savesumbit").value="저장";

	}
}