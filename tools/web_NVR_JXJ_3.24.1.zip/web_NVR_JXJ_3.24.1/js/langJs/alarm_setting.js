function changeTheLanguage(type){
	setLanguage(type);
	if(type==0){//英文
		$s("alarm").innerHTML="Alarm Param";
		$s("inputChn").innerHTML="Channel";
		$s("paramChnNum").innerHTML="Channel Number";
		$s("alarmType").innerHTML="Alarm Type";

		$s("alarmEnabled").innerHTML="Enable Alarm";
		$s("detectInterval").innerHTML="Interval(s)";
		$s("labelTime").innerHTML="";
		$s("sensitivity").innerHTML="Sensitivity";

		$s("deploymentTime").innerHTML="Deploy Time";
		$s("tdTime1").innerHTML="Section 1";
		$s("tdTime2").innerHTML="Section 2";
		$s("tdFulltime").innerHTML="Full-time";
		
		$s("tdEveryday").innerHTML="Everyday";
		$s("tdSun").innerHTML="Sunday";
		$s("tdMon").innerHTML="Monday";
		$s("tdTue").innerHTML="Tuesday";
		$s("tdWed").innerHTML="Wednesday";
		$s("tdThu").innerHTML="Thursday";
		$s("tdFri").innerHTML="Friday";
		$s("tdSat").innerHTML="Saturday";
		$s("gotoLinkage").innerHTML = "Alarm Trigger";

		$s("ioTypeTd").innerHTML="Probe Type";
		var ioType=$s("ioType");
		ioType.options[0].text="Closed";
		ioType.options[1].text="Open";

		var alarmTypeSel=$s("alarm_type");
		alarmTypeSel.options[0].text="Motion Detection";
		alarmTypeSel.options[1].text="Lost Alarm";
		alarmTypeSel.options[2].text="Privacy Zone Alarm Setting";
		alarmTypeSel.options[3].text="Probe Detection";
		alarmTypeSel.options[4].text="PIR Alarm";
		alarmTypeSel.style.width = "182px";

		$s("btn_setmask").value="Set Zone";
		$s("savesumbit").value="Save";
	}else if(type==1){//中文
		$s("alarm").innerHTML="报警参数";
		$s("inputChn").innerHTML="输入通道";
		$s("paramChnNum").innerHTML="通道号";
		$s("alarmType").innerHTML="报警类型";

		$s("alarmEnabled").innerHTML="启用报警";
		$s("detectInterval").innerHTML="侦测间隔时间";
		$s("labelTime").innerHTML="秒";
		$s("sensitivity").innerHTML="灵敏度";

		$s("deploymentTime").innerHTML="布防时间";
		$s("tdTime1").innerHTML="布防时间段1";
		$s("tdTime2").innerHTML="布防时间段2";
		$s("tdFulltime").innerHTML="全天布防";
		
		$s("tdEveryday").innerHTML="每&nbsp;&nbsp;&nbsp;天";
		$s("tdSun").innerHTML="星期天";
		$s("tdMon").innerHTML="星期一";
		$s("tdTue").innerHTML="星期二";
		$s("tdWed").innerHTML="星期三";
		$s("tdThu").innerHTML="星期四";
		$s("tdFri").innerHTML="星期五";
		$s("tdSat").innerHTML="星期六";
		$s("gotoLinkage").innerHTML = "联动设置";

		$s("ioTypeTd").innerHTML="IO类型";
		var ioType=$s("ioType");
		ioType.options[0].text="常闭";
		ioType.options[1].text="常开";

		var alarmTypeSel=$s("alarm_type");
		alarmTypeSel.options[0].text="移动侦测报警";
		alarmTypeSel.options[1].text="视频丢失报警";
		alarmTypeSel.options[2].text="遮挡报警";
		alarmTypeSel.options[3].text="IO报警";
		alarmTypeSel.options[4].text="人体检测报警";

		$s("btn_setmask").value="报警区域设置";
		$s("savesumbit").value="保存";
	}else if(type==2){//韩文
		$s("alarm").innerHTML="알람 설정값";
		$s("inputChn").innerHTML="입력채널";
		$s("paramChnNum").innerHTML="채널 번호";
		$s("alarmType").innerHTML="알람종류";

		$s("alarmEnabled").innerHTML="알람사용가능";
		$s("detectInterval").innerHTML="감지시간간격";
		$s("labelTime").innerHTML="초";
		$s("sensitivity").innerHTML="민감도";

		$s("deploymentTime").innerHTML="알람배치시간";
		$s("tdTime1").innerHTML="영역1";
		$s("tdTime2").innerHTML="영역2";
		$s("tdFulltime").innerHTML="종일";
		
		$s("tdEveryday").innerHTML="매일";
		$s("tdSun").innerHTML="일요일";
		$s("tdMon").innerHTML="월요일";
		$s("tdTue").innerHTML="화요일";
		$s("tdWed").innerHTML="수요일";
		$s("tdThu").innerHTML="목요일";
		$s("tdFri").innerHTML="금요일";
		$s("tdSat").innerHTML="토요일";
		$s("gotoLinkage").innerHTML = "알람설정";

		$s("ioTypeTd").innerHTML="IO종류";
		var ioType=$s("ioType");
		ioType.options[0].text="N/C";
		ioType.options[1].text="N/O";

		var alarmTypeSel=$s("alarm_type");
		alarmTypeSel.options[0].text="모션감지 알람";
		alarmTypeSel.options[1].text="영상신호손실 알람";
		alarmTypeSel.options[2].text="비디오차단 알람";
		alarmTypeSel.options[3].text="IO 알람";
		alarmTypeSel.options[4].text="인체 검출 신고";

		$s("btn_setmask").value="알람지역 설정";
		$s("savesumbit").value="저장";
	}
}
