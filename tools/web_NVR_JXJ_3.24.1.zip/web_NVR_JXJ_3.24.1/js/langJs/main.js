function changeTheLanguage(type){
	setLanguage(type);
	setSelectParamToEn(type);
	if(type==0){//英文
		try{
			window.document.title="network video camera";
			$s("preview").style.width="55px";
			$s("set").style.width="55px";
			$s("about").style.width="55px";
			$s("topName1").innerHTML="Video";
			$s("topName2").innerHTML="Setting";
			$s("topName3").innerHTML="About";
			
			//云台
			$s("ptzCtl").src="images/web_18_en.jpg";
			$s("ptzUp").title="Up";
			$s("ptzLeft").title="Left";
			$s("ptzAuto").title="Auto";
			$s("ptzRight").title="Right";
			$s("ptzDown").title="Down";
			$s("thumbdIi15vNI1m6G").title="PTZ Speed";

			//镜头
			$s("adjustDiv").style.paddingLeft="45px";
			$s("adjustmentspac").innerHTML="Zoom";
			$s("adjustmentspac").style.width="58px";
			$s("adjustmentspac2").innerHTML="Focus";
			$s("adjustmentspac2").style.width="58px";
			$s("adjustmentspac3").innerHTML="Iris";
			$s("adjustmentspac3").style.width="58px";
			$s("Presetspac").innerHTML="Preset";
			
			//预置号
			$s("button1").value="Call";
			$s("button2").value="Set";
			$s("button3").value="Delete";

			//菜单
			$s("menu0").innerHTML="Local Config";
			$s("menuDevice").innerHTML="Device Config";
			//$s("menu1Span").innerHTML="Audio Setting";
			$s("menu2Span").innerHTML="Video Setting";
			$s("sub2-1Span").innerHTML="Encoding";
			$s("sub2-2Span").innerHTML="OSD Setting";
			$s("sub2-3Span").innerHTML="Privacy Zone";
			$s("sub2-4Span").innerHTML="Image";
			$s("sub2-5Span").innerHTML="Interest Area";
			$s("menu3Span").innerHTML="Network Setting";
			$s("sub3-1Span").innerHTML="IP Setting";
			//$s("sub3-2Span").innerHTML="Port Setting";
			$s("sub3-3Span").innerHTML="PPPOE Setting";
			$s("sub3-4Span").innerHTML="FTP Setting";
			$s("sub3-5Span").innerHTML="E-MAIL Setting";
			$s("sub3-6Span").innerHTML="DDNS Setting";
			$s("sub3-7Span").innerHTML="UPNP Setting";
			$s("sub3-8Span").innerHTML="Wifi Setting";
			$s("sub3-9Span").innerHTML="3G Setting";
			$s("sub3-10Span").innerHTML="Platform Setting";
			$s("sub3-11Span").innerHTML="ZSYH Platform";
			$s("sub3-12Span").innerHTML="HXHT Platform";
			//$s("sub3-13Span").innerHTML="GB28181";
			$s("sub3-14Span").innerHTML="HW Platform";
			$s("menu8Span").innerHTML="Record Setting";
			$s("sub8-1Span").innerHTML="SD Card Setting";
			$s("sub8-2Span").innerHTML="Record Plan";
			$s("sub8-3Span").innerHTML="Network Disk";
			$s("menu4Span").innerHTML="Alarm Setting";
			$s("sub4-1Span").innerHTML="Alarm Param";
			$s("sub4-2Span").innerHTML="Alarm Linkage";
			$s("menu5Span").innerHTML="Serial Setting";
			$s("sub5-1Span").innerHTML="Port Setting";
			$s("sub5-2Span").innerHTML="PTZ Setting";
			$s("menu6Span").innerHTML="System Setting";
			$s("sub6-1Span").innerHTML="System Setting";
			$s("sub6-2Span").innerHTML="Time Setting";
			$s("sub6-3Span").innerHTML="User Manage";
			$s("sub6-4Span").innerHTML="Device Upgrade";
			$s("sub6-5Span").innerHTML="Channel Setting";
			$s("menu7Span").innerHTML="Intelligent Analysis";
			$s("sub7-1Span").innerHTML="Video Analysis";

			//preview.asp
			$w("td1").innerHTML="Record";
			$w("td2").innerHTML="Audio";
			$w("td3").innerHTML="Talk";
			$w("td4").innerHTML="Capture";
			$w("td5").innerHTML="Alarm";
			$w("td6").innerHTML="Playback";
			$w("td7").innerHTML="Full Screen";

		}catch(e){
			window.status = "Loading failure!";
		}
	}else if(type==1){//中文
		try{
			window.document.title="网络视频摄像机";
			$s("topName1").innerHTML="实时预览";
			$s("topName2").innerHTML="参数设置";
			$s("topName3").innerHTML="关于";
			
			//云台
			$s("ptzUp").title="上";
			$s("ptzLeft").title="左";
			$s("ptzAuto").title="自动";
			$s("ptzRight").title="右";
			$s("ptzDown").title="下";
			$s("thumbdIi15vNI1m6G").title="云台速度";

			//镜头
			$s("adjustmentspac").innerHTML="变倍";
			$s("adjustmentspac2").innerHTML="聚焦";
			$s("adjustmentspac3").innerHTML="光圈";
			$s("Presetspac").innerHTML="预置号";
			
			//预置号
			$s("button1").value="调用";
			$s("button2").value="设置";
			$s("button3").value="删除";

			//菜单
			$s("menu0").innerHTML="本地配置";
			$s("menuDevice").innerHTML="设备配置";
			//$s("menu1Span").innerHTML="音频属性";
			$s("menu2Span").innerHTML="视频设置";
			$s("sub2-1Span").innerHTML="音视频参数";
			$s("sub2-2Span").innerHTML="字幕";
			$s("sub2-3Span").innerHTML="视频遮挡";
			$s("sub2-4Span").innerHTML="图像参数";
			$s("sub2-5Span").innerHTML="感兴趣区域";
			$s("menu3Span").innerHTML="网络配置";
			$s("sub3-1Span").innerHTML="网络设备";
			//$s("sub3-2Span").innerHTML="端口配置";
			$s("sub3-3Span").innerHTML="PPPOE服务";
			$s("sub3-4Span").innerHTML="FTP服务";
			$s("sub3-5Span").innerHTML="EMAIL服务";
			$s("sub3-6Span").innerHTML="DDNS服务";
			$s("sub3-7Span").innerHTML="UPNP服务";
			$s("sub3-8Span").innerHTML="无线网卡服务";
			$s("sub3-9Span").innerHTML="3G服务";
			$s("sub3-10Span").innerHTML="平台配置";
			$s("sub3-11Span").innerHTML="中盛益华平台";
			$s("sub3-12Span").innerHTML="互信互通平台";
			//$s("sub3-13Span").innerHTML="GB28181";
			$s("sub3-14Span").innerHTML="华为平台";
			$s("menu8Span").innerHTML="存储配置";
			$s("sub8-1Span").innerHTML="存储磁盘";
			$s("sub8-2Span").innerHTML="存储策略";
			$s("sub8-3Span").innerHTML="网络磁盘";
			$s("menu4Span").innerHTML="报警配置";
			$s("sub4-1Span").innerHTML="报警参数";
			$s("sub4-2Span").innerHTML="报警联动";
			$s("menu5Span").innerHTML="串口配置";
			$s("sub5-1Span").innerHTML="串口设置";
			$s("sub5-2Span").innerHTML="云台设置";
			$s("menu6Span").innerHTML="系统参数";
			$s("sub6-1Span").innerHTML="系统信息";
			$s("sub6-2Span").innerHTML="系统时间";
			$s("sub6-3Span").innerHTML="用户管理";
			$s("sub6-4Span").innerHTML="维护&升级";
			$s("sub6-5Span").innerHTML="通道配置";
			$s("menu7Span").innerHTML="智能分析";
			$s("sub7-1Span").innerHTML="视频诊断";

			//preview.asp
			$w("td1").innerHTML="录像";
			$w("td2").innerHTML="监听";
			$w("td3").innerHTML="对讲";
			$w("td4").innerHTML="抓拍";
			$w("td5").innerHTML="报警";
			$w("td6").innerHTML="回放";
			$w("td7").innerHTML="全屏";

		}catch(e){
			window.status = "加载失败!";
		}
	}else if(type==2){//韩文
		try{
			window.document.title="네트워크 비디오 카메라";
			$s("preview").style.width="55px";
			$s("set").style.width="55px";
			$s("about").style.width="65px";
			$s("topName1").innerHTML="라이브";
			$s("topName2").innerHTML="설정";
			$s("topName3").innerHTML="버전 정보";
		
			//云台
			$s("ptzCtl").src="images/web_18_en.jpg";
			$s("ptzUp").title="상";
			$s("ptzLeft").title="좌";
			$s("ptzAuto").title="자동";
			$s("ptzRight").title="우";
			$s("ptzDown").title="하";
			document.getElementsByName("thumbdIi15vNI1m6G")[0].title="PTZ Speed";

			//镜头
			$s("adjustmentspac").innerHTML="Zoom";
			$s("adjustmentspac2").innerHTML="Focus";
			$s("adjustmentspac3").innerHTML="Iris";
			$s("Presetspac").innerHTML="Preset";
			
			//预置号
			$s("button1").value="Call";
			$s("button2").value="Set";
			$s("button3").value="Delete";

			//菜单
			$s("menu0").innerHTML="로컬 설정";
			$s("menuDevice").innerHTML="장비 설정";
			//$s("menu1Span").innerHTML="음성 설정";
			$s("menu2Span").innerHTML="비디오 설정";
			$s("sub2-1Span").innerHTML="영상음성 설정값";
			$s("sub2-2Span").innerHTML="OSD";
			$s("sub2-3Span").innerHTML="프라이버시 영역";
			$s("sub2-4Span").innerHTML="이미지";
			$s("sub2-5Span").innerHTML="관심지역";
			$s("menu3Span").innerHTML="네트워크 설정";
			$s("sub3-1Span").innerHTML="IP 설정";
			//$s("sub3-2Span").innerHTML="포트 설정";
			$s("sub3-3Span").innerHTML="PPPOE 설정";
			$s("sub3-4Span").innerHTML="FTP 설정";
			$s("sub3-5Span").innerHTML="이메일 설정";
			$s("sub3-6Span").innerHTML="DDNS 설정";
			$s("sub3-7Span").innerHTML="UPNP 설정";
			$s("sub3-8Span").innerHTML="wifi 세팅";
			$s("sub3-9Span").innerHTML="3G 세팅";
			$s("sub3-10Span").innerHTML="CMS설정";
			$s("sub3-11Span").innerHTML="ZSYH 설정";
			$s("sub3-12Span").innerHTML="HXHT 설정";
			//$s("sub3-13Span").innerHTML="GB28181";
			$s("sub3-14Span").innerHTML="HW 설정";
			$s("menu8Span").innerHTML="저장 설정";
			$s("sub8-1Span").innerHTML="SD 카드 설정";
			$s("sub8-2Span").innerHTML="자동 녹화";
			$s("sub8-3Span").innerHTML="네트워크 디스크";
			$s("menu4Span").innerHTML="알람 설정";
			$s("sub4-1Span").innerHTML="알람설정값";
			$s("sub4-2Span").innerHTML="알람연동";
			$s("menu5Span").innerHTML="시리얼 설정";
			$s("sub5-1Span").innerHTML="포트 설정";
			$s("sub5-2Span").innerHTML="PTZ 설정";
			$s("menu6Span").innerHTML="시스템 설정";
			$s("sub6-1Span").innerHTML="기본 정보";
			$s("sub6-2Span").innerHTML="시스템 시간";
			$s("sub6-3Span").innerHTML="사용자 계정";
			$s("sub6-4Span").innerHTML="업그레이드";
			$s("sub6-5Span").innerHTML="채널 설정";
			$s("menu7Span").innerHTML="스마트감지";
			$s("sub7-1Span").innerHTML="지능형감지";

			//preview.asp
			$w("td1").innerHTML="녹화";
			$w("td2").innerHTML="오디오";
			$w("td3").innerHTML="스피커";
			$w("td4").innerHTML="영상 캡쳐";
			$w("td5").innerHTML="알람";
			$w("td6").innerHTML="재생";
			$w("td7").innerHTML="전체화면";

		}catch(e){
			window.status = "Loading failure!";
		}
	}
	
	if($s("fastBallFlag").value=="1"){//高速球
		setHighSpeedBallEng(type);
	}
}

//高速球英文设置
function setHighSpeedBallEng(type){
//////////////////////////////////////////////////////////////20120113
	if(type==0){
		//高速球
		caretaker="Guard P";
		$s("baseBtn").value="Basic Control";
		$s("advancedBtn").value="Advanced Control";

		$s("szdsdzBtn").value="Timing Action Setting";
		$s("autoFlipSpan").innerHTML="Auto Flip";
		$s("autoZoomSpan").innerHTML="Auto Zoom";
		$s("autoIrisSpan").innerHTML="Auto Iris";
		$s("autoFocusSpan").innerHTML="Auto Focus";

		//扫描控制
		$s("smkz").innerHTML=" Scan Control ";
		var smkz=$s("smkzSelect");
		smkz.options[0].text="Cruise Scan";
		smkz.options[1].text="Auto Scan";
		smkz.options[2].text="AB Scan";
		$s("smkzType").innerHTML="Type";
		$s("smkzBtn1").value="Start";
		$s("smkzBtn2").value="Stop";
		$s("smkzBtn3").value="Setting";

		//闲置动作
		$s("xzdz").innerHTML=" Idle Action ";
		var xzdz=$s("xzdzSelect");
		xzdz.options[0].text="No Action";
		xzdz.options[1].text="Preset 1";
		xzdz.options[2].text="Preset 2";
		xzdz.options[3].text="Preset 3";
		xzdz.options[4].text="Preset 4";
		xzdz.options[5].text="Guard P";
		xzdz.options[6].text="Cruise Scan";
		xzdz.options[7].text="Auto Scan";
		xzdz.options[8].text="AB Scan";
		$s("xzdzBtn").value="Setting";

		//报警动作
		$s("bjdz").innerHTML=" Alarm Action ";
		var bjdz=$s("bjdzSelect");
		bjdz.options[0].text="No action";
		bjdz.options[1].text="Preset 1";
		bjdz.options[2].text="Preset 2";
		bjdz.options[3].text="Preset 3";
		bjdz.options[4].text="Preset 4";
		bjdz.options[5].text="Guard P";
		bjdz.options[6].text="Cruise Scan";
		bjdz.options[7].text="Auto Scan";
		bjdz.options[8].text="AB Scan";
		$s("bjdzBtn").value="Setting";

		//巡航组扫描属性
		$s("DivCruiseScan").innerHTML="Cruise Scan Setting";
		var divSecArray=document.getElementsByTagName("label");
		for(var i=0;i<divSecArray.length;i++){
			divSecArray[i].innerHTML="Sec";
		}
		$s("topPresetPoint").innerHTML="Preset";
		$s("topTime").innerHTML="Stay";
		$s("topSpeed").innerHTML="Speed";
		for(var i=1;i<=16;i++){
			$s("tdPresetPoint"+i).innerHTML="Preset_"+i;
		}
		var gsqDivBtn=document.getElementsByName("gsqDivBtn");
		for(var i=0;i<gsqDivBtn.length;i++){
			gsqDivBtn[i].value="Save";
		}

		//自动扫描属性
		$s("DivAutoScan").innerHTML="Auto Scan Setting";
		$s("tdAutoScanSpeed").innerHTML="Scan Speed:";
		$s("autoScanSpan").innerHTML="Save Current Position As Vertical";

		//AB亮点扫描属性
		$s("DivABpointScan").innerHTML="AB Scan Setting";
		$s("tdABpointScanSpeed").innerHTML="Scann speed:";
		$s("ABpointScanSpan").innerHTML="Save Current Position As Vertical";
		$s("leftLimit").value="Left Position";
		$s("rightLimit").value="Right Position";

		//闲置动作属性
		$s("DivFreeAction").innerHTML="Idle Action Setting";
		$s("tdFreeTime").innerHTML="Idle Time:";

		//报警动作属性
		$s("DivAlarmAction").innerHTML="Alarm Action Setting";
		$s("tdAlarmTime").innerHTML="Stay Time:";

		//设置定时动作
		$s("DivTimeAction").innerHTML="Timing Action Setting";
		$s("topBT").innerHTML="Start";
		$s("topET").innerHTML="End";
		$s("topAction").innerHTML="Action";
		$s("reSetTimeActionBtn").value="Reset";
		for(var i=1;i<=8;i++){
			var tempSelect=document.getElementById("actionSelect"+i);
			tempSelect.options[0].text="No action";
			tempSelect.options[1].text="Preset 1";
			tempSelect.options[2].text="Preset 2";
			tempSelect.options[3].text="Preset 3";
			tempSelect.options[4].text="Preset 4";
			tempSelect.options[5].text="Guard P";
			tempSelect.options[6].text="Cruise Scan";
			tempSelect.options[7].text="Auto Scan";
			tempSelect.options[8].text="AB Scan";
		}

	}else if(type==1){
		//高速球
		caretaker="看守位";
		$s("baseBtn").value="基本控制";
		$s("advancedBtn").value="高级控制";

		$s("szdsdzBtn").value="设置定时动作";
		$s("autoFlipSpan").innerHTML="自动翻转";
		$s("autoZoomSpan").innerHTML="自动变倍";
		$s("autoIrisSpan").innerHTML="自动光圈";
		$s("autoFocusSpan").innerHTML="自动聚焦";

		//扫描控制
		$s("smkz").innerHTML=" 扫描控制 ";
		var smkz=$s("smkzSelect");
		smkz.options[0].text="巡航组扫描";
		smkz.options[1].text="自动扫描";
		smkz.options[2].text="AB两点扫描";
		$s("smkzType").innerHTML="类型";
		$s("smkzBtn1").value="开始";
		$s("smkzBtn2").value="停止";
		$s("smkzBtn3").value="设置";

		//闲置动作
		$s("xzdz").innerHTML=" 闲置动作 ";
		var xzdz=$s("xzdzSelect");
		xzdz.options[0].text="无动作";
		xzdz.options[1].text="预置点1";
		xzdz.options[2].text="预置点2";
		xzdz.options[3].text="预置点3";
		xzdz.options[4].text="预置点4";
		xzdz.options[5].text="看守位";
		xzdz.options[6].text="巡航组扫描";
		xzdz.options[7].text="自动扫描";  
		xzdz.options[8].text="AB两点扫描";
		$s("xzdzBtn").value="设置";

		//报警动作
		$s("bjdz").innerHTML=" 报警动作 ";
		var bjdz=$s("bjdzSelect");
		bjdz.options[0].text="无动作";
		bjdz.options[1].text="预置点1";
		bjdz.options[2].text="预置点2";
		bjdz.options[3].text="预置点3";
		bjdz.options[4].text="预置点4";
		bjdz.options[5].text="看守位";
		bjdz.options[6].text="巡航组扫描";
		bjdz.options[7].text="自动扫描";
		bjdz.options[8].text="AB两点扫描";
		$s("bjdzBtn").value="设置";

		//巡航组扫描属性
		$s("DivCruiseScan").innerHTML="巡航组扫描属性";
		var divSecArray=document.getElementsByTagName("label");
		for(var i=0;i<divSecArray.length;i++){
			divSecArray[i].innerHTML="秒";
		}
		$s("topPresetPoint").innerHTML="预置点";
		$s("topTime").innerHTML="时长";
		$s("topSpeed").innerHTML="速度";
		for(var i=1;i<=16;i++){
			$s("tdPresetPoint"+i).innerHTML="预置点_"+i;
		}
		var gsqDivBtn=document.getElementsByName("gsqDivBtn");
		for(var i=0;i<gsqDivBtn.length;i++){
			gsqDivBtn[i].value="保存";
		}

		//自动扫描属性
		$s("DivAutoScan").innerHTML="自动扫描属性";
		$s("tdAutoScanSpeed").innerHTML="扫描速度:";
		$s("autoScanSpan").innerHTML="保存当前点为垂直位置";

		//AB亮点扫描属性
		$s("DivABpointScan").innerHTML="AB两点扫描属性";
		$s("tdABpointScanSpeed").innerHTML="扫描速度:";
		$s("ABpointScanSpan").innerHTML="保存当前点为垂直位置";
		$s("leftLimit").value="左限位";
		$s("rightLimit").value="右限位";

		//闲置动作属性
		$s("DivFreeAction").innerHTML="设置定时动作";
		$s("tdFreeTime").innerHTML="闲置时间:";

		//报警动作属性
		$s("DivAlarmAction").innerHTML="报警动作属性";
		$s("tdAlarmTime").innerHTML="持续时间:";

		//设置定时动作
		$s("DivTimeAction").innerHTML="设置定时动作";
		$s("topBT").innerHTML="开始时间";
		$s("topET").innerHTML="结束时间";
		$s("topAction").innerHTML="动作";
		$s("reSetTimeActionBtn").value="重置";
		for(var i=1;i<=8;i++){
			var tempSelect=document.getElementById("actionSelect"+i);
			tempSelect.options[0].text="无动作";    
			tempSelect.options[1].text="预置点1";   
			tempSelect.options[2].text="预置点2";   
			tempSelect.options[3].text="预置点3";   
			tempSelect.options[4].text="预置点4";   
			tempSelect.options[5].text="看守位";    
			tempSelect.options[6].text="巡航组扫描";
			tempSelect.options[7].text="自动扫描";  
			tempSelect.options[8].text="AB两点扫描";
		}

	}else{

	}

//////////////////////////////////////////////////////////////
}