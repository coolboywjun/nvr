function changeTheLanguage(type){
	setLanguage(type);
	if(type==0){//英文
		$s("aenc").innerHTML="Audio Setting";
		$s("aencChn").innerHTML="Channel";
		$s("aencAllChn").innerHTML="Copy to all channels";
		$s("aencAudio").innerHTML="Enable Audio";
		$s("aencInputType").innerHTML="Audio Input";
		$s("aencType").innerHTML="Encoding";
		$s("aencBitrate").innerHTML="Audio Bit Rate";
		$s("aencSampling").innerHTML="Sampling Rate";
		$s("savesumbit").value="Save";
	}else if(type==1){//中文
		$s("aenc").innerHTML="音频编码";
		$s("aencChn").innerHTML="通道";
		$s("aencAllChn").innerHTML="复制到所有通道";
		$s("aencAudio").innerHTML="开启音频";
		$s("aencInputType").innerHTML="输入方式";
		$s("aencType").innerHTML="压缩格式";
		$s("aencBitrate").innerHTML="音频码率";
		$s("aencSampling").innerHTML="采样率";
		$s("savesumbit").value="保存";
	}else if(type==2){//韩文
		$s("aenc").innerHTML="오디오 설정";
		$s("aencChn").innerHTML="Channel";
		$s("aencAllChn").innerHTML="Copy to all channels";
		$s("aencAudio").innerHTML="오디오 활성화";
		$s("aencInputType").innerHTML="오디오 입력";
		$s("aencType").innerHTML="오디오 압축 코덱";
		$s("aencBitrate").innerHTML="음성 전송대역";
		$s("aencSampling").innerHTML="샘플링 레이트";
		$s("savesumbit").value="저장";
		var inputtype=document.getElementById("inputtype");
		inputtype.options[0].text="마이크 입력";
		inputtype.options[1].text="라인 입력";
	}
}
