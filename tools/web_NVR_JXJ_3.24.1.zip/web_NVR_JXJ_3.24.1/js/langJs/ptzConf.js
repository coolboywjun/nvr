function changeTheLanguage(type){
	setLanguage(type);
	if(type==0){//英文
		$s("ptzConf").innerHTML="PTZ Setting";
		$s("paramChnNum").innerHTML="Channel Number";
		$s("ptzConfProtocal").innerHTML="Protocal";
		$s("ptzConfAddress").innerHTML="PTZ Address";
		$s("serial1").innerHTML="Port Type";
		$s("serialBitrate").innerHTML="Baud Rate";
		$s("serialDatabit").innerHTML="Data Bit";
		$s("serialStopbit").innerHTML="Stop Bit";
		$s("serialParity").innerHTML="Check Bit";

		var serial_parity=document.getElementById("serial_parity");
		serial_parity.options[0].text="No Check";
		serial_parity.options[1].text="Odd Check";
		serial_parity.options[2].text="Even Check";
		$s("savesumbit").value="Save";
	}else if(type==1){//中文
		$s("ptzConf").innerHTML="云台";
		$s("paramChnNum").innerHTML="通道号";
		$s("ptzConfProtocal").innerHTML="云台协议";
		$s("ptzConfAddress").innerHTML="地址码";
		$s("serial1").innerHTML="串口";
		$s("serialBitrate").innerHTML="波特率";
		$s("serialDatabit").innerHTML="数据位";
		$s("serialStopbit").innerHTML="停止位";
		$s("serialParity").innerHTML="校验位";

		var serial_parity=document.getElementById("serial_parity");
		serial_parity.options[0].text="无校验";
		serial_parity.options[1].text="奇校验";
		serial_parity.options[2].text="偶校验";
		$s("savesumbit").value="保存";
	}else if(type==2){//韩文
		$s("ptzConf").innerHTML="PTZ 설정";
		$s("paramChnNum").innerHTML="채널 번호";
		$s("ptzConfProtocal").innerHTML="PTZ 프로토콜";
		$s("ptzConfAddress").innerHTML="PTZ 주소";
		$s("serial1").innerHTML="포트";
		$s("serialBitrate").innerHTML="Baud Rate";
		$s("serialDatabit").innerHTML="Data Bit";
		$s("serialStopbit").innerHTML="Stop Bit";
		$s("serialParity").innerHTML="Check Bit";

		var serial_parity=document.getElementById("serial_parity");
		serial_parity.options[0].text="No Check";
		serial_parity.options[1].text="Odd Check";
		serial_parity.options[2].text="Even Check";
		$s("savesumbit").value="저장";
	}
}
