function changeTheLanguage(type){
	setLanguage(type);
	if(type==0){//英文
		$s("netDisk").innerHTML="Network Disk";
		$s("netDiskOpen").innerHTML="Enable Network Disk";
		$s("diskProto").innerHTML="Disk Protocol";
		$s("diskIP").innerHTML="Disk Ip";
		$s("diskPort").innerHTML="Disk Port";
		$s("diskName").innerHTML="Disk Target Name";
		$s("authType").innerHTML="Target Type";
		$s("authUser").innerHTML="CHAP Username";
		$s("authPasswd").innerHTML="CHAP Password";

		$s("savesumbit").value="Save";
	}else if(type==1){//中文
		$s("netDisk").innerHTML="网络磁盘";
		$s("netDiskOpen").innerHTML="启用网络磁盘";
		$s("diskProto").innerHTML="网络盘协议类型";
		$s("diskIP").innerHTML="网络磁盘Ip地址";
		$s("diskPort").innerHTML="网络磁盘服务端口";
		$s("diskName").innerHTML="网络磁盘Target 名称";
		$s("authType").innerHTML="Target 访问认证";
		$s("authUser").innerHTML="CHAP 用户名";
		$s("authPasswd").innerHTML="CHAP 认证密码";

		$s("savesumbit").value="保存";
	}else if(type==2){//韩文
		$s("netDisk").innerHTML="네트워크 디스크";
		$s("netDiskOpen").innerHTML="사용가능";
		$s("diskProto").innerHTML="프로토콜 종류";
		$s("diskIP").innerHTML="IP 주소";
		$s("diskPort").innerHTML="서버포트";
		$s("diskName").innerHTML="Target명칭";
		$s("authType").innerHTML="Target 접속 인증";
		$s("authUser").innerHTML="CHAP 사용자명";
		$s("authPasswd").innerHTML="CHAP 비밀번호";

		$s("savesumbit").value="저장";
	}
}
