function changeTheLanguage(type){
	setLanguage(type);
	if(type==0){//英文
		$s("osd").innerHTML="OSD Setting ";
		$s("osdDate").innerHTML=" Display Time ";
		$s("paramChnNum").innerHTML="Channel Number";
		$s("osdTimeColor").innerHTML="Time Color &nbsp;";
		$s("osdTitle").innerHTML=" Display Text ";
		$s("osdTitleColor").innerHTML="Text Color &nbsp;";
		$s("osdTitleText").innerHTML="Text";
		$s("osdPosition").value="OSD Setting";
		$s("invertColor").innerHTML="Invert Color";
		$s("displayStream").innerHTML="Display Stream &nbsp;";

		$s("osdTitle2").innerHTML=" Display Text 2 ";
		$s("osdTitleText2").innerHTML="Text 2 ";
		$s("osdTitle3").innerHTML=" Display Text 3 ";
		$s("osdTitleText3").innerHTML="Text 3 ";
		
		/*var osd_timeColor=document.getElementById("osd_timeColor");
		osd_timeColor.options[0].text="Black";
		osd_timeColor.options[1].text="White";
		osd_timeColor.options[2].text="Blue";
		osd_timeColor.options[3].text="Yellow";*/

		/*var osd_titleColor=document.getElementById("osd_titleColor");
		osd_titleColor.options[0].text="Black";
		osd_titleColor.options[1].text="White";
		osd_titleColor.options[2].text="Blue";
		osd_titleColor.options[3].text="Yellow"*/

		$s("osd_titleColor").title="Click to set the color";

		$s("savesumbit").value="Save";
	}else if(type==1){
		$s("osd").innerHTML="字幕设置";
		$s("osdDate").innerHTML=" 显示时间 ";
		$s("paramChnNum").innerHTML="通道号";
		$s("osdTimeColor").innerHTML="字体颜色&nbsp;&nbsp;";
		$s("osdTitle").innerHTML="&nbsp;显示标题&nbsp;";
		$s("osdTitleColor").innerHTML="字体颜色&nbsp;&nbsp;";
		$s("osdTitleText").innerHTML="标题内容";
		$s("osdPosition").value="OSD位置设置";
		$s("invertColor").innerHTML="启用反色";
		$s("displayStream").innerHTML="显示码流信息";

		$s("osdTitle2").innerHTML="&nbsp;显示标题2&nbsp;";
		$s("osdTitleText2").innerHTML="标题内容2";
		$s("osdTitle3").innerHTML="&nbsp;显示标题3&nbsp;";
		$s("osdTitleText3").innerHTML="标题内容3";


		$s("osd_titleColor").title="点击可进行颜色设置";
		
		$s("savesumbit").value="保存";
	}else if(type==2){//韩文
		$s("osd").innerHTML="OSD";
		$s("osdDate").innerHTML=" OSD 표시 시간 ";
		$s("paramChnNum").innerHTML="채널 번호";
		$s("osdTimeColor").innerHTML="텍스트 색상&nbsp;&nbsp;";
		$s("osdTitle").innerHTML="&nbsp;OSD 표시 텍스트&nbsp;";
		$s("osdTitleColor").innerHTML="텍스트 색상&nbsp;&nbsp;";
		$s("osdTitleText").innerHTML="텍스트";
		$s("osdPosition").value="OSD 위치설정";
		$s("invertColor").innerHTML="보색";
		$s("displayStream").innerHTML="영상 정보";

		$s("osdTitle2").innerHTML="&nbsp;OSD 표시 텍스트2&nbsp;";
		$s("osdTitleText2").innerHTML="텍스트2";
		$s("osdTitle3").innerHTML="&nbsp;OSD 표시 텍스트3&nbsp;";
		$s("osdTitleText3").innerHTML="텍스트3";


		$s("osd_titleColor").title="색상 설정";
		
		$s("savesumbit").value="저장";

	}
}
