function changeTheLanguage(type){
	setLanguage(type);
	if(type==0){//英文
		$s("sysTime").innerHTML="Time Setting";
		$s("sysTimeManual").innerHTML="Device Time Setting";
		$s("sysTimeCurrent").innerHTML="Device Time";
		$s("sysTimePc").innerHTML="Get PC Time";
		$s("sysTimeManualSet").innerHTML="Manual";
		$s("sysTimeNtp").innerHTML="NTP Server Setting";
		$s("sysTimeNptOpen").innerHTML="Sync to NTP";
		$s("sysTimeNtpServer").innerHTML="Server IP";
		$s("sysTimeZone").innerHTML="Time Zone";
		$s("sysTimeRef").innerHTML="Update Cycle";
		$s("sysTimeHour").innerHTML="Hour";
		$s("sysTimeEuro").innerHTML="Enable Day Light Saving Time";

		$s("savesumbit").value="Save";

		var zoneObj=document.getElementById("systime_zone");
		var zoneTmpe=zoneObj.value;
		zoneObj.length=0;
		zoneObj.options[0]=new Option("(GMT+13:00)Nukualofa Tonga", "13");
		zoneObj.options[1]=new Option("(GMT+12:00)Fiji, Exploration and peninsula, Marshall Islands, Will Neton", "12");
		zoneObj.options[2]=new Option("(GMT+11:00)Magellan, Solomon Islands", "11");
		zoneObj.options[3]=new Option("(GMT+10:00)Canberra, Guam, Port Moresby", "10");
		zoneObj.options[4]=new Option("(GMT+09:00)Seoul, Tokyo, Yakutsk", "9");
		zoneObj.options[5]=new Option("(GMT+08:00)Beijing, Hongkong, Singapore, Taipei", "8");
		zoneObj.options[6]=new Option("(GMT+07:00)Bangkok, Hanoi, Jakarta", "7");
		zoneObj.options[7]=new Option("(GMT+06:00)Aspen Tati, A Mandi, can Lunbo, Di Haka", "6");
		zoneObj.options[8]=new Option("(GMT+05:00)Kaisa Lin Town, Islamabad, Tashkent", "5");
		zoneObj.options[9]=new Option("(GMT+04:00)Abu Dhabi, Baku, Muscat, Tbilisi", "4");
		zoneObj.options[10]=new Option("(GMT+03:00)Moscow, St. Petersburg, Volga, Baghdad, Kuwait, Riyadh", "3");
		zoneObj.options[11]=new Option("(GMT+02:00)Athens, Harare, Bucharest, Jerusalem, Cairo, Istanbul, Minsk", "2");
		zoneObj.options[12]=new Option("(GMT+01:00)Amsterdam, Budapest, Sofia, Prague, Berlin, Copenhagen, Madrid, Paris, Rome, Stockholm, Vienna", "1");
		zoneObj.options[13]=new Option("(GMT+00:00)Casablanca City, Monrovia, Dublin, Edinburgh, Lisbon, London", "0");
		zoneObj.options[14]=new Option("(GMT-01:00)Azores, De angular", "-1");
		zoneObj.options[15]=new Option("(GMT-02:00)Central - Argentina", "-2");
		zoneObj.options[16]=new Option("(GMT-03:00)Newfoundland", "-3");
		zoneObj.options[17]=new Option("(GMT-04:00)Caracas, La Paz", "-4");
		zoneObj.options[18]=new Option("(GMT-05:00)Indiana, Lima, Quito, Bogota", "-5");
		zoneObj.options[19]=new Option("(GMT-06:00)Mexico, Tegucigalpa", "-6");
		zoneObj.options[20]=new Option("(GMT-07:00)Arizona", "-7");
		zoneObj.options[21]=new Option("(GMT-08:00)Pacific standard time (America & Canada)", "-8");
		zoneObj.options[22]=new Option("(GMT-09:00)Alaska", "-9");
		zoneObj.options[23]=new Option("(GMT-10:00)Hawaii", "-10");
		zoneObj.options[24]=new Option("(GMT-11:00)U.S. Midwest, Samoa", "-11");
		zoneObj.options[25]=new Option("(GMT-12:00)Eniwetok, Kwajalein", "-12");
		document.getElementById("systime_zone").value=zoneTmpe;
	}else if(type==1){//中文
		$s("sysTime").innerHTML="时间设置";
		$s("sysTimeManual").innerHTML="手动对时";
		$s("sysTimeCurrent").innerHTML="当前时间";
		$s("sysTimePc").innerHTML="与本地电脑同步";
		$s("sysTimeManualSet").innerHTML="手动设置";
		$s("sysTimeNtp").innerHTML="NTP对时";
		$s("sysTimeNptOpen").innerHTML="开启NTP";
		$s("sysTimeNtpServer").innerHTML="NTP服务器";
		$s("sysTimeZone").innerHTML="时区";
		$s("sysTimeRef").innerHTML="对时间隔";
		$s("sysTimeHour").innerHTML="小时";
		$s("sysTimeEuro").innerHTML="启动夏令时";

		$s("savesumbit").value="保存";
	}else if(type==2){//韩文
		$s("sysTime").innerHTML="시스템 시간";
		$s("sysTimeManual").innerHTML="수동설정, PC와 동기";
		$s("sysTimeCurrent").innerHTML="현재 시간";
		$s("sysTimePc").innerHTML="PC와 동기";
		$s("sysTimeManualSet").innerHTML="수동설정";
		$s("sysTimeNtp").innerHTML="NTP와 동기 ";
		$s("sysTimeNptOpen").innerHTML="NTP 활성화";
		$s("sysTimeNtpServer").innerHTML="NTP 서버";
		$s("sysTimeZone").innerHTML="타임 존";
		$s("sysTimeRef").innerHTML="동기 주기";
		$s("sysTimeHour").innerHTML="시간";
		$s("sysTimeEuro").innerHTML="서머타임 활성화";

		$s("savesumbit").value="저장";

		var zoneObj=document.getElementById("systime_zone");
		var zoneTmpe=zoneObj.value;
		zoneObj.length=0;
		zoneObj.options[0]=new Option("(GMT+13:00)Nukualofa Tonga", "13");
		zoneObj.options[1]=new Option("(GMT+12:00)Fiji, Exploration and peninsula, Marshall Islands, Will Neton", "12");
		zoneObj.options[2]=new Option("(GMT+11:00)Magellan, Solomon Islands", "11");
		zoneObj.options[3]=new Option("(GMT+10:00)Canberra, Guam, Port Moresby", "10");
		zoneObj.options[4]=new Option("(GMT+09:00)Seoul, Tokyo, Yakutsk", "9");
		zoneObj.options[5]=new Option("(GMT+08:00)Beijing, Hongkong, Singapore, Taipei", "8");
		zoneObj.options[6]=new Option("(GMT+07:00)Bangkok, Hanoi, Jakarta", "7");
		zoneObj.options[7]=new Option("(GMT+06:00)Aspen Tati, A Mandi, can Lunbo, Di Haka", "6");
		zoneObj.options[8]=new Option("(GMT+05:00)Kaisa Lin Town, Islamabad, Tashkent", "5");
		zoneObj.options[9]=new Option("(GMT+04:00)Abu Dhabi, Baku, Muscat, Tbilisi", "4");
		zoneObj.options[10]=new Option("(GMT+03:00)Moscow, St. Petersburg, Volga, Baghdad, Kuwait, Riyadh", "3");
		zoneObj.options[11]=new Option("(GMT+02:00)Athens, Harare, Bucharest, Jerusalem, Cairo, Istanbul, Minsk", "2");
		zoneObj.options[12]=new Option("(GMT+01:00)Amsterdam, Budapest, Sofia, Prague, Berlin, Copenhagen, Madrid, Paris, Rome, Stockholm, Vienna", "1");
		zoneObj.options[13]=new Option("(GMT+00:00)Casablanca City, Monrovia, Dublin, Edinburgh, Lisbon, London", "0");
		zoneObj.options[14]=new Option("(GMT-01:00)Azores, De angular", "-1");
		zoneObj.options[15]=new Option("(GMT-02:00)Central - Argentina", "-2");
		zoneObj.options[16]=new Option("(GMT-03:00)Newfoundland", "-3");
		zoneObj.options[17]=new Option("(GMT-04:00)Caracas, La Paz", "-4");
		zoneObj.options[18]=new Option("(GMT-05:00)Indiana, Lima, Quito, Bogota", "-5");
		zoneObj.options[19]=new Option("(GMT-06:00)Mexico, Tegucigalpa", "-6");
		zoneObj.options[20]=new Option("(GMT-07:00)Arizona", "-7");
		zoneObj.options[21]=new Option("(GMT-08:00)Pacific standard time (America & Canada)", "-8");
		zoneObj.options[22]=new Option("(GMT-09:00)Alaska", "-9");
		zoneObj.options[23]=new Option("(GMT-10:00)Hawaii", "-10");
		zoneObj.options[24]=new Option("(GMT-11:00)U.S. Midwest, Samoa", "-11");
		zoneObj.options[25]=new Option("(GMT-12:00)Eniwetok, Kwajalein", "-12");
		document.getElementById("systime_zone").value=zoneTmpe;
	}
}
