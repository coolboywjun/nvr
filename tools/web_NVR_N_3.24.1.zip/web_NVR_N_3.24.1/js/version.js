var version="V3.24.1_N";
var companyUrl="";
var companyZH="";
var companyEN="";
var phoneNumZH="";
var phoneNumEN="";
