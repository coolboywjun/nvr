function changeTheLanguage(type){
	setLanguage(type);
	if(type==0){//英文
		langRecPath="Record Path";
		langCapturePath="Capture Path";
		langDownloadPath="Download Path";

		$s("local").innerHTML="Local Config";
		$s("localSubflow").innerHTML="Stream Type";
	 
		var local_subflow=document.getElementById("local_subflow");
		local_subflow.options[0].text="First Stream";
		local_subflow.options[1].text="Second Stream";
		local_subflow.options[2].text="Third Stream";
		local_subflow.style.width="130px";

		$s("manualRecTime").innerHTML="Manu Record";
		$s("recTime").innerHTML="Minute";
		$s("localRecpath").innerHTML="Record Path";
		$s("localCappath").innerHTML="Capture Path";
		$s("localDlpath").innerHTML="Download Path";
		$s("savesumbit").value="Save";
	}else if(type==1){//中文
		langRecPath="录像路径";
		langCapturePath="抓拍路径";
		langDownloadPath="录像文件下载路径";

		$s("local").innerHTML="本地配置";
		$s("localSubflow").innerHTML="码流选择";
	 
		var local_subflow=document.getElementById("local_subflow");
		local_subflow.options[0].text="主码流";
		local_subflow.options[1].text="次码流";
		local_subflow.options[2].text="三码流";

		$s("manualRecTime").innerHTML="手动录像时长";
		$s("recTime").innerHTML="分";
		$s("localRecpath").innerHTML="录像路径";
		$s("localCappath").innerHTML="抓拍路径";
		$s("localDlpath").innerHTML="录像文件下载路径";
		$s("savesumbit").value="保存";
	}else if(type==2){//韩文
		langRecPath="저장 경로";
		langCapturePath="캡쳐 경로";
		langDownloadPath="다운로드 경로";

		$s("local").innerHTML="로컬 설정";
		$s("localSubflow").innerHTML="스트림 타입";
	 
		var local_subflow=document.getElementById("local_subflow");
		local_subflow.options[0].text="1st 스트림";
		local_subflow.options[1].text="2st 스트림";
		local_subflow.options[2].text="3st 스트림";

		$s("manualRecTime").innerHTML="수동녹화시간";
		$s("recTime").innerHTML="분";
		$s("localRecpath").innerHTML="저장 경로";
		$s("localCappath").innerHTML="캡쳐 경로";
		$s("localDlpath").innerHTML="다운로드 경로";
		$s("savesumbit").value="저장";
	}else if(type==3){//俄罗斯
		langRecPath="Путь записи";
		langCapturePath="Путь снимков";
		langDownloadPath="Путь загрузки";

		$s("local").innerHTML="Лок. Настройки";
		$s("localSubflow").innerHTML="Тип потока";
	 
		var local_subflow=document.getElementById("local_subflow");
		local_subflow.options[0].text="Первый поток";
		local_subflow.options[1].text="Второй поток";
		local_subflow.options[2].text="Третий поток";

		$s("manualRecTime").innerHTML="Ручн. запись";
		$s("recTime").innerHTML="Минут";
		$s("localRecpath").innerHTML="Путь записи";
		$s("localCappath").innerHTML="Путь снимков";
		$s("localDlpath").innerHTML="Путь загрузки";
		$s("savesumbit").value="Сохр.";
	}

}
