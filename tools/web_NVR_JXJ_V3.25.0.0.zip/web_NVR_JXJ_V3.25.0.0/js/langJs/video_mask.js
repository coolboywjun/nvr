function changeTheLanguage(type){
	setLanguage(type);
	if(type==0){//英文
		$s("mask").innerHTML="Privacy Zone";
		$s("paramChnNum").innerHTML="Channel Number";
		$s("maskOpen").innerHTML="Enable Privacy Zone";

		var btnSetmask=$s("btn_setmask");
		btnSetmask.style.backgroundImage="url(images/web_100.jpg)";
		btnSetmask.style.width="110px";
		btnSetmask.value="Set Zone";

		$s("savesumbit").value="Save";
	}else if(type==1){
		$s("mask").innerHTML="视频屏蔽";
		$s("paramChnNum").innerHTML="通道号";
		$s("maskOpen").innerHTML="开启视频屏蔽";

		$s("btn_setmask").value="屏蔽区域设置";

		$s("savesumbit").value="保存";
	}else if(type==2){//韩文
		$s("mask").innerHTML="프라이버시 영역";
		$s("paramChnNum").innerHTML="채널 번호";
		$s("maskOpen").innerHTML="프라이버시 영역 활성화";

		var btnSetmask=$s("btn_setmask");
		btnSetmask.style.backgroundImage="url(images/web_100.jpg)";
		btnSetmask.style.width="110px";
		btnSetmask.value="영역 설정";

		$s("savesumbit").value="저장";

	}else if(type==3){//俄罗斯
		$s("mask").innerHTML="Маска";
		$s("paramChnNum").innerHTML="Номер канала";
		$s("maskOpen").innerHTML="Включить маску";

		$s("btn_setmask").value="Уст. зону";

		$s("savesumbit").value="Сохр.";
	}
}
