function changeTheLanguage(type){
	setLanguage(type);
	if(type==0){//英文
		$s("netFtp").innerHTML="FTP Setting";
		$s("netFtpServer").innerHTML="Server IP";
		$s("netFtpPort").innerHTML="Server Port";
		$s("netFtpPath").innerHTML="Remote Path";
		$s("netFtpUser").innerHTML="User Name";
		$s("netFtpPassword").innerHTML="Password";

		$s("savesumbit").value="Save";
	}else if(type==1){//中文
		$s("netFtp").innerHTML="FTP服务";
		$s("netFtpServer").innerHTML="服务器地址";
		$s("netFtpPort").innerHTML="服务端口";
		$s("netFtpPath").innerHTML="存储路径";
		$s("netFtpUser").innerHTML="用户名";
		$s("netFtpPassword").innerHTML="密码";

		$s("savesumbit").value="保存";
	}else if(type==2){//韩文
		$s("netFtp").innerHTML="FTP 설정";
		$s("netFtpServer").innerHTML="Server IP";
		$s("netFtpPort").innerHTML="Server 포트";
		$s("netFtpPath").innerHTML="Remote 경로";
		$s("netFtpUser").innerHTML="사용자 이름";
		$s("netFtpPassword").innerHTML="비밀번호";

		$s("savesumbit").value="저장";
	}else if(type==3){//俄罗斯
		$s("netFtp").innerHTML="FTP настройки";
		$s("netFtpServer").innerHTML="Сервер IP";
		$s("netFtpPort").innerHTML="Сервер Порт";
		$s("netFtpPath").innerHTML="Удал. путь";
		$s("netFtpUser").innerHTML="Имя";
		$s("netFtpPassword").innerHTML="Пароль";

		$s("savesumbit").value="Сохр.";
	}
}
