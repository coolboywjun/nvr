function changeTheLanguage(type){
	setLanguage(type);
	if(type==0){//英文
		$s("servPort").innerHTML="Port Setting";
		$s("servPortData").innerHTML="Device Port";
		$s("servPortHTTP").innerHTML="Web Port";
		
		$s("savesumbit").value="Save";
	}else if(type==1){//中文
		$s("servPort").innerHTML="端口配置";
		$s("servPortData").innerHTML="数据端口";
		$s("servPortHTTP").innerHTML="HTTP端口";
		
		$s("savesumbit").value="保存";
	}else if(type==2){//韩文
		$s("servPort").innerHTML="포트 설정";
		$s("servPortData").innerHTML="장비 포트";
		$s("servPortHTTP").innerHTML="웹 포트";
	
		$s("savesumbit").value="저장";
	}else if(type==3){//俄罗斯
		$s("servPort").innerHTML="Настройка порта";
		$s("servPortData").innerHTML="Порт устройства";
		$s("servPortHTTP").innerHTML="Web порт";
		
		$s("savesumbit").value="Сохр.";
	}
}
