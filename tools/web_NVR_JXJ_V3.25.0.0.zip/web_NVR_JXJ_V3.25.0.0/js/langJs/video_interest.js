function changeTheLanguage(type){
	setLanguage(type);
	if(type==0){//英文
		$s("interest").innerHTML="Interest Area";
		$s("paramChnNum").innerHTML="Channel Number";
		$s("interestOpen").innerHTML="Enable Interest";
		$s("btn_setInterest").value="Set Interest";
		$s("qualityVla").innerHTML="Quality Level";

		$s("savesumbit").value="Save";
	}else if(type==1){
		$s("interest").innerHTML="感兴趣区域";
		$s("paramChnNum").innerHTML="通道号";
		$s("interestOpen").innerHTML="开启感兴趣区域设置";
		$s("btn_setInterest").value="感兴趣区域设置";
		$s("qualityVla").innerHTML="质量值";

		$s("savesumbit").value="保存";
	}else if(type==2){//韩文
		$s("interest").innerHTML="관심지역";
		$s("paramChnNum").innerHTML="채널 번호";
		$s("interestOpen").innerHTML="사용가능";
		$s("btn_setInterest").value="설정";
		$s("qualityVla").innerHTML="녹화 레벨";

		$s("savesumbit").value="저장";
	}else if(type==3){//俄罗斯
		$s("interest").innerHTML="Зона интереса";
		$s("paramChnNum").innerHTML="Номер канала";
		$s("interestOpen").innerHTML="Включить зону";
		$s("btn_setInterest").value="Настроить зону";
		$s("qualityVla").innerHTML="Уровень качества";

		$s("savesumbit").value="Сохр.";
	}
}
