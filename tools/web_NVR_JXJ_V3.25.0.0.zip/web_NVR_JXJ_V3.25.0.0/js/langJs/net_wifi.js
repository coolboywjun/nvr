function changeTheLanguage(type){
	setLanguage(type);
	if(type==0){//英文
		$s("netWifi").innerHTML="Wifi Setting";
		$s("netWofiInfo").innerHTML="Wifi Net Info";
		$s("wifiChoice").innerHTML="Select";
		$s("wifiName").innerHTML="Wifi Name";
		$s("wifiSignal").innerHTML="Signal";
		$s("usedStatus").innerHTML="Used";
		$s("wifiStatus").innerHTML="Status";
		$s("enterPsw").innerHTML="Password : ";

		noWifiInfo="No Wifi";
		connect1="Using";
		connect2="Unused";
		status1="Connection";
		status2="Success";

		$s("connectBtn").value="Connect";
		$s("cutBtn").value="Cut";
		$s("refurbish").value="Refresh";
	}else if(type==1){//中文
		$s("netWifi").innerHTML="无线网卡服务";
		$s("netWofiInfo").innerHTML="无线网络信息";
		$s("wifiChoice").innerHTML="选择";
		$s("wifiName").innerHTML="网络名称";
		$s("wifiSignal").innerHTML="信号强度";
		$s("usedStatus").innerHTML="使用状态";
		$s("wifiStatus").innerHTML="连接状态";
		$s("enterPsw").innerHTML="请输入密码： ";

		noWifiInfo="没有查找到无线网络";
		connect1="使用中";
		connect2="未使用";
		status1="连接中···";
		status2="成功";

		$s("connectBtn").value="连接";
		$s("cutBtn").value="断开";
		$s("refurbish").value="刷新";
	}else if(type==2){//韩文
		$s("netWifi").innerHTML="Wifi 세팅";
		$s("netWofiInfo").innerHTML="Wifi 네트워크 정보";
		$s("wifiChoice").innerHTML="선택";
		$s("wifiName").innerHTML="Wifi 이름";
		$s("wifiSignal").innerHTML="시그널";
		$s("usedStatus").innerHTML="상태";
		$s("wifiStatus").innerHTML="상태";
		$s("enterPsw").innerHTML="연결 : ";

		noWifiInfo="무선 네트워크를 찾을 수 없습니다";
		connect1="사용중";
		connect2="미사용";
		status1="연결중···";
		status2="성공";

		$s("connectBtn").value="연결";
		$s("cutBtn").value="정지";
		$s("refurbish").value="재시도";

	}else if(type==3){//中文
		$s("netWifi").innerHTML="Wifi настройки";
		$s("netWofiInfo").innerHTML="Wifi инфо о сети";
		$s("wifiChoice").innerHTML="Выбор";
		$s("wifiName").innerHTML="Wifi имя";
		$s("wifiSignal").innerHTML="Сигнал";
		$s("usedStatus").innerHTML="Исп";
		$s("wifiStatus").innerHTML="Статус";
		$s("enterPsw").innerHTML="Пароль : ";

		noWifiInfo="Нет Wifi";
		connect1="Исп";
		connect2="Не исп";
		status1="Соединение";
		status2="Успешно";

		$s("connectBtn").value="Подкл.";
		$s("cutBtn").value="Отк.";
		$s("refurbish").value="Обнов.";
	}
}
