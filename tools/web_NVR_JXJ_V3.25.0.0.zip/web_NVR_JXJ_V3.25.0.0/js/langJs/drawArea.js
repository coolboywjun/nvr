function changeTheLanguage(type){
	setLanguage(type);
	if(type==0){//英文
		$s("maskOpen").innerHTML = "Set";
		$s("clearBtn").value = "Clear";
		$s("closeBtn").value = "Close";
	}else if(type==1){//中文
		$s("maskOpen").innerHTML = "开始画线";
		$s("clearBtn").value = "清除";
		$s("closeBtn").value = "退出";
	}else if(type==2){//韩文
		$s("maskOpen").innerHTML = "알람구역지정";
		$s("clearBtn").value = "해제";
		$s("closeBtn").value = "나가기";
	}else if(type==3){//俄罗斯
		$s("maskOpen").innerHTML = "Уст.";
		$s("clearBtn").value = "Сброс";
		$s("closeBtn").value = "Закрыть";
	}
}
