function changeTheLanguage(type){
	setLanguage(type);
	if(type==0){//英文
		$s("venc").innerHTML="Encoding";
		$s("paramChnNum").innerHTML="Channel Number";
		$s("vencStreamType").innerHTML="Stream Type";
		$s("vecn_streamType").style.width="115px";
		$s("vencFrate").innerHTML="Frame Rate";
		$s("vencFinterval").innerHTML="I Frame";
		$s("vencAudio").innerHTML="Enable Audio";
		$s("vencBitrate").innerHTML="Bit Rate(Kb/s)";
		$s("bitrateS").innerHTML="";
		
		$s("vencFramePriority").innerHTML="Frame Rate Priority";
		$s("vencQuality").innerHTML="Quality";

		$s("vencVideoType").innerHTML="Encoding";
		$s("vencAudioType").innerHTML="Audio Encoding Type";
		$s("vencAudioInputType").innerHTML="Audio Input";
		$s("vencResolution").innerHTML="Resolution";
		$s("vencVideoFormat").innerHTML="Signal System";
		$s("vencBitRateType").innerHTML="Bit Rate Type";
		$s("vencCodeLevel").innerHTML="Encode Level";
		
		$s("vencBase").innerHTML="Base";
		$s("vencAdvance").innerHTML="Advance";

		var venc_quality=document.getElementById("venc_quality");
		venc_quality.options[0].text="Best";
		venc_quality.options[1].text="Better";
		venc_quality.options[2].text="Good";
		venc_quality.options[3].text="Normal";
		venc_quality.options[4].text="Worse";
		venc_quality.options[5].text="Worst";

		/*var venc_codeLevel=document.getElementById("venc_codeLevel");
		venc_codeLevel.options[0].text="Low";
		venc_codeLevel.options[1].text="Medium";
		venc_codeLevel.options[2].text="High";*/

		$s("savesumbit").value="Save";
	}else if(type==1){
		$s("venc").innerHTML="音视频编码";
		$s("paramChnNum").innerHTML="通道号";
		$s("vencStreamType").innerHTML="码流类型";
		$s("vencFrate").innerHTML="帧率";
		$s("vencFinterval").innerHTML="I 帧间隔";
		$s("vencAudio").innerHTML="启用音频";
		$s("vencBitrate").innerHTML="码率";
		$s("bitrateS").innerHTML="Kbps";
		
		$s("vencFramePriority").innerHTML="帧率优先";
		$s("vencQuality").innerHTML="图像质量";

		$s("vencVideoType").innerHTML="视频编码类型";
		$s("vencAudioType").innerHTML="音频编码类型";
		$s("vencAudioInputType").innerHTML="音频输入类型";
		$s("vencResolution").innerHTML="分辨率";
		$s("vencVideoFormat").innerHTML="制式";
		$s("vencBitRateType").innerHTML="位率类型";
		$s("vencCodeLevel").innerHTML="编码等级";
		
		$s("vencBase").innerHTML="基本参数";
		$s("vencAdvance").innerHTML="高级参数";

		var venc_quality=document.getElementById("venc_quality");
		venc_quality.options[0].text="最好";
		venc_quality.options[1].text="较好";
		venc_quality.options[2].text="好";
		venc_quality.options[3].text="中等";
		venc_quality.options[4].text="差";
		venc_quality.options[5].text="很差";

		$s("savesumbit").value="保存";
	}else if(type==2){//韩文
		$s("venc").innerHTML="녹화";
		$s("paramChnNum").innerHTML="채널 번호";
		$s("vencStreamType").innerHTML="스트림 타입";
		$s("vencFrate").innerHTML="프레임율";
		$s("vencFinterval").innerHTML="I 프레임 간격";
		$s("vencAudio").innerHTML="오디오 실행";
		$s("vencBitrate").innerHTML="비트 레이트";
		$s("bitrateS").innerHTML="Kbps";
		
		$s("vencFramePriority").innerHTML="영상처리 우선";
		$s("vencQuality").innerHTML="이미지 품질";

		$s("vencVideoType").innerHTML="녹화종류";
		$s("vencAudioType").innerHTML="오디오종류";
		$s("vencAudioInputType").innerHTML="오디오입력";
		$s("vencResolution").innerHTML="해상도";
		$s("vencVideoFormat").innerHTML="신호방식";
		$s("vencBitRateType").innerHTML="비트레이트";
		$s("vencCodeLevel").innerHTML="녹화레벨";
		
		$s("vencBase").innerHTML="기본 설정";
		$s("vencAdvance").innerHTML="고급 설정";

		var venc_quality=document.getElementById("venc_quality");
		venc_quality.options[0].text="최고 좋음";
		venc_quality.options[1].text="비교적 좋음";
		venc_quality.options[2].text="좋음";
		venc_quality.options[3].text="보통";
		venc_quality.options[4].text="나쁨";
		venc_quality.options[5].text="아주 나쁨";

		$s("savesumbit").value="저장";

	}else if(type==3){//俄罗斯
		$s("venc").innerHTML="Кодирование";
		$s("paramChnNum").innerHTML="Номер канала";
		$s("vencStreamType").innerHTML="Тип потока";
		$s("vecn_streamType").style.width="115px";
		$s("vencFrate").innerHTML="К/с";
		$s("vencFinterval").innerHTML="I кадр";
		$s("vencAudio").innerHTML="Вкл. звук";
		$s("vencBitrate").innerHTML="Битрейт(Кб/с)";
		$s("bitrateS").innerHTML="";
		
		$s("vencFramePriority").innerHTML="Приоритет кадров";
		$s("vencQuality").innerHTML="Качество";

		$s("vencVideoType").innerHTML="Кодирование";
		$s("vencAudioType").innerHTML="Тип кодека звука";
		$s("vencAudioInputType").innerHTML="Аудио вход";
		$s("vencResolution").innerHTML="Разрешение";
		$s("vencVideoFormat").innerHTML="Система";
		$s("vencBitRateType").innerHTML="Тип битрейта";
		$s("vencCodeLevel").innerHTML="Уровень кодирования";
		
		$s("vencBase").innerHTML="Базовый";
		$s("vencAdvance").innerHTML="Расширенный";

		var venc_quality=document.getElementById("venc_quality");
		venc_quality.options[0].text="Максимальный";
		venc_quality.options[1].text="Лучший";
		venc_quality.options[2].text="Хороший";
		venc_quality.options[3].text="Нормальный";
		venc_quality.options[4].text="Худший";
		venc_quality.options[5].text="Плохой";

		/*var venc_codeLevel=document.getElementById("venc_codeLevel");
		venc_codeLevel.options[0].text="Low";
		venc_codeLevel.options[1].text="Medium";
		venc_codeLevel.options[2].text="High";*/

		$s("savesumbit").value="Сохр.";
	}
}
