function changeTheLanguage(type){
	setLanguage(type);
	if(type==0){//英文
		$s("eth").innerHTML="IP Setting";
		var netType=document.getElementById("netType");
		netType.options[0].text="Ethernet";
		netType.options[1].text="WIFI";
		netType.options[2].text="3G";
		
		$s("eth_netType").innerHTML="Network Type";
		$s("getIdFlag1").innerHTML="Obtained IP Address Automatically";
		$s("getIdFlag2").innerHTML="Use IP Address As Following";
		$s("ethIp").innerHTML="IP Address";
		$s("ethSubmask").innerHTML="Subnet Mask";
		$s("ethGateway").innerHTML="Default Gateway";
		$s("getDnsFlag1").innerHTML="Obtained DNS Automatically";
		$s("getDnsFlag2").innerHTML="Use DNS As Following";
		$s("ethDns1").innerHTML="Main DNS";
		$s("ethDns2").innerHTML="Sub DNS";
		$s("ethDevCommandPort").innerHTML="Port";
		$s("ethDevStreamPort").innerHTML="Stream Port";
		$s("ethWEBPort").innerHTML="WEB Port";
		
		$s("description").innerHTML="Warmly Note:";
		$s("tdNotes").innerHTML="Any change of the settings on this page will force camera to reboot and web close!";
		$s("savesumbit").value="Save";
	}else if(type==1){//中文
		$s("eth").innerHTML="网络设备";
		var netType=document.getElementById("netType");
		netType.options[0].text="有线";
		netType.options[1].text="无线";
		netType.options[2].text="3G";
		
		$s("eth_netType").innerHTML="网卡类型";
		$s("getIdFlag1").innerHTML="自动获得IP地址";
		$s("getIdFlag2").innerHTML="使用下面的IP地址";
		$s("ethIp").innerHTML="IP地址";
		$s("ethSubmask").innerHTML="子网掩码";
		$s("ethGateway").innerHTML="默认网关";
		$s("getDnsFlag1").innerHTML="自动获得DNS服务器地址";
		$s("getDnsFlag2").innerHTML="使用下面的DNS服务器地址";
		$s("ethDns1").innerHTML="首选DNS服务器";
		$s("ethDns2").innerHTML="备选DNS服务器";
		$s("ethDevCommandPort").innerHTML="设备命令端口";
		$s("ethDevStreamPort").innerHTML="设备流端口";
		$s("ethWEBPort").innerHTML="web端口";
		
		$s("description").innerHTML="说  明：";
		$s("tdNotes").innerHTML="当前参数页面修改任何参数后，设备会重启，页面将会强行关闭！";
		
		$s("savesumbit").value="保存";
	}else if(type==2){//韩文
		$s("eth").innerHTML="IP 설정";
		var netType=document.getElementById("netType");
		netType.options[0].text="Ethernet";
		netType.options[1].text="WIFI";
		netType.options[2].text="3G";
		
		$s("eth_netType").innerHTML="Network Type";
		$s("getIdFlag1").innerHTML="IP 주소 자동으로 가져오기";
		$s("getIdFlag2").innerHTML="IP 주소 수동 설정";
		$s("ethIp").innerHTML="IP Address";
		$s("ethSubmask").innerHTML="Subnet Mask";
		$s("ethGateway").innerHTML="Default Gateway";
		$s("getDnsFlag1").innerHTML="DNS 자동으로 가져오기";
		$s("getDnsFlag2").innerHTML="DNS 자동으로 가져오기";
		$s("ethDns1").innerHTML="Main DNS";
		$s("ethDns2").innerHTML="Sub DNS";
		$s("ethDevCommandPort").innerHTML="기본포트";
		$s("ethDevStreamPort").innerHTML="비디오포트";
		$s("ethWEBPort").innerHTML="웹 포트";
		
		$s("description").innerHTML="설명 : ";
		$s("tdNotes").innerHTML="현재 파라미터 화면에서 어떠한 파마미터를 수정하게 되면 설비는 재가동 될 수 있으며 강제로 화면이 꺼질 수 있습니다!";
		
		$s("savesumbit").value="저장";

	}else if(type==3){//俄罗斯
		$s("eth").innerHTML="IP настройки";
		var netType=document.getElementById("netType");
		netType.options[0].text="Провод.";
		netType.options[1].text="Беспров.";
		netType.options[2].text="3G";
		
		$s("eth_netType").innerHTML="Тип сети";
		$s("getIdFlag1").innerHTML="Автополученные IP-адреса";
		$s("getIdFlag2").innerHTML="Используйте такой IP-адрес";
		$s("ethIp").innerHTML="IP адрес";
		$s("ethSubmask").innerHTML="Маска";
		$s("ethGateway").innerHTML="Шлюз";
		$s("getDnsFlag1").innerHTML="Автополучение DNS";
		$s("getDnsFlag2").innerHTML="Используйте такой DNS";
		$s("ethDns1").innerHTML="Осн. DNS";
		$s("ethDns2").innerHTML="Доп. DNS";
		$s("ethDevCommandPort").innerHTML="Порт";
		$s("ethDevStreamPort").innerHTML="Потоковый порт";
		$s("ethWEBPort").innerHTML="WEB порт";
		
		$s("description").innerHTML="Примечание:";
		$s("tdNotes").innerHTML="Любое изменение параметров на этой странице вызовет перезагрузку!";
		
		$s("savesumbit").value="Сохр.";
	}
}
