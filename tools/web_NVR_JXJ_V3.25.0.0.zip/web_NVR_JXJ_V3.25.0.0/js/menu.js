
//顶级菜单click
function onTopMenuClick(btnObj){
	if(!hasCapability){
		alert(capabilityMsg);
		return;
	}
	if(!loginSuccess){
		return;
	}
	if(isUpgradeFlag){
		alert(sys_mod_msg4);
		return;
	}
	var curID=btnObj.id;
	if(btnObj.name=="1"){
		return;
	}else if(btnObj.name==""){
		btnObj.name="1";
	}
	
	if(curID=="videoPre"){
		if($s("chnCount").value>1){//多通道
			
		}else{
			if(!$w("ipc").IsStartStream(0, handleID)){
				$w("ipc").StartStream(0, 0,  handleID);
			}
			//$w("ipc").StartStream(0, 0,  handleID);
		}

		try{
			$t("ipc").StopStream($t("childChnNum").value, childHandleID);//关闭参数配置页面视频
		}catch(e){}

		document.getElementById("thumbdIi15v").style.display="block";
		document.getElementById("trackdIi15v").style.display="block";
		document.getElementById("track2dIi15v").style.display="block";

		$("#leftmenu").hide();
		$("#leftpreview").show();
		$("#setpanel").hide();
		$("#previewpanel").show();
		$("#paramConf").attr("name","");
		document.getElementById("videoPre").src="images3/web3_09.jpg";
		document.getElementById("paramConf").src="images/web_11.jpg";
		
		//重设界面
		document.getElementById("leftpreview").style.height=document.body.clientHeight-126;
		$w("videoId").style.height=document.body.clientHeight-165;

		var tempWidth=0;
		if($s("chnListFlag").value=="1" && $w("showChnListImg").value=="1"){//多通道，并且显示列表
			$s("rightChnList").style.display="block";
			tempWidth=184;
		}
		$s("container").style.width=srcAvailWidth-210-tempWidth;
		$w("rbannercontact").style.width=srcAvailWidth-230-tempWidth;
	}else if(curID=="paramConf"){
		//////////////////////////////////////////////////////////////////////////////////////////////////////
		//判断实时视频是否正在录像、监听、对讲
		if($s("chnCount").value>1){//多通道
			//alert(totalRecordCount+" "+totalTalkCount+" "+totalAudioCount);
			if(totalRecordCount>0 || totalTalkCount>0 || totalAudioCount>0){
				if(!confirm(changeMenuMsg1)){
					btnObj.name="";
					return;
				}
			}
			for(var i=1;i<=$s("chnCount").value;i++){
				var tempPlayChn=document.getElementById("previewImg"+i);
				if(tempPlayChn.name=="1"){
					enableStream((i-1), tempPlayChn);//关闭当前视频流
				}
			}
		}else{
			//alert($w("ipc").IsRec(0, handleID)+" "+$w("ipc").IsTalk(0, handleID)+" "+$w("ipc").IsAudio(0, handleID));
			if($w("ipc").IsRec(0, handleID) || $w("ipc").IsTalk(0, handleID) || $w("ipc").IsAudio(0, handleID)){//录像，对讲，监听
				if(!confirm(changeMenuMsg2)){
					btnObj.name="";
					return;
				}else{
					$w("ipc").StopREC(0, handleID);		//停止录像
					$w("ipc").StopTalk(0, handleID);	//停止对讲
					$w("ipc").StopAudio(0, handleID);	//停止监听
					/*$w("btn_record").name="0";
					$w("btn_record").src="images/web_34.jpg";
					$w("btn_talk").name="0";
					$w("btn_talk").src="images/web_37.jpg";
					$w("btn_audio").name="0";
					$w("btn_audio").src="images/web_28.jpg";*/
					//$w("ipc").StopStream(0, handleID);	//停止预览
				}
			}
		}
		//////////////////////////////////////////////////////////////////////////////////////////////////////
		try{
			$t("ipc").StartStream($t("childChnNum").value, $t("childWndIndex").value,  childHandleID);//开启参数配置页面视频
		}catch(e){}

		document.getElementById("thumbdIi15v").style.display="none";
		document.getElementById("trackdIi15v").style.display="none";
		document.getElementById("track2dIi15v").style.display="none";

		$("#leftpreview").hide();
		$("#leftmenu").show();
		$("#previewpanel").hide();
		$("#setpanel").show();
		$("#videoPre").attr("name","");
		document.getElementById("videoPre").src="images/web_09.jpg";
		document.getElementById("paramConf").src="images3/web3_11.jpg";

		//重设界面
		document.getElementById("leftmenu").style.height=document.body.clientHeight-126;
		document.getElementById("setpanel").style.height=document.body.clientHeight-165;

		$s("rightChnList").style.display="none";
		$s("container").style.width=srcAvailWidth-210;
		$s("rbannercontact").style.width=srcAvailWidth-230;
	}else{
		location.href = "./";
	}
}

var sel_menu_id		="";
var drop_menu_id	="";

//菜单click
//isSub		是否为子菜单
//szID		二级菜单
//szUrl		页面地址
function onLevelMenuClick(isSub,szID,szUrl){
	if(isUpgradeFlag){
		alert(sys_mod_msg4);
		return;
	}
	var $obj=$("#"+szID);
	if(!isSub && drop_menu_id!="" && drop_menu_id!=szID){//隐藏前一个展开的菜单
		var $oldobj=$("#"+drop_menu_id);
		$oldobj.hide();
		drop_menu_id="";
	}
	if(szUrl==""){//二级菜单
		$obj.show();
		drop_menu_id=szID;	//下次要隐藏的二级菜单

		var index=1;
		var tempObj;
		while(true){
			tempObj=document.getElementById("sub"+szID.substring(3,szID.length)+"-"+index);
			if(index==20){
				break;
			}
			if(!tempObj || tempObj.style.display=="none"){
				index++;
				continue;
			}else{
				tempObj.click();
				break;
			}
		}
		/*if(document.getElementById("sub"+szID.substring(3,szID.length)+"-1")){//如果有三级菜单，则默认选中第一个菜单
			document.getElementById("sub"+szID.substring(3,szID.length)+"-1").click();
		}*/
	}else{
		if(szID!=sel_menu_id){//修改其它菜单样式
			if(szID=="menu0"){//选中一级菜单"本地配置"
				document.getElementById("menu0").style.color="#4e9305";
				document.getElementById("menu0").style.fontWeight="bold";
			}else{
				document.getElementById("menu0").style.color="#ffffff";
				document.getElementById("menu0").style.fontWeight="normal";
			}
			var ulArray=document.getElementsByTagName("ul");
			for(var i=0;i<ulArray.length;i++){
				if(ulArray[i].getAttribute("name")=="ulNames"){
					if(ulArray[i].id==szID){//选中二级菜单
						document.getElementById(ulArray[i].id).style.color="#4e9305";
						document.getElementById(ulArray[i].id).style.fontWeight="bold";
					}else{
						document.getElementById(ulArray[i].id).style.color="#ffffff";
						document.getElementById(ulArray[i].id).style.fontWeight="normal";
					}
				}
			}
			var liArray=document.getElementsByTagName("li");
			for(var i=0;i<liArray.length;i++){
				if(liArray[i].getAttribute("name")=="liNames"){
					if(liArray[i].id==szID){//选中三级菜单
						document.getElementById(liArray[i].id).style.color="#4e9305";
						document.getElementById(liArray[i].id).style.fontWeight="bold";
					}else{
						document.getElementById(liArray[i].id).style.color="#292929";
						document.getElementById(liArray[i].id).style.fontWeight="normal";
					}
				}
			}
			setTimeout("parent.ifrmSet.location.href  = '"+szUrl+"';",30);
		}
	}
	sel_menu_id=szID;
}

function checkOuttime(){
	set_language=GetCookidStr("LANGSET");
	if(set_language==null || set_language=="undefined"){
		set_language=1;
	}
	SetCookidStr("LANGSET",set_language,7);

	var nowDate=new Date();
	var LNtimes = nowDate.getTime();
	var Oldtimes = GetCookidStr("setOuttimes");
	if(Oldtimes==null || Oldtimes==""){
		location='error.asp';
		return;
	}
	delete nowDate;
	nowDate = null;
	CollectGarbage();
	if((LNtimes-Oldtimes) > 30000){//30秒超时
		location='error.asp';
		return;
	}

	$s("ip").value=(document.URL.split('//')[1]).split('/')[0].split(':')[0];
	$s("dataPort").value=GetCookidStr("dataPort");
	$s("streamPort").value=GetCookidStr("streamPort");
	$s("userName").value=GetCookidStr("loginUserName");
	$s("password").value=GetCookidStr("loginPassword");
	/*if(GetCookidStr("loginPassword")==null){
		$s("password").value="";
	}else{
		$s("password").value=decrypt(GetCookidStr("loginPassword"), "jxj");
	}*/
	/*$s("ip").value="192.168.55.100";
	$s("dataPort").value="3321";
	$s("streamPort").value="7554";
	$s("userName").value="admin";
	$s("password").value="admin";*/

	if($s("userName").value==null || $s("userName").value==""){
		location='error.asp';
		return;
	}

	changeTheLanguage(set_language);
	/*if(set_language==0){//英文
		setLanguage();
		changeToEng();
		setSelectParamToEn();//设置option英文
	}else if(set_language==1){
		window.document.title="网络视频摄像机";
		$s("topName1").innerHTML="实时预览";
		$s("topName2").innerHTML="参数设置";
		$s("topName3").innerHTML="关于";
	}else{}*/

	if($s("devType").value==2){//dvr
		window.document.title="DVR";
	}else if($s("devType").value==3){
		window.document.title="NVR";
	}
	ifrmSet.location.href="localset.asp";
	setOuttime();
}

function setOuttime(){
	var d=new Date();
	var nowTime = d.getTime();
	SetCookidStr("setOuttimes",nowTime,7);
	delete d;
	d = null;
	CollectGarbage();
	setTimeout(setOuttime, 2000);
}
