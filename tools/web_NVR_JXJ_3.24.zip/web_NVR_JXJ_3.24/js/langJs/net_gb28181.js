function changeTheLanguage(type){
	setLanguage(type);
	if(type==0){//英文
		$s("devId").innerHTML="Device Id";
		$s("devPwd").innerHTML="Device Password";
		$s("serverId").innerHTML="Server Id";
		$s("serverIp").innerHTML="Server IP";
		$s("serverPort").innerHTML="Server Port";
		$s("localMsgPort").innerHTML="Local Message Port";

		$s("savesumbit").value="Save";
	}else if(type==1){//中文
		$s("devId").innerHTML="设备ID";
		$s("devPwd").innerHTML="设备密码";
		$s("serverId").innerHTML="服务器ID";
		$s("serverIp").innerHTML="服务器Ip";
		$s("serverPort").innerHTML="服务器端口";
		$s("localMsgPort").innerHTML="本地消息端口";

		$s("savesumbit").value="保存";
	}else if(type==2){
		$s("devId").innerHTML="장치 ID";
		$s("devPwd").innerHTML="장치 암호";
		$s("serverId").innerHTML="서버 ID";
		$s("serverIp").innerHTML="서버 IP";
		$s("serverPort").innerHTML="서버 포트";
		$s("localMsgPort").innerHTML="지역 뉴스 포트";

		$s("savesumbit").value="저장";
	}
}
