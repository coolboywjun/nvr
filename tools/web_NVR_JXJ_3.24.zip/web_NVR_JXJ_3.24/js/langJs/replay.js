function changeTheLanguage(type){
	setLanguage(type);
	if(type==0){//英文
		langPlay="Play";
		langPause="Pause";

		selAuto="Auto";
		selManual="Manual";
		selMotion="Motion";
		selProbe="Probe";
		selLost="Lost";
		selHide="Hide";
		selPIR="PIR";

		$s("imgPalyback").style.backgroundImage="url(Replayimages/hf_01_en.jpg)";
		$s("imgRecFile").style.backgroundImage="url(Replayimages/hf_13_en.jpg)";

		$s("tdSearch1").style.paddingLeft=15;
		$s("tdSearch2").style.paddingLeft=20;
		
		$s("paramChnNum").innerHTML="Channel";
		$s("playSearchL").innerHTML="Local";
		$s("playSearchD").innerHTML="Device";
		$s("playType").innerHTML="Type";
		
		$s("searchStartTime").innerHTML="Start Time";
		$s("searchEndTime").innerHTML="End Time";

		//$s("tableFileList").style.height="275px";

		$s("btn_open").title="Open File";
		$s("btn_play").title="Play";
		$s("btn_stop").title="Stop";
		$s("btn_slow").title="Slow Forward";
		$s("btn_fast").title="Fast Forward";
		//$s("previous").title="Previous Frame";
		$s("next").title="Next frame";
		$s("btn_audio").title="Enable Audio";
		$s("btn_cap").title="Capture";
		$s("btn_full").title="Full Screen";
		
		$s("searchBtn").value="Search";
		$s("downloadDiv").innerHTML="<INPUT TYPE='button' id='downloadBtn' class='replayBtn' value='Download'  onclick='uploadFile();'" +
							"style='background:url(images/web_100.jpg) no-repeat; color:#eaeced; width:110px; height:23px; border:none; padding:2px 0px 0px 2px; '/>";

		////////////////////////////////////////////////date.js
		chooseYear="Click here to select Year";
		chooseMonth="Click here to select Month";
		chooseHour="Click here to select Hour";
		chooseMinute="Click here to select Minute";
		chooseSecond="Click here to select Second";
		turnFrontY="Previous Year";
		turnFrontM="Previous Month";
		turnAfterY="Next Year";
		turnAfterM="Next Month";
		topYear="-";
		topMonth="";
		dateMon="Mon";
		dateTue="Tue";
		dateWed="Wed";
		dateThu="Thu";
		dateFri="Fri";
		dateSat="Sat";
		dateSun="Sun";
		dateH=" Hr.";
		dateM=" Mins";
		dateS=" Sec";
		dateClear="Clear";
		dateToday="Now";
		dateClose="Close";
		////////////////////////////////////////////////end date.js
	}else if(type==1){//中文
		langPlay="播放";
		langPause="暂停";

		selAuto="自动录像";
		selManual="手动录像";
		selMotion="移动侦测";
		selProbe="探头报警";
		selLost="视频丢失";
		selHide="遮挡报警";
		selPIR="人体检测";

		$s("paramChnNum").innerHTML="通道号";
		$s("playSearchL").innerHTML="搜索本地";
		$s("playSearchD").innerHTML="搜索设备端";
		$s("playType").innerHTML="录像类型:";
		
		$s("searchStartTime").innerHTML="开始时间:";
		$s("searchEndTime").innerHTML="结束时间:";

		$s("btn_open").title="打开";
		$s("btn_play").title="播放";
		$s("btn_stop").title="停止";
		$s("btn_slow").title="慢播";
		$s("btn_fast").title="快播";
		//$s("previous").title="上一帧";
		$s("next").title="下一帧";
		$s("btn_audio").title="监听";
		$s("btn_cap").title="抓拍";
		$s("btn_full").title="全屏";
		
		$s("searchBtn").value="查询";

		////////////////////////////////////////////////date.js
		chooseYear="点击此处选择年";
		chooseMonth="点击此处选择月";
		chooseHour="点击此处选择时";
		chooseMinute="点击此处选择分";
		chooseSecond="点击此处选择秒";
		turnFrontY="向前翻 1 年";
		turnFrontM="向前翻 1 月";
		turnAfterY="向后翻 1 年";
		turnAfterM="向后翻 1 月";
		topYear="年";
		topMonth="月";
		dateMon="一";
		dateTue="二";
		dateWed="三";
		dateThu="四";
		dateFri="五";
		dateSat="六";
		dateSun="日";
		dateH=" 时";
		dateM=" 分";
		dateS=" 秒";
		dateClear="清除";
		dateToday="今天";
		dateClose="关闭";
		////////////////////////////////////////////////end date.js
	}else if(type==2){//韩文
		langPlay="재생";
		langPause="일시 정지";
		$s("imgPalyback").style.backgroundImage="url(Replayimages/hf_01_en.jpg)";
		$s("imgRecFile").style.backgroundImage="url(Replayimages/hf_13_en.jpg)";

		$s("tdSearch1").style.paddingLeft=15;
		$s("tdSearch2").style.paddingLeft=20;
		selAuto="자동 영상";
		selManual="수동 녹화";
		selMotion="모션감지 알람";
		selProbe="기웃기웃 신고";
		selLost="영상신호손실 알람";
		selHide="비디오차단 알람";
		selPIR="인체 검색";

		$s("paramChnNum").innerHTML="채널 번호";
		$s("playSearchL").innerHTML="로컬";
		$s("playSearchD").innerHTML="제품";
		$s("playType").innerHTML="녹화 종류";
		
		$s("searchStartTime").innerHTML="시작시간";
		$s("searchEndTime").innerHTML="종료시간";

		$s("btn_open").title="파일 찾기";
		$s("btn_play").title="재생";
		$s("btn_stop").title="정지";
		$s("btn_slow").title="느린 재생";
		$s("btn_fast").title="빠른 재생";
		//$s("previous").title="이전 프레임";
		$s("next").title="다음 프레임";
		$s("btn_audio").title="오디오";
		$s("btn_cap").title="영상 캡쳐";
		$s("btn_full").title="전체화면";
	
		$s("searchBtn").value="검색";
		$s("downloadDiv").innerHTML="<INPUT TYPE='button' id='downloadBtn' class='replayBtn' value='다운로드' onclick='uploadFile();'" +
							"style='background:url(images/web_100.jpg) no-repeat; color:#eaeced; width:110px; height:23px; border:none; padding:2px 0px 0px 2px; '/>";

		////////////////////////////////////////////////date.js
		chooseYear="년도를 선택하세요";
		chooseMonth="월을 선택하세요";
		chooseHour="시간을 선택 하세요";
		chooseMinute="분을 선택 하세요";
		chooseSecond="초를 선택 하세요";
		turnFrontY="전년";
		turnFrontM="전월";
		turnAfterY="내년";
		turnAfterM="익월";
		topYear="-";
		topMonth="";
		dateMon="Mon";
		dateTue="Tue";
		dateWed="Wed";
		dateThu="Thu";
		dateFri="Fri";
		dateSat="Sat";
		dateSun="Sun";
		dateH=" 시";
		dateM=" 분";
		dateS=" 초";
		dateClear="삭제";
		dateToday="현재";
		dateClose="닫기";
		////////////////////////////////////////////////end date.js

	}
}
