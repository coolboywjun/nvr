function changeTheLanguage(type){
	setLanguage(type);
	if(type==0){//英文
		$s("platform").innerHTML="JXJ Platform Setting";
		$s("platformFlag").innerHTML="Enable";
		$s("devicePUID").innerHTML="Device PUID";
		$s("pfCMSip").innerHTML="CMS IP";
		$s("pfMDSip").innerHTML="MDS IP";
		$s("pfCMSport").innerHTML="CMS Port";
		$s("pfMDSport").innerHTML="MDS Port";
		$s("pfCommunPro").innerHTML="Communication Protocol";

		$s("savesumbit").value="Save";
	}else if(type==1){//中文
		$s("platform").innerHTML="平台服务";
		$s("platformFlag").innerHTML="启用";
		$s("devicePUID").innerHTML="设备PUID";
		$s("pfCMSip").innerHTML="CMS IP";
		$s("pfMDSip").innerHTML="MDS IP";
		$s("pfCMSport").innerHTML="CMS 端口";
		$s("pfMDSport").innerHTML="MDS 端口";
		$s("pfCommunPro").innerHTML="视频流传输协议";

		$s("savesumbit").value="保存";
	}else if(type==2){//韩文
		$s("platform").innerHTML="플랫폼 서비스";
		$s("platformFlag").innerHTML="사용";
		$s("devicePUID").innerHTML="장비 PUID";
		$s("pfCMSip").innerHTML="CMS IP";
		$s("pfMDSip").innerHTML="MDS IP";
		$s("pfCMSport").innerHTML="CMS 포트";
		$s("pfMDSport").innerHTML="MDS 포트";
		$s("pfCommunPro").innerHTML="비디오 스트리밍 프로토콜";

		$s("savesumbit").value="저장";
		
	}
}
