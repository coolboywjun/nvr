function changeTheLanguage(type){
	setLanguage(type);
	if(type==0){//英文
		$s("disk").innerHTML="SD Card Setting";
		$s("diskInfo").innerHTML="SD Card Infomation";
		$s("diskChoice").innerHTML="Select";
		$s("diskNo").innerHTML="No.";
		$s("diskType").innerHTML="Disk Type";
		$s("diskState").innerHTML="Status";
		$s("diskTotal").innerHTML="Total Size(MB)";
		$s("diskSpare").innerHTML="Available Size(MB)";
		$s("isBackUp").innerHTML="Backup Disk";
		$s("fileType").innerHTML="File System Type";
		
		backupT="Yes";
		backupF="No";

		var btnFormat=$s("format");
		btnFormat.style.backgroundImage="url(images/web_100.jpg)";
		btnFormat.style.width="110px";
		btnFormat.value="Format";

		$s("refurbish").value="Refresh";
	}else if(type==1){//中文
		$s("disk").innerHTML="存储磁盘";
		$s("diskInfo").innerHTML="设备端存储信息";
		$s("diskChoice").innerHTML="选择";
		$s("diskNo").innerHTML="No.";
		$s("diskType").innerHTML="磁盘类型";
		$s("diskState").innerHTML="磁盘状态";
		$s("diskTotal").innerHTML="总容量(M)";
		$s("diskSpare").innerHTML="剩余容量(M)";
		$s("isBackUp").innerHTML="是否备份盘";
		$s("fileType").innerHTML="文件系统类型";
		
		backupT="是";
		backupF="否";

		$s("format").value="格式化";

		$s("refurbish").value="刷新";
	}else if(type==2){//韩文
		$s("disk").innerHTML="SD 카드 설정";
		$s("diskInfo").innerHTML="SD 카드 정보";
		$s("diskChoice").innerHTML="선택";
		$s("diskNo").innerHTML="No.";
		$s("diskType").innerHTML="디스크종류";
		$s("diskState").innerHTML="디스크상태";
		$s("diskTotal").innerHTML="총 크기 (MB)";
		$s("diskSpare").innerHTML="유효 크기 (MB)";
		$s("isBackUp").innerHTML="백업여부";
		$s("fileType").innerHTML="파일종류";
		
		backupT="예";
		backupF="아니오";

		var btnFormat=$s("format");
		//btnFormat.style.backgroundImage="url(images/web_100.jpg)";
		//btnFormat.style.width="110px";
		btnFormat.value="포멧";

		var refurbishBtn=$s("refurbish");
		refurbishBtn.style.backgroundImage="url(images/web_100.jpg)";
		refurbishBtn.style.width="110px";
		refurbishBtn.value="새로고침";
	}
}
