var wndType=1;
var alarmTypeMap;

function onVideoMenuClick(btnObj, flag){
	if(!isOcxObject){
		return;
	}
	var szID=btnObj.id;
	var nChannelno=0;
	if($p("chnCount").value>1){
		nChannelno=mainIpc.GetChnNumFromWnd(parent.wndIndex, parent.handleID);//获取当前选中窗口的通道号
	}
	if(mainIpc.IsStartStream(nChannelno, parent.handleID)!=1 && flag){
		btnObj.name="0";
		return;
	}
	
	if(szID=="btn_alert"){
		return;
	}

	var szName=btnObj.name;
	/*if(szName=="0")
		btnObj.name=1;
	else if(szName=="1")
		btnObj.name="0";*/

	if(szID=="btn_record"){//录像
		if(szName=="0"){
			mainIpc.StartREC(nChannelno, parent.handleID);
		}else{
			mainIpc.StopREC(nChannelno, parent.handleID);
		}
	}else if(szID=="btn_audio"){//监听
		if(szName=="0"){
			mainIpc.StartAudio(nChannelno, parent.handleID);
			//parent.totalAudioCount++;
		}else{
			mainIpc.StopAudio(nChannelno, parent.handleID);
			//parent.totalAudioCount--;
		}
	}else if(szID=="btn_talk"){//对讲
		if(szName=="0"){
			mainIpc.StartTalk(nChannelno, parent.handleID);
			//parent.totalTalkCount++;
		}else{
			mainIpc.StopTalk(nChannelno, parent.handleID);
			//parent.totalTalkCount--;
		}
	}else if(szID=="btn_capture"){//抓拍
		var picPath=mainIpc.Snapshot(parent.wndIndex, parent.handleID);
		if(picPath!=""){
			window.status=picPathMsg+picPath;
			//alert(picPathMsg+picPath);
		}
	}else if(szID=="btn_fullscreen"){//全屏
		mainIpc.FullScreen(-1, 1, parent.handleID);//控件全屏
	}else if(szID=="btn_replay"){//回放
		//window.open("replay.htm","window","dialogHeight:630px; dialogWidth:888px; "+
		//	"resizable=no; help=no; center:yes; status=no; scroll=no; toolbar=no; location=no; titlebar=no;");
		window.showModalDialog("replay.htm",window,"dialogHeight:630px; dialogWidth:888px; "+
			"resizable=no; help=no; center:yes; status=no; scroll=no; toolbar=no; location=no; titlebar=no;");
	}else if(szID=="btn_alert"){//手动清除报警
		mainIpc.ClearAlarm(nChannelno, parent.handleID);
		btnObj.src="images/web_31.jpg";
		btnObj.name="";
	}
}

var szIP;//登录设备的IP
var szDataPort;//设备参数设置端口
var szStreamPort;//设备视频流端口
var szUserName;//用户名
var szPwd;//密码

var isOcxObject=false;
function initMe(){
	if(document.getElementById("ipc").object == null){
		alert(ocx_msg1);
		return;
	}

///////////////////////////设置屏幕高度和宽度
	//高度
	$p("main").style.height=parent.document.body.clientHeight-103;
	parent.document.getElementById("leftpreview").style.height=parent.document.body.clientHeight-126;
	document.getElementById("videoId").style.height=parent.document.body.clientHeight-165;
	parent.document.getElementById("rightList").style.height=parent.document.body.clientHeight-159;

	//宽度
	var fullscreenWidth=parent.document.body.clientWidth;
	if(fullscreenWidth<1000){//宽度必须大于等于1000
		fullscreenWidth=1000;
	}
	$p("topbg").style.width=fullscreenWidth;
	$p("toplogo").style.width=fullscreenWidth;
	$p("main").style.width=fullscreenWidth;
	$p("mainMenuBtn").style.marginLeft=fullscreenWidth-180;
	var tempWidth=0;
	if($p("chnListFlag").value=="1"){//多通道
		tempWidth=184;
	}
	$p("container").style.width=fullscreenWidth-210-tempWidth;
	$p("rbannercontact").style.width=fullscreenWidth-230-tempWidth;
	$s("rbannercontact").style.width=fullscreenWidth-230-tempWidth;
///////////////////////////
}

var mainIpc;
function initVideoPlayer(){
	isOcxObject=true;
	$p("ip").value=(document.URL.split('//')[1]).split('/')[0].split(':')[0];
	$p("dataPort").value=GetCookidStr("dataPort");
	$p("streamPort").value=GetCookidStr("streamPort");
	$p("userName").value=GetCookidStr("loginUserName");
	$p("password").value=GetCookidStr("loginPassword");
	/*if(GetCookidStr("loginPassword")==null){
		$p("password").value="";
	}else{
		$p("password").value=decrypt(GetCookidStr("loginPassword"), "jxj");
	}*/
	/*$p("ip").value="192.168.71.119";
	$p("dataPort").value="3321";
	$p("streamPort").value="7554";
	$p("userName").value="admin";
	$p("password").value="admin";*/

	szIP= $p("ip").value;
	szDataPort= $p("dataPort").value;
	szStreamPort= $p("streamPort").value;
	szUserName= $p("userName").value;
	szPwd = $p("password").value;

	//alert(szIP+" "+szDataPort+" "+szStreamPort+" "+szUserName+" "+szPwd);
	if(szIP == "" || szDataPort == "" || szStreamPort == "" || szUserName == "" || szIP==null || szDataPort==null|| szStreamPort==null|| szUserName==null){
		parent.location='login.asp';
		return;
	}
	szDataPort=parseInt(szDataPort);
	szStreamPort=parseInt(szStreamPort);
	mainIpc=document.getElementById("ipc");

	alarmTypeMap=new HashMap();
	alarmTypeMap.put(0, 0);
	alarmTypeMap.put(1, 0);
	alarmTypeMap.put(2, 0);
	alarmTypeMap.put(3, 0);

	openVideo();
}

function openVideo(){
	var screenFormat='{"type":0,"count":4,"splitData":'
					+'[{"id":1, "x":1, "y":1, "wndCount":-1}, {"id":4, "x":2, "y":2, "wndCount":-1}, {"id":9, "x":3, "y":3, "wndCount":-1}, {"id":16, "x":4, "y":4, "wndCount":-1}]'
					+'}';
	mainIpc.SetSplitDef(screenFormat);//定义分屏格式
	try{
		if(mainIpc.Login(szIP, szStreamPort, szDataPort,  szUserName, szPwd)==0){
			alert(ocx_msg2);
			return;
		}
	}catch(e){alert(ocx_msg2);parent.location='login.asp';return;}
	var tempCapability=mainIpc.getJSONDataForParam('{"type":"capability"}' , 0, parent.handleID);//获取能力集
	//alert(tempCapability);
	try{
		parent.systemCapability=eval("("+tempCapability+")");
	}catch(e){parent.systemCapability=null;parent.hasCapability=false;}
	if(parent.systemCapability.Req_Err_NO!=0){
		parent.systemCapability=null;
		parent.hasCapability=false;
	}
	parent.systemDevInfo=mainIpc.getJSONDataForParam('{"type":"sys_info"}' , 0, parent.handleID);//获取设备系统信息
	try{
		parent.systemDevInfo=eval("("+parent.systemDevInfo+")");
	}catch(e){parent.systemDevInfo=null;}
	if(parent.systemDevInfo.Req_Err_NO!=0){
		parent.systemDevInfo=null;
	}
	setDevCapability();
	parent.loginSuccess=true;
	$s("multiImg1").click();
	if($p("chnCount").value=="1"){//单通道ipc，则播放视频预览
		parent.selectChnNum=0;
		var tempStreamType=GetCookidStr("STREAMTYPE");
		if(tempStreamType==null || tempStreamType==""){
			tempStreamType=0;
		}
		mainIpc.SetLocalInfo(tempStreamType, 3, parent.handleID);//设置码流
		SetCookidStr("STREAMTYPE",tempStreamType,7);
		mainIpc.StartStream(0, 0,  parent.handleID);
	}
	//mainIpc.StartStream(0, 0,  parent.handleID);
}

function setDevCapability(){
	if(parent.systemCapability==null){
		return;
	}
	if(parent.systemCapability.analysisFlag==0){
		$p("menu7").style.display="none";
	}
	if(parent.systemCapability.storageFlag==0){
		$p("menu8").style.display="none";
	}
	if(parent.systemCapability.wifiFlag==1){
		$p("sub3-8").style.display="block";
	}
	if(parent.systemCapability.threeGFlag==1){
		$p("sub3-9").style.display="block";
	}
	if(parent.systemCapability.platformFlag==0){
		/*$p("sub3-10").style.display="none";
		$p("sub3-11").style.display="none";
		$p("sub3-12").style.display="none";*/
	}else{
		if(parent.systemCapability.platformType>0){
			var typeTemp=toBin(parent.systemCapability.platformType)+"";
			var typeTempLength=typeTemp.length;
			var type="";
			for(var i=typeTempLength-1;i>=0;i--){
				type+=typeTemp.charAt(i);
			}
			var marginVal=20-typeTempLength;
			if(marginVal>0){
				for(var i=1;i<=marginVal;i++){
					type+="0";
				}
			}
			//alert(type);
			if(type.charAt(0)=="1"){//JXJ
				$p("sub3-10").style.display="block";
			}
			if(type.charAt(1)=="1"){//ZSYH
				$p("sub3-11").style.display="block";
			}
			if(type.charAt(2)=="1"){//HXHT
				$p("sub3-12").style.display="block";
			}
			if(type.charAt(3)=="1"){//GB28181
				$p("sub3-13").style.display="block";
			}
			if(type.charAt(4)=="1"){//HUAWEI
				$p("sub3-14").style.display="block";
			}
		}
	}
	if(parent.systemCapability.protocolType>0){
		var typeTemp=toBin(parent.systemCapability.protocolType)+"";
		var typeTempLength=typeTemp.length;
		var type="";
		for(var i=typeTempLength-1;i>=0;i--){
			type+=typeTemp.charAt(i);
		}
		var marginVal=20-typeTempLength;
		if(marginVal>0){
			for(var i=1;i<=marginVal;i++){
				type+="0";
			}
		}
		if(type.charAt(3)=="1"){//GB28181
			$p("sub3-13").style.display="block";
		}
	}
	if(parent.systemCapability.networkDisk==1){//网络磁盘
		$p("sub8-3").style.display="block";
	}
	if(parent.systemCapability.serial485==0 && parent.systemCapability.serial232==0){//串口设置
		$p("sub5-1").style.display="none";
	}
}

function showChnList(obj){//显示隐藏通道列表
	if(obj.value=="1"){
		obj.value="0";
		$p("rightChnList").style.display="none";
		obj.title=parent.chnListmsg2;
		obj.src="images/chnList/03_15.jpg";
	}else{
		obj.value="1";
		$p("rightChnList").style.display="block";
		obj.title=parent.chnListmsg1;
		obj.src="images/chnList/01_15.jpg";
	}
	parent.srcAvailWidth=0;
}

function setMultiImg(obj, srcPath){//设置分屏图片样式
	for(var i=1;i<=4;i++){
		$s("multiImg"+i).src=$s("multiImg"+i).value;
		$s("multiImg"+i).name="";
	}
	obj.src=srcPath;
	obj.name='1';
	mainIpc.FullScreen(-1, 8, parent.handleID);//切换时强制退出控件内全屏
}

function escKeyDownPreview(){
	/*if (event.keyCode == 27){//esc键，退出 全屏
		var ctrlType=mainIpc.GetFullScreenType(parent.handleID);//获取全屏操作类型
		if(ctrlType==1 || ctrlType==3){
			mainIpc.FullScreen(-1, 8, parent.handleID);//退出全屏
			mainIpc.FullScreen(-1, 4, parent.handleID);
		}
	}*/
}