
//�����¼�
function escKeyDownReplay(){
	if (event.keyCode == 27){//esc�����˳�/���� ȫ��
		ipc.FullScreen();
	}
}

//�Ƚ�����
function checkCfmDate(){
	var startDate = $s("startDate").value;
	var endDate = $s("endDate").value;
	
	if(startDate !=""&&!IsLongDateTime(startDate)){
		alert(date_validate_msg);
		return false;
	}
	if(endDate !=""&&!IsLongDateTime(endDate)){
		alert(date_validate_msg);
		return false;
	}
	if(startDate=="" || trim(startDate)=="" || endDate=="" || trim(endDate)==""){
		alert(date_validate_msg);
		return false;
	}
	var startYear=parseInt(startDate.split(" ")[0].split("-")[0]);
	if(startYear<=1970){//ʱ�䲻��С��1970��
		alert(date_year_msg);
		return false;
	}
	var endYear=parseInt(endDate.split(" ")[0].split("-")[0]);
	if(endYear>=2038){
		alert(date_year_msg1);
		return false;
	}
	if(startDate!=""&&endDate!=""){
		if(!cmpDate(startDate,endDate)){
			alert(b_e_date_msg);
			return false;
		}else 
			return true;
	}
	return true;
}

//��ȡʱ�����1970��1��1�յ�����
function getDateTime(dateValue){
	var a=dateValue.split(" ");
	var b=a[0].split("-");
	var c=a[1].split(":");
	var d=new Date(b[0],b[1]-1,b[2],c[0],c[1],c[2]);
	//alert(d.toLocaleString());
	return d.getTime()/1000;
}

var	startyear	= 1970;
var	startmonth	= 1;
var	startday	= 1;
var	milliDate	= new Date();
//���ݺ�������ȡʱ������
function millisecondsStrToDate(str){
	milliDate.setFullYear(startyear, startmonth, startday);
	milliDate.setTime(0);
	milliDate.setMilliseconds(str);
	var d = milliDate.getFullYear() + "-" + (milliDate.getMonth()+1) + "-" + milliDate.getDate();
	var t = (milliDate.getHours()<10?"0":"")+milliDate.getHours() + 
		":" + (milliDate.getMinutes()<10?"0":"")+milliDate.getMinutes() + 
		":" + (milliDate.getSeconds()<10?"0":"")+milliDate.getSeconds();
	return new Array(t, d+" "+t);
}