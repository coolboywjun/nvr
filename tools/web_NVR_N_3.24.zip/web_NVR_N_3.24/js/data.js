function HashMap(){
	/**Map大小**/
	var size=0;
	/**对象**/
	var entry=new Object();
	/**Map的存put方法**/
	this.put=function(key,value){
		if(!this.containsKey(key)){
			size++;
			entry[key]=value;
		}
	}
	/**Map取get方法**/
	this.get=function(key){
		return this.containsKey(key) ? entry[key] : null;
	}
	/**Map删除remove方法**/
	this.remove=function(key){
		if(this.containsKey(key) && ( delete entry[key] )){
			size--;
		}
	}
	/**是否包含Key**/
	this.containsKey= function (key){
		return (key in entry);
	}
	/**是否包含Value**/
	this.containsValue=function(value){
		for(var prop in entry) {
			if(entry[prop]==value){
				return true;
			}
		}
		return false;
	}
	/**所有的Value**/
	this.values=function(){
		var values=new Array();
		for(var prop in entry) {
			values.push(entry[prop]);
		}
		return values;
	}
	/**所有的 Key**/
	this.keys=function(){
		var keys=new Array();
		for(var prop in entry) {
			keys.push(prop);
		}
		return keys;
	}
	/**Map size**/
	this.size=function(){
		return size;
	}
	/**清空Map**/
	this.clear=function(){
		size=0;
		entry=new Object();
	}
}

var mapStreamParma1="主码流";
var mapStreamParma2="次码流";
var mapStreamParma3="三码流";
var mapStreamParma4="四码流";
var mapStreamParma5="五码流";

var mapParma1="正在使用";
var mapParma2="已挂载";
var mapParma3="未挂载";

var mapParam4="未知";
var mapParam5="有线";
var mapParam6="无线";

/*var mapParma7="黑色";
var mapParma8="白色";
var mapParma9="蓝色";
var mapParma10="黄色";*/


function setSelectParamToEn(langType){
	if(langType==0){
		mapStreamParma1="First Stream";
		mapStreamParma2="Second Stream";
		mapStreamParma3="Third Stream";
		mapStreamParma4="Fourth Stream";
		mapStreamParma5="Fifth Stream";

		mapParma1="Is being used";
		mapParma2="Mounted";
		mapParma3="Unmounted";

		mapParam4="Unknown";
		mapParam5="Wired";
		mapParam6="Wireless";

		/*mapParma7="Black";
		mapParma8="White";
		mapParma9="Blue";
		mapParma10="Yellow";*/
	}else if(langType==1){
		mapStreamParma1="主码流";
		mapStreamParma2="次码流";
		mapStreamParma3="三码流";
		mapStreamParma4="四码流";
		mapStreamParma5="五码流";

		mapParma1="正在使用";
		mapParma2="已挂载";
		mapParma3="未挂载";

		mapParam4="未知";
		mapParam5="有线";
		mapParam6="无线";

		/*mapParma7="黑色";
		mapParma8="白色";
		mapParma9="蓝色";
		mapParma10="黄色";*/
	}else if(langType==2){//韩文
		mapStreamParma1="첫 번째 스트림";
		mapStreamParma2="두 번째 스트림";
		mapStreamParma3="세 번째 스트림";
		mapStreamParma4="네 번째 스트림";
		mapStreamParma5="다섯 번째 스트림";

		mapParma1="사용되고 있음";
		mapParma2="장착된";
		mapParma3="장착되지 않음";

		mapParam4="알려지지 않은";
		mapParam5="유선";
		mapParam6="무선";

		/*mapParma7="검은색";
		mapParma8="흰색";
		mapParma9="파란색";
		mapParma10="노란색";*/
	}
}

var streamTypeMap;
var videoTypeMap;
var audioTypeMap;
var resolutionMap;
var bitRateTypeMap;
var videoFormatMap;
var verifyArray;
var osdColorMap;
var diskTypeMap;
var diskStatusMap;
var diskFileTypeMap;
var networkTypeMap;
function setSelectMap(){
	streamTypeMap	=new HashMap();		//码流类型
	streamTypeMap.put("0", mapStreamParma1);
	streamTypeMap.put("1", mapStreamParma2);
	streamTypeMap.put("2", mapStreamParma3);
	streamTypeMap.put("3", mapStreamParma4);
	streamTypeMap.put("4", mapStreamParma5);

	/*osdColorMap		=new HashMap();		//osd字体颜色
	osdColorMap.put("0", mapParma7);
	osdColorMap.put("1", mapParma8);
	osdColorMap.put("2", mapParma9);
	osdColorMap.put("3", mapParma10);*/
	
	diskStatusMap	=new HashMap();		//磁盘状态
	diskStatusMap.put("0", mapParma1);
	diskStatusMap.put("1", mapParma2);
	diskStatusMap.put("2", mapParma3);

	videoTypeMap	=new HashMap();		//视频编码类型
	videoTypeMap.put("0", mapParam4);
	videoTypeMap.put("11", "H264");
	videoTypeMap.put("12", "MPEG4");

	audioTypeMap	=new HashMap();		//音频编码类型
	audioTypeMap.put("0", mapParam4);
	audioTypeMap.put("21", "G711A");
	audioTypeMap.put("22", "G711U");

	resolutionMap	=new HashMap();		//分辨率
	resolutionMap.put("1", "QCIF");
	resolutionMap.put("2", "CIF");
	resolutionMap.put("3", "HD1");
	resolutionMap.put("4", "D1");
	resolutionMap.put("32", "QQVGA");
	resolutionMap.put("33", "QVGA");
	resolutionMap.put("34", "VGA");
	resolutionMap.put("35", "SVGA");
	resolutionMap.put("36", "UXGA");
	resolutionMap.put("64", "720P");
	resolutionMap.put("65", "960p");
	resolutionMap.put("66", "1080P");

	/*bitRateTypeMap	=new HashMap();		//位率类型
	bitRateTypeMap.put("0", "ABR");
	bitRateTypeMap.put("1", "CBR");
	bitRateTypeMap.put("2", "VBR");
	bitRateTypeMap.put("3", "FixQP");
	bitRateTypeMap.put("4", "BUTT");*/
	
	/*videoFormatMap	=new HashMap();		//制式
	videoFormatMap.put("0", "PAL");
	videoFormatMap.put("0", "NTSC");*/

	diskTypeMap		=new HashMap();		//磁盘类型
	diskTypeMap.put("0", "SATA");
	diskTypeMap.put("1", "USB");
	diskTypeMap.put("2", "ISCSI");
	diskTypeMap.put("3", "NFS");
	diskTypeMap.put("4", "SD");

	diskFileTypeMap	=new HashMap();		//磁盘文件系统类型
	diskFileTypeMap.put("0", "FAT 16");
	diskFileTypeMap.put("1", "FAT 32");
	diskFileTypeMap.put("2", "NTFS");
	diskFileTypeMap.put("3", "EXT");
	diskFileTypeMap.put("4", "EXT 2");
	diskFileTypeMap.put("5", "EXT 3");

	/*networkTypeMap	=new HashMap();		//网卡类型
	networkTypeMap.put("0", mapParam5);
	networkTypeMap.put("1", "WIFI");
	networkTypeMap.put("2", "3G");*/
}


/*
[TIME_ZONE_DEF]
ITEM_COUNT=26
ITEM_000 = +13 (GMT+13:00) 努库阿洛法汤加
ITEM_001 = +12 (GMT+12:00) 斐济，奥克兰，惠灵顿，新西兰，斐济，堪察加半岛
ITEM_002 = +11 (GMT+11:00) 所罗门群岛，新喀里多尼亚和太平洋中部
ITEM_003 = +10 (GMT+10:00) 关岛，莫尔兹比港，西太平洋，霍巴特塔斯马尼亚岛
ITEM_004 = +09 (GMT+09:00) 大阪，札幌，东京，汉城，韩国，雅库茨克
ITEM_005 = +08 (GMT+08:00) 北京，珀斯西部澳大利亚，吉隆坡，台北
ITEM_006 = +07 (GMT+07:00) 曼谷，河内，雅加达，南洋，克拉斯诺亚尔斯克北
ITEM_007 = +06 (GMT+06:00) 阿拉木图，新西伯利亚，中亚北部，阿斯塔纳
ITEM_008 = +05 (GMT+05:00) 伊斯兰堡，卡拉奇，西塔什干
ITEM_009 = +04 (GMT+04:00) 阿布扎比马斯喀特，阿拉伯半岛，巴库，第比利斯
ITEM_010 = +03 (GMT+03:00) 莫斯科，圣彼得堡，伏尔加格勒，俄罗斯，内罗毕，东非
ITEM_011 = +02 (GMT+02:00) 赫尔辛基，布加勒斯特，基辅，雅典，耶路撒冷，开罗
ITEM_012 = +01 (GMT+01:00) 柏林，罗马，马德里，布鲁塞尔，阿姆斯特丹，哥本哈根，伯尔尼
ITEM_013 = +00 (GMT+00:00) 伦敦，都柏林，爱丁堡，里斯本
ITEM_014 = -01 (GMT-01:00) 佛得角，佛得角群岛，亚速尔群岛
ITEM_015 = -02 (GMT-02:00) 大西洋
ITEM_016 = -03 (GMT-03:00) 格陵兰，布宜诺斯艾利斯，乔治敦大学，南美国东
ITEM_017 = -04 (GMT-04:00) 圣地亚哥，南太平洋
ITEM_018 = -05 (GMT-05:00) 印第安娜（东部），美国东岸，波哥大，利马，基多）
ITEM_019 = -06 (GMT-06:00) 中央萨斯喀彻温省，加拿大，美国，墨西哥市
ITEM_020 = -07 (GMT-07:00) 奇瓦瓦，拉巴斯，美国和加拿大山
ITEM_021 = -08 (GMT-08:00) 太平洋标准时间（美国和加拿大）；蒂华纳太平洋
ITEM_022 = -09 (GMT-09:00) 阿拉斯加
ITEM_023 = -10 (GMT-10:00) 夏威夷
ITEM_024 = -11 (GMT-11:00) 中途群岛，萨摩亚群岛
ITEM_025 = -12 (GMT-12:00) 日界线国际日期变更线以西

[JNET_PU_TYPE]
ITEM_COUNT=4
ITEM_000=000 DVR
ITEM_001=001 DVS
ITEM_002=002 IPC
ITEM_003=003 其他

[JNET_PU_SUB_TYPE]
ITEM_COUNT=3
ITEM_000=000 枪机
ITEM_001=001 红外
ITEM_002=002 半球

[JNET_PROTOCOL_TYPE]
ITEM_COUNT=2
ITEM_000=000 TCP
ITEM_001=001 UDP

[JNET_NETWORK_TYPE]
ITEM_COUNT=3
ITEM_000=000 以太网
ITEM_001=001 WIFI
ITEM_002=002 3G

[JNET_MEDIA_TYPE]
ITEM_COUNT=5
ITEM_000=000 实时音视频流
ITEM_001=001 实时抓拍图片
ITEM_002=002 历史音视频(点播)
ITEM_003=003 历史音视频(下载)
ITEM_004=004 历史图片

[JNET_VIDEO_FORMAT]
ITEM_COUNT=2
ITEM_000=000 PAL
ITEM_001=001 NTSC

[JNET_BIT_RATE]
ITEM_COUNT=5
ITEM_000=000 ABR
ITEM_001=001 CBR
ITEM_002=002 VBR
ITEM_003=003 FIXQP
ITEM_004=004 BUTT

[JNET_DISK_TYPE]
ITEM_COUNT=5
ITEM_000=000 SATA
ITEM_001=001 USB
ITEM_002=002 ISCSI
ITEM_003=003 NFS
ITEM_004=004 SD

[JNET_DISK_STATUS]
ITEM_COUNT=3
ITEM_000=000 正在使用
ITEM_001=001 已经挂载
ITEM_002=002 未挂载

[JNET_WEEK_DAY]
ITEM_COUNT=8
ITEM_000=000 星期日
ITEM_001=001 星期一
ITEM_002=002 星期二
ITEM_003=003 星期三
ITEM_004=004 星期四
ITEM_005=005 星期五
ITEM_006=006 星期六
ITEM_007=007 每天

[JNET_SYS_FILE_TYPE]磁盘
ITEM_COUNT=6
ITEM_000=000 FAT 16
ITEM_001=001 FAT 32
ITEM_002=002 NTFS
ITEM_003=003 EXT
ITEM_004=004 EXT 2
ITEM_005=005 EXT 3

[JNET_ALARM_TYPE]
ITEM_COUNT=4
ITEM_000=000 移动报警
ITEM_001=001 丢失报警
ITEM_002=002 遮挡报警
ITEM_003=003 IO报警

[JNET_ACTION_TYPE]
ITEM_COUNT=2
ITEM_000=000 打包
ITEM_001=001 未打包

[JNET_RESOLUTION_TYPE]
ITEM_COUNT=12
ITEM_000=1  QCIF
ITEM_001=2  CIF
ITEM_002=3  HD1
ITEM_003=4  D1
ITEM_004=32 QQVGA
ITEM_005=33 QVGA
ITEM_006=34 VGA
ITEM_007=35 SVGA
ITEM_008=36 UXGA
ITEM_009=64 720P
ITEM_010=65 960P
ITEM_011=66 1080P

[JNET_AV_CODEC_TYPE]
ITEM_COUNT=5
ITEM_000=000 未知
ITEM_001=011 H264
ITEM_002=012 MPEG4
ITEM_003=021 G711A
ITEM_004=022 G711U

[JNET_AUDIO_INPUT_MODE]
ITEM_COUNT=2
ITEM_000=000 MIC
ITEM_001=001 线输入

[JNET_ENCODE_LEVEL]
ITEM_COUNT=3
ITEM_000=000 BaseLine
ITEM_001=001 Main
ITEM_002=002 High






设备能力集
devType			设备类型
chnCount		通道数
networkType		网卡类型
streamCount		码流数





通道能力集
videoType		视频编码类型
audioType		音频编码类型
resolution		分辨率
videoFormat		制式
bitRateType		位率类型
streamCount		码流类型
alarmType		报警类型











*/

