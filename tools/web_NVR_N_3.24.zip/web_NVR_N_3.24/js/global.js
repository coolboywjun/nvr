

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var chnListmsg1="点击隐藏列表";//
var chnListmsg2="点击显示列表";//

var picPathMsg="图片抓拍成功！路径为：";				//
var capabilityMsg="获取能力集失败，无法进行参数设置！";	//

var frate_msg="帧率必须是整数";							//
var frame_interval_msg="I 帧间隔必须是整数";			//
var bitrate_msg="码率必须是整数";						//

var sys_mod_msg1="设备名称不能为空！";					//
var sys_mod_msg2="数据保存成功！";						//
var sys_mod_msg4="升级中，请稍后···";					//
var sys_mod_msg5="保存成功后会重新登录，确认需要保存吗？";

var gsq_msg1="检查：小时和分钟必须是数字！";			//
var gsq_msg2="小时不能超过23！";						//
var gsq_msg3="分钟不能超过59！";						//
var analysis_msg1="检查：时间必须是数字！";				//
var analysis_msg2="秒数不能超过59！";					//

var date_msg1="开始时间不能大于结束时间！";				//

var preset_msg="预置号不能为0，请选择预置号！";			//

var ocx_msg1="未找到控件。请正确安装控件后重新访问！";	//
var ocx_msg2="控件登录失败！";							//

var num_msg="请输入数字";								//
var path_not_null="配置路径不能为空！";					//
var conf_success="配置成功！";							//

var error_num="错误码：";								//
var get_data_error="获取数据失败！";					//
var saveError="操作失败或保存数据失败";					//
var stream_data_error="获取码流类型失败！";				//
var has_illegal_letter="无效字符或字符串！";			//
var getDataError="获取数据失败！";						//
var port_msg="端口必须是小于65536的整数";				//
var ip_msg="请输入正确的IP地址！";						//
var isNotNet="ip和网关不在同一个网段，确认要保存吗？";	//
var submask_msg="请输入正确的子网掩码！";				//
var gateway_msg="请输入正确的默认网关！";				//
var dns1_msg="请输入正确的首选DNS服务器！";				//
var dns2_msg="请输入正确的备选DNS服务器";				//

var pppoe_msg1="帐号密码不能为空！";					//

var ftp_msg1="请输入正确的服务器地址！";				//
var ftp_msg2="请输入正确的服务端口！";					//

var email_msg1="请输入正确的SMTP服务器！";				//
var email_msg2="请输入正确的SMTP端口！";				//
var email_msg3="请输入正确的email地址！";				//

var ddns_msg1="请输入正确的主机域名！";
var upnp_msg1="请输入正确的主机地址！";					//
var upnp_msg2="请输入正确的数据映射端口！";				//
var upnp_msg3="请输入正确的HTTP映射端口！";				//
var upnp_msg4="请输入正确刷新间隔时间！";				//
var refreshTime_msg="刷新时间间隔为大于0且小于49的正整数！";//
var date_validate_msg="请输入正确的时间格式:yyyy-MM-dd HH:mm:ss";//
var b_e_date_msg="开始时间不能大于结束时间！";			//

var user_pwd_msg1="用户密码不能为空!且长度不能大于16!";	//
var user_pwd_msg2="输入的密码含有非法字符!";			//
var user_pwd_msg3="两次输入的密码不一致!";				//
var user_pwd_msg4="输入密码有误！";						//
var user_pwd_msg5="修改密码失败！";						//

var file_msg="请选择文件";								//
var fileFormat="文件类型不匹配，请选择正确的(.bin)升级文件！";//
var file_upg_Format="文件类型不匹配，请选择正确的(.upg)升级文件！";//
var defectMsg1="坏点检测成功。";						//
var defectMsg2="坏点检测失败，或超时";					//
var defectMsg3="光圈检测成功。";						//
var defectMsg4="光圈检测失败，或超时";					//
var update_install_msg="正在安装，请等待...";			//
var update_success_msg="升级成功！";					//
var update_fail_msg="升级失败！";						//
var default_ipc="确认要恢复出厂默认设置吗？";			//
var reboot_ipc="确认要重启设备吗？";					//
var correcting_dev="确认要校正吗？";					//
var format_msg="请选择需要格式化的磁盘！";				//
var confirm_format_msg="格式化后，会清除所有数据，确认要格式化吗？";//
var format_success="格式化成功！";						//
var format_faild="系统超时或磁盘正在录像，格式化失败！";						//
var platform_msg1="设备PUID不能为空。";					//
var platform_msg2="最大连接数必须是大于1或小于65的整数。";//

var alarmMsg="侦测间隔时间必须为正整数或零！";			//

var wifi_msg1="操作成功！";								//
var wifi_msg2="已断开连接";								//
var wifi_msg3="请选择一个无线网络";						//
var wifi_msg4="秒后页面重新刷新";				//
var wifi_msg5="连接失败：密码错误或网络异常！";

var noPlayFile="无播放文件！";
var date_year_msg="时间必须大于1970年！";
var date_year_msg1="时间必须小于2038年！";
var replay_file_upload="请选择下载文件！";
var replay_faild="失败";
var replay_hasDownLoadFila="当前有文件正在下载，继续操作会导致当前下载文件终止！\r\n\r\n                确认要重新查询吗？";
var replay_operate_faild = "操作失败！";
var replay_isOnload_msg = "页面控件未正常加载，点击确定后，请重新操作！";
var replay_isFile = "文件错误!";
var replay_no_file = "无播放文件！请点击\"打开\"并选择播放文件播放，或者搜索出录像文件后双击录像文件进行播放！";
var replay_isPlay = "当前文件正在播放！";
var no_record_file = "该时间间隔内没有录像资料或正在解除休眠,请稍后再试";

var sys_mod_isUpdate = "当前有数据被修改，保存成功后，页面会关闭，请重新登录。确认要继续操作吗？";
var sys_mod_save_success = "数据保存成功！确定后，页面3秒钟后关闭，请重新登录！";
var browser_error="未知错误！当前页面将强行关闭。请打开浏览器重新登录！";

var video_time_msg = "请输入5-255的整数";

var gb28181Msg1="设备ID不能为空.";
var gb28181Msg2="设备密码不能为空.";
var gb28181Msg3="服务器ID不能为空.";

var changeMenuMsg1="当前有通道正在录像，或开启语音对讲功能，跳转到参数页面会强制终止操作。确认跳转？";
var changeMenuMsg2="当前设备正在录像，或开启语音对讲功能，跳转到参数页面会强制终止操作。确认跳转？";
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////





var main_flow_msg="主码流";
var sub_flow_msg="次码流";

var date_msg="日期格式不正确";
var time_msg="时间格式不正确";
var param_msg="参数错误";
var user_name_msg2="输入的用户名含有非法字符!";

var create_xmlhttp_msg="提示 :( 创建Msxml2.XMLHTTP失败)";
var send_xmlhttp_msg="注意: (Msxml2.XMLHTTP发送数据失败，请确认IE版本是否为5.5或更高!)";
var create_domdoc_msg="注意: (创建Msxml2.DOMDocument失败，请确认IE版本是否为5.5或更高!)";
var xml_error_msg="XML数据有误,解析失败!";
var url_error_msg="URL错误";

var macaddr_msg="请输入正确的物理地址！";






var bf_hour_msg="布防时间段 \"时\" 不能超过24！";
var bf_minute_msg="布防时间段 \"分\" 不能超过60！";

var stop_rec_msg="当前有磁盘正在录像，确认要停止录像吗？";
var sys_outtime="系统超时，请重新操作！";
var isRec_msg="当前有磁盘正在录像，无法格式化！";
var store_policy_msg="改变码流保存后，必须重启设备才有会有效。确认要保存吗？";

var CreateXMLHTTP	= "提示 :( 创建Msxml2.XMLHTTP失败)";
var returnXMLfail	= "返回的XML数据有误,解析失败!";
var URLerror		= "URL错误";
var SendXMLHTTP		= "注意: (Msxml2.XMLHTTP发送数据失败，请确认IE版本是否为5.5或更高!)";
var CreateDOMDoc	= "注意: (创建Msxml2.DOMDocument失败，请确认IE版本是否为5.5或更高!)";







var isRecording="当前正在录像，确认要跳转到参数设置页面吗？确认后会强制关闭！";
var isTalking="当前已开启设备端语音对讲功能，确认要跳转到参数设置页面吗？确认后会强制关闭！";
var isAudioing="当前已启用音频功能，确认要跳转到参数设置页面吗？确认后会强制关闭！";

var ocx_ctl_error="未安装控件或加载控件失败！控件下载请到登录页面！";


var msg_3g_1="已开启3G";
var msg_3g_2="已关闭3G";

//设置语言
function setLanguage(type){
	if(type==0){
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		chnListmsg1="Click to hide list.";
		chnListmsg2="Click to display list.";

		picPathMsg="Pictures capture success! The path for the: ";
		capabilityMsg="Access capability set failure, unable to set parameters.";
		
		frate_msg="Frame rate must be an integer";
		frame_interval_msg="I frame space must be an integer";
		bitrate_msg="Bit rate must be an integer";

		sys_mod_msg1="Please input Device Type.";
		sys_mod_msg2="Data Save Successful.";
		sys_mod_msg4="Upgrading, Please wait...";
		sys_mod_msg5="You will re-login after changing the Password, Continue?";

		gsq_msg1="Check: hours and minutes must be a number.";
		gsq_msg2="Hours can not be over 23.";
		gsq_msg3="Minutes can not be over 59.";
		analysis_msg1="Check: time must be a number.";
		analysis_msg2="Seconds can not be over 59.";

		date_msg1="Start Time cannot be later than End Time.";

		preset_msg="Preset number cannot be 0, please select a preset number.";

		ocx_msg1="ActiveX OCX was not found. Please correct installation and re-visit.";
		ocx_msg2="ActiveX OCX login failed.";
		
		num_msg="Please enter the number";
		path_not_null="Please input Saving Path.";
		conf_success="Configuration Successful.";

		error_num="Error code: ";
		get_data_error="Failed to get data.";
		saveError="The operation failed or save the data failed";
		stream_data_error="Failed to get the type of stream";
		has_illegal_letter="Invalid Characters.";
		getDataError="Failed to get data.";
		port_msg="Port must be an integer less than 65536";
		ip_msg="Please input correct IP Address.";
		isNotNet="IP and Gateway are not on the same network segment, Save?";
		submask_msg="Please input correct Subnet Mask.";
		gateway_msg="Please input correct Default Gateway.";
		dns1_msg="Please input correct Main DNS.";
		dns2_msg="Please input correct Sub DNS.";
		
		pppoe_msg1="Please input User Name and Password.";

		ftp_msg1="Please input correct Server IP.";
		ftp_msg2="Please input correct Server Port.";

		email_msg1="Please input correct SMTP Server.";
		email_msg2="Please input correct SMTP Port.";
		email_msg3="Please input correct Email address.";
		
		ddns_msg1="Please input correct Domain.";
		upnp_msg1="Please input correct Sever IP.";
		upnp_msg2="Please input correct Device Port.";
		upnp_msg3="Please input correct Web Port.";
		upnp_msg4="please the correct Update Cycle.";
		refreshTime_msg="Update Cycle must be an integer, from 1 to 49.";
		date_validate_msg="Please input the correct time format: yyyy-MM-dd HH:mm:ss";
		b_e_date_msg="Start Time cannot be later than End Time.";
		
		user_pwd_msg1="Please enter password, less than 16.";
		user_pwd_msg2="Invalid Characters for Password Input.";
		user_pwd_msg3="Inconsistent Password Input.";
		user_pwd_msg4="Incorrect Password Input.";
		user_pwd_msg5="Update password faild.";
		
		file_msg="Please select a file";
		fileFormat="File type not match, please choose the correct ( .Bin ) upgrade file.";
		file_upg_Format="File type not match, please choose the correct ( .upg ) upgrade file.";
		defectMsg1="Defective Pixel detecting success";
		defectMsg2="Defective Pixel detecting failure, or timeout";
		defectMsg3="Iris detecting success";
		defectMsg4="Iris detecting failure, or timeout";
		login_msg="Disconnected";
		update_send_msg="Sending, Please wait...";
		update_install_msg="Installing, Please wait...";
		update_success_msg="Upgrade Successful.";
		update_fail_msg="Upgrade Unsuccessful.";
		default_ipc="Are you sure to default setting?";
		reboot_ipc="Sure you want to reboot the device?";
		correcting_dev="Confirm that you want to correct it?";
		format_msg="Please choose the SD Card to format.";
		confirm_format_msg="All data will be cleared after formatting, Continue?";
		format_success="Format successful."
		format_faild="System timeout or disk is video, format failure!";
		platform_msg1="Device PUID cannot be empty.";
		platform_msg2="The maximum number of connections must be greater than 1 or less than65 integer.";

		alarmMsg="Detection interval must be a positive integer or zero.";

		wifi_msg1="The success of operation";
		wifi_msg2="Disconnected success.";
		wifi_msg3="Please select a wireless network";
		wifi_msg4=" seconds after the page refresh";
		wifi_msg5="Connection failed: password is incorrect or network anomaly.";
		
		noPlayFile="Please select a video file to play.";
		date_year_msg="Year must be Later than 1970.";
		date_year_msg1="Year must be less than 2038.";
		replay_file_upload="Please select a file to download.";
		replay_faild="failed";
		replay_hasDownLoadFila="Downloading now, To search will stop downloading, Continue?";
		
		replay_operate_faild = "Operation Failure!";
		replay_isOnload_msg = "Unable to run ActiveX Control, please operate again!";
		replay_isFile = "File Failure!";
		replay_no_file ="No media file, please click 'Open' or search to select the file to play!";
		replay_isPlay = "Current file is being played!";
		no_record_file = "No Record File,try it later.";
		
		sys_mod_isUpdate = "Setting modified. After saving, the web will close and you need to re-login, continue?";
		sys_mod_save_success = "Setting modified! The web will close 3 seconds later, please re-login!";
		browser_error="Unknown error! The current page will be forcibly closed. Please open your browser and login again!";

		video_time_msg = "Please enter 5-255 integer";

		gb28181Msg1="Please input Device id.";
		gb28181Msg2="Please input Device password.";
		gb28181Msg3="Please input Server ID.";

		changeMenuMsg1="The channel is video, or open voice intercom function, To turn to Setting interface will stop recording, Continue?";
		changeMenuMsg2="The device is video, or open voice intercom function, To turn to Setting interface will stop recording, Continue?";
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



		main_flow_msg="Primary stream";
		sub_flow_msg="Secondary stream";
		//multiaddr_msg="Invalid IP for Multicast Address";
		date_msg="Incorrect Date Format";
		time_msg="Incorrect Time Format";
		param_msg="Parameter Error";
		user_name_msg2="Invalid Characters for User Name Input.";

		create_xmlhttp_msg="Note: (Unable to create Msxml2.XMLHTTP)";
		send_xmlhttp_msg="Attention:( Unable to send data by Msxml2.XMLHTTP, Please confirm your IE version is 5.5 or higher.)";
		create_domdoc_msg="Attention:( Unable to create Msxml2.DOMDocument, Please confirm your IE version is 5.5 or higher.)";
		xml_error_msg="XML data is incorrect, Unable to parse.";
		url_error_msg="Incorrect URL";

		macaddr_msg="Please input correct MAC.";






		bf_hour_msg="\"Hour\" of the Auto Recording Time must be no more than 24.";
		bf_minute_msg="\"Minute\" of the Auto Recording Time must be no more than 60";

		stop_rec_msg="SD Card being occupied for recording, stop recording and format?";
		sys_outtime="System time out, Please try again.";
		isRec_msg="There are disks being videotaped, Cannot format.";
		store_policy_msg="The Stream change will only take effect after reboot, Save?";

		CreateXMLHTTP	= "Note: (Unable to create Msxml2.XMLHTTP)";
		returnXMLfail	= "XML data returned is incorrect, Unable to parse.";
		URLerror		= "Incorrect URL";
		SendXMLHTTP		= "Attention:( Unable to send data by Msxml2.XMLHTTP, Please confirm your IE version is 5.5 or higher.)";
		CreateDOMDoc	= "Attention:( Unable to create Msxml2.DOMDocument, Please confirm your IE version is 5.5 or higher.)";

		

		

		isRecording="Recording now, To turn to Setting interface will stop recording, Continue?";
		isTalking="Talk function activated, To turn to Setting interface will shut it down, Continue?";
		isAudioing="Audio function activated, To turn to Setting interface will shut it down, Continue?";

		ocx_ctl_error="Unable to install or run ActiveX Control. Please go to Login Page to download the ActiveX Control.";


		msg_3g_1="Turn on 3G.";
		msg_3g_2="Turn off 3G.";

	}else if(type==2){
		chnListmsg1="Click to hide list.";
		chnListmsg2="Click to display list.";

		picPathMsg="Pictures capture success! The path for the: ";
		capabilityMsg="Access capability set failure, unable to set parameters.";
		
		frate_msg="프레임 수는 정수이어야 함";
		frame_interval_msg="I 프레임 공간은 정수이어야 합니다.";
		bitrate_msg="비트 레이트는 정수이어야 합니다.";

		sys_mod_msg1="장비 타입을 입력하세요.";
		sys_mod_msg2="데이타 저장을 성공하였습니다.";
		sys_mod_msg4="업그레이드 중입니다. 기다려 주십시오...";
		sys_mod_msg5="패스워드 변경 후에 재 로그인합니다. 계속 하시겠습니까?";

		gsq_msg1="시간과 분은 반드시 숫자 이어야 합니다.";
		gsq_msg2="시간은 23 이상일 수 없습니다.";
		gsq_msg3="분은 59 이상 일 수 없습니다.";
		analysis_msg1="Check: time must be a number.";
		analysis_msg2="Seconds can not be over 59.";

		date_msg1="시작시간은 종료시간보다 이후 일 수는 없습니다.";

		preset_msg="프리셋 번호는 0일 수가 없습니다. 프리셋 번호를 선택하세요..";

		ocx_msg1="ActiveX OCX was not found. Please correct installation and re-visit.";
		ocx_msg2="ActiveX OCX login failed.";
		
		num_msg="숫자를 입력하세요";
		path_not_null="저장 경로를 설정하세요.";
		conf_success="설정이 성공적으로 끝났습니다.";

		error_num="Error code: ";
		get_data_error="Failed to get data.";
		saveError="The operation failed or save the data failed";
		stream_data_error="Failed to get the type of stream";
		has_illegal_letter="무효한 문자입니다.";
		getDataError="Failed to get data.";
		port_msg="포트는 65536 보다 적은 수이어야 합니다";
		ip_msg="정확한 IP 주소를 입력 하세요.";
		isNotNet="IP와 Gateway가 같은 네트워크 망에 있지 않음. 저장하시겠습니까?";
		submask_msg="정확한 Subnet Mask를 입력하세요.";
		gateway_msg="정확한 Default Gateway를 입력 하세요.";
		dns1_msg="정확한 Main DNS를 입력 하세요.";
		dns2_msg="정확한 Sub DNS를 입력 하세요.";
		
		pppoe_msg1="Please input User Name and Password.";

		ftp_msg1="정확한 서버IP를 입력하세요.";
		ftp_msg2="정확한 서버 포트를 입력하세요.";

		email_msg1="정확한 SMTP 서버를 입력하세요.";
		email_msg2="정확한 SMTP 포트를 입력하세요.";
		email_msg3="Please input correct Email address.";
		
		ddns_msg1="정확한 Domain을 입력하세요.";
		upnp_msg1="정확한 서버 IP를 입력하세요.";
		upnp_msg2="정확한 장비 포트를 입력하세요.";
		upnp_msg3="정확한 웹 포트를 입력하세요.";
		upnp_msg4="정확한 업데이트 주기를 입력하세요.";
		refreshTime_msg="업데이트 주기는 1~49까지의 정수이어야 합니다.";
		date_validate_msg="정확한 시간 포멧을 입력하십시오. : 년-월-일 시:분:초";
		b_e_date_msg="시작시간은 종료시간보다 이후 일 수는 없습니다.";
		
		user_pwd_msg1="6~16자리의 비밀번호를 입력하세요.";
		user_pwd_msg2="부정확한 비밀번호 입력.";
		user_pwd_msg3="비밀번호 입력 불일치.";
		user_pwd_msg4="부정확한 비밀번호 입력.";
		user_pwd_msg5="Update password faild.";
		
		file_msg="파일을 선택하세요";
		fileFormat="File type not match, please choose the correct ( .Bin ) upgrade file.";
		file_upg_Format="File type not match, please choose the correct ( .upg ) upgrade file.";
		defectMsg1="Defective Pixel detecting success";
		defectMsg2="Defective Pixel detecting failure, or timeout";
		defectMsg3="Iris detecting success";
		defectMsg4="Iris detecting failure, or timeout";
		login_msg="Disconnected";
		update_send_msg="Sending, Please wait...";
		update_install_msg="설치 중, 기다리세요...";
		update_success_msg="업그레이드 성공.";
		update_fail_msg="업그레이드 실패.";
		default_ipc="기본 설정을 하시겠습니까?";
		reboot_ipc="Sure you want to reboot the device?";
		correcting_dev="Confirm that you want to correct it?";
		format_msg="포멧 할 SD카드를 선택 하세요.";
		confirm_format_msg="모든 데이타는 포멧 후 삭제 됨. 계속하시겠습니까?";
		format_success="Format successful."
		format_faild="System timeout or disk is video, format failure!";
		platform_msg1="Device PUID cannot be empty.";
		platform_msg2="The maximum number of connections must be greater than 1 or less than65 integer.";

		alarmMsg="Detection interval must be a positive integer or zero.";

		wifi_msg1="The success of operation";
		wifi_msg2="성공적으로 연결이 끊어 졌습니다.";
		wifi_msg3="Please select a wireless network";
		wifi_msg4=" seconds after the page refresh";
		wifi_msg5="연결이 실패하였습니다. 패스워드가 틀리거나 네트워크가 비 정상적입니다.";
		
		noPlayFile="재생할 비디오를 선택하세요.";
		date_year_msg="년도는 1970보다 이후 이어야 합니다.";
		date_year_msg1="년도는 2038보다 이전 이어야 합니다.";
		replay_file_upload="다운로드 할 파일을 선택 하십시오.";
		replay_faild="실패";
		replay_hasDownLoadFila="다운로드 중입니다, 다운로드 중에는 탐색이 정지 합니다. 계속 하시겠습니까?";
		
		replay_operate_faild = "Operation Failure!";
		replay_isOnload_msg = "Unable to run ActiveX Control, please operate again!";
		replay_isFile = "File Failure!";
		replay_no_file ="No media file, please click 'Open' or search to select the file to play!";
		replay_isPlay = "Current file is being played!";
		no_record_file = "No Record File,try it later.";
		
		sys_mod_isUpdate = "Setting modified. After saving, the web will close and you need to re-login, continue?";
		sys_mod_save_success = "Setting modified! The web will close 3 seconds later, please re-login!";
		browser_error="Unknown error! The current page will be forcibly closed. Please open your browser and login again!";

		video_time_msg = "Please enter 5-255 integer";

		gb28181Msg1="Please input Device id.";
		gb28181Msg2="Please input Device password.";
		gb28181Msg3="Please input Server ID.";

		changeMenuMsg1="The channel is video, or open voice intercom function, To turn to Setting interface will stop recording, Continue?";
		changeMenuMsg2="The device is video, or open voice intercom function, To turn to Setting interface will stop recording, Continue?";
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



		main_flow_msg="첫번째 스트림";
		sub_flow_msg="두번째 스트림";
		//multiaddr_msg="멀티캐스트 주소를 위한 무효한 IP입니다";
		date_msg="부정확한 날짜";
		time_msg="부정확한 시간";
		param_msg="파라미터 에러";
		user_name_msg2="부정확한 사용자 이름 입력.";

		create_xmlhttp_msg="주의: (Msxml2.XMLHTTP을 생성할 수 없습니다.)";
		send_xmlhttp_msg="Attention:(Msxml2.XMLHTTP로 데이타를 보낼 수 없음, IE 버전이 5.5 또는 상위 버전인지 확인 하세요.)";
		create_domdoc_msg="Attention:(Msxml2.DOMDocument을 생성할 수 없음, IE 버전이 5.5 또는 상위 버전인지 확인 하세요.)";
		xml_error_msg="XML 데이타가 부정확합니다., 분석할 수 없습니다.";
		url_error_msg="부정확한 URL";

		macaddr_msg="정확한 MAC을 입력하세요..";






		bf_hour_msg="자동 녹화 시간의 \"시간\"은 24보다 작아야 합니다.";
		bf_minute_msg="자동 녹화 시간의 \"분\"은 60보다 작아야 합니다.";

		stop_rec_msg="SD카드에 녹화가 되고 있습니다. 녹화를 멈추고 포멧을 하시겠습니까?";
		sys_outtime="시스템 시간이 종료 되었습니다. 다시 시도 하세요.";
		isRec_msg="영상이 저장된 디스크가 있습니다. 포멧 할 수 없습니다.";
		store_policy_msg="스트림 변경은 리부팅 후에 유효함. 저장하시겠습니까?";

		CreateXMLHTTP	= "주의: (Msxml2.XMLHTTP을 생성할 수 없습니다.)";
		returnXMLfail	= "반송된 XML 데이터가 부정확함. 분석할 수 없습니다.";
		URLerror		= "부정확한 URL";
		SendXMLHTTP		= "주의:( Unable to send data by Msxml2.XMLHTTP로 데이타를 보낼 수 없음. IE 버전이 5.5또는 상위버전인지 확인 하세요.)";
		CreateDOMDoc	= "주의:( Unable to create Msxml2.DOMDocument을 생성할 수 없음. IE 버전이 5.5또는 상위버전인지 확인 하세요.)";

		

		

		isRecording="녹화 중입니다, 설정 인터페이스로 가기 위해서는 녹화가 멈춥니다. 계속하시겠습니까?";
		isTalking="스피커가 작동 중입니다. 설정 인터페이스로 가기 위해서는 장비가 꺼집니다. 계속하시겠습니까?";
		isAudioing="오디오가 작동 중입니다. 설정 인터페이스로 가기 위해서는 장비가 꺼집니다. 계속 하시겠습니까?";

		ocx_ctl_error="설치, AxtiveX Control을 실행할 수 없습니다. AxtiveX Control을 다운받기 위해서는 로그인 페이지로 이동하세요.";


		msg_3g_1="3G를 켜세요.";
		msg_3g_2="3G를 끄세요.";
	}
}

function onCheckboxClick(){
	var $obj=$(this);
	if($obj.attr("checked")==false)
		$obj.val('0');
	else
		$obj.val('1');
}

//初始化所有checkbox
function hookCheckbox(){
	$(':checkbox').bind('click',onCheckboxClick);
	$(':checkbox').each(function(){
		var $obj=$(this);
		if($obj.val()=="1")
			$obj.attr("checked","1");
		else
			$obj.attr("checked","");
	});
}

//页面按键事件
function hookKeyDown(){
	if (event.keyCode == 13){	//回车
		event.returnValue=false;
		event.cancel = true;
		event.keyCode=0;
		event.cancelBubble = true;
		return false;
	}
	if (event.keyCode == 8){	//backspace
		event.returnValue=false;
		event.cancel = true;
		event.keyCode=0;
		event.cancelBubble = true;
		return false;
	}
	if (event.keyCode == 115){	//F4
		event.returnValue=false;
		event.cancel = true;
		event.keyCode=0;
		event.cancelBubble = true;
		return false;
	}
	if (event.keyCode == 116){	//F5
		event.returnValue=false;
		event.cancel = true;
		event.keyCode=0;
		event.cancelBubble = true;
		return false;
	}
}

//验证字母或数字
function isNumOrLetter(nl){
	var jgpattern =/^[A-Za-z0-9]+$/; 
	if(!jgpattern.test(nl))
		return false;
	return true;
}

//判断是否为合法port
function isPORT(strPORT){
	if(strPORT == "" || isSpace(strPORT))
		return false;			
	var newPar=/^\d+$/;
	if(newPar.test(strPORT)){
		if(strPORT.charAt(0)=='0')
			return false;		
		if(strPORT < 65536 && strPORT>0)
			return true;						
	}
	return false;
}

//是否为空格字符串;true为空，FALSE为非空
function isSpace(strSource){
	var istring=strSource;
	var temp,i,strlen;
	temp=true;
	strlen=istring.length;
	for (i=0;i<strlen;i++){
		if((istring.substring(i,i+1)!=" ")&(temp)){
			temp=false;
		}
	}
	return temp;
}

//验证数字
function isNum(num){
	if(!num.match("^\\d+$"))
		return false;
	if(num.charAt(0)=='0')
		return false;
	return true;
}

function isTimeNum(num){
	if(!num.match("^\\d+$"))
		return false;
	return true;
}

//验证空字符串
function isBlank(str){
	if( str !="")
		return false;
	else
		return true;
}

//判断是否为数组
function isArray(obj){
	//typeof 返回值有六种可能： "number," "string," "boolean," "object," "function," 和 "undefined."
	if(typeof(obj)!="object")
		return false;
	if (!Array.prototype.push) { 
		Array.prototype.pop=function(){
			if(this.length!=0)this.length--;
				return this;
		}
	}
	if (!Array.prototype.push) {
		Array.prototype.push = function() {
			var startLength = this.length;
			for (var i = 0; i < arguments.length; i++)
				this[startLength + i] = arguments[i];
			return this.length;
		}
	}
	try{
		obj.push(1);
		obj.pop();
		return true;
	}catch(e){return false;}
}

//去字符串空格
function ignoreSpaces(string){
	var temp = "";
	string = '' + string;
	splitstring = string.split(" ");
	for(i = 0; i < splitstring.length; i++)
		temp += splitstring[i];
	return temp;
}

//验证物理地址
function isMac(str){
	if(str=="")
		return false;
	var t=/^([A-Z0-9]{2})-([A-Z0-9]{2})-([A-Z0-9]{2})-([A-Z0-9]{2})-([A-Z0-9]{2})-([A-Z0-9]{2})$/;
	if(t.test(str)){
		return true;
	}
	return false;
}

//email的判断。
function checkEmail(strSource){
	var reg	= new RegExp(/^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/);
	return reg.test(trim(strSource));
}

//验证域名
function checkDomain(strSource){
	if(strSource==""){
		return false;
	}
	var reg = new RegExp(/^[a-zA-Z0-9][-a-zA-Z0-9]{0,62}(\.[a-zA-Z0-9][-a-zA-Z0-9]{0,62})+\.?/);
	return reg.test(trim(strSource));
}

//验证IP
function isIPAddr(str){
	if(str==""){
		return false;
	}
	//check type
	if(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.test(str)==false){
		return false;
	}
	//check value
	if(RegExp.$1<0 || RegExp.$1>255||RegExp.$2<0||RegExp.$2>255||RegExp.$3<0||RegExp.$3>255|| RegExp.$4<0||RegExp.$4>255){
		return false;	 
	}
	//剔除 如 010.020.020.03 前面 的0
	var str=str.replace(/0(\d)/g,"$1");
	str=str.replace(/0(\d)/g,"$1");
	return true;	
}

//验证键盘数字
function isDigit(){
	if((event.keyCode != 46)&&(event.keyCode != 13)){
		if ((event.keyCode < 48) || (event.keyCode > 57)){
			alert(num_msg)
		};
		return ((event.keyCode >= 48) && (event.keyCode <= 57));
	}else{
		return  (event.keyCode);
	}
}

//验证路径
function verify(str){
	var pattern = /^([a-zA-Z]){1}:(\\[a-zA-Z]+)*(\\)?$/;
	if(pattern.test(str)){
		return true;
	}else{
		return false;
	}
}

//设置cookie
function SetCookidStr(szName,szValue,szExpires){
	var date=new Date();
	var expireDays;
	if(szExpires==""||szExpires==null){
		expireDays = 1;
	}else{
		expireDays=parseInt(szExpires);
	}
	if(szExpires<0){
		expireDays=1;
	}
	if(szName==""||szName==null){
		szName = "nothing";
	}
	date.setTime(date.getTime()+expireDays*24*3600*1000);
	document.cookie=""+szName+"=" + szValue + ";expires="+date.toGMTString();
	delete date; 
	date = null;
	CollectGarbage(); 
}

//获取cookie
function GetCookidStr(szName){
	var szCookie=unescape(document.cookie);
	var arrCookie=szCookie.split(";");
	var userId;
	userId = null;
	for(var i=0;i<arrCookie.length;i++){
		var arr=arrCookie[i].split("=");
		if(szName==trim(arr[0])){
		  userId=unescape(arr[1]);
		  break;
		}
	}
	return(userId);
}

//删除cookie
function DelCookidStr(cookieName){
	var exp = new Date();
	exp.setTime(exp.getTime() - 1);
	var cval=GetCookidStr(cookieName);
	if(cval!=null) document.cookie= cookieName + "="+cval+";expires="+exp.toGMTString();
}

//获得self元素值
function $s() {
	var elements = new Array();
	for (var i = 0; i < arguments.length; i++) {
		var element = arguments[i];
		if (typeof element == 'string')
			element = document.getElementById(element);
		if (arguments.length == 1)
			return element;
		elements.push(element);
	}
	return elements;
}

//获得parent元素值
function $p() {
	var elements = new Array();
	for (var i = 0; i < arguments.length; i++) {
		var element = arguments[i];
		if (typeof element == 'string')
			element = parent.document.getElementById(element);
		if (arguments.length == 1)
			return element;
		elements.push(element);
	}
	return elements;
}

//获得setpanel元素值
function $t(){
	var elements = new Array();
	for (var i = 0; i < arguments.length; i++) {
		var element = arguments[i];
		if (typeof element == 'string')
			element = parent.ifrmSet.document.getElementById(element);
		if (arguments.length == 1)
			return element;
		elements.push(element);
	}
	return elements;
}

//获得previewpanel元素值
function $w(){
	var elements = new Array();
	for (var i = 0; i < arguments.length; i++) {
		var element = arguments[i];
		if (typeof element == 'string')
			element = parent.ifrmPreview.document.getElementById(element);
		if (arguments.length == 1)
			return element;
		elements.push(element);
	}
	return elements;
}


//获取当天日期:yyyy-MM-dd
function getCurDate(){
	var today = new Date(); 	
	return today.getYear() + "-" + ((today.getMonth()+1)<10?"0":"") + (today.getMonth()+1) + "-" + (today.getDate()<10?"0":"") + today.getDate();
}

//获取当天时间:yyyyMMdd-hhmmss
function getCurTime(){
	var today = new Date();
	return today.getYear() + ((today.getMonth()+1)<10?"0":"") + (today.getMonth()+1) + (today.getDate()<10?"0":"") + today.getDate() + "-" + 
		(today.getHours()<10?"0":"")+today.getHours() + 
		(today.getMinutes()<10?"0":"")+today.getMinutes() + 
		(today.getSeconds()<10?"0":"")+today.getSeconds();
}

//长时间，形如(2003-12-05 13:04:06)
function IsLongDateTime(strSource){
	var reg = /^(\d{1,4})(-|\/)(\d{1,2})\2(\d{1,2}) (\d{1,2}):(\d{1,2}):(\d{1,2})$/;
	var r = strSource.match(reg);
	if(r==null)return false;
	if(strSource.length != 19) return false;
	var d= new Date(r[1], r[3]-1,r[4],r[5],r[6],r[7]);
	return (d.getFullYear()==r[1]&&(d.getMonth()+1)==r[3]&&d.getDate()==r[4]&&d.getHours()==r[5]&&d.getMinutes()==r[6]&&d.getSeconds()==r[7]);
}

//比较输入日期
function cmpDate(startDate,endDate){
	if(startDate.length>0&&endDate.length>0){
		var startDateTemp = startDate.split(" ");
		var endDateTemp = endDate.split(" ");
		var arrStartDate = startDateTemp[0].split("-");
		var arrEndDate = endDateTemp[0].split("-");
		var arrStartTime = startDateTemp[1].split(":");
		var arrEndTime = endDateTemp[1].split(":");
		var allStartDate = new Date(arrStartDate[0],arrStartDate[1]-1,arrStartDate[2],arrStartTime[0],arrStartTime[1],arrStartTime[2]);
		var allEndDate = new Date(arrEndDate[0],arrEndDate[1]-1,arrEndDate[2],arrEndTime[0],arrEndTime[1],arrEndTime[2]);
		if(allStartDate.getTime()>allEndDate.getTime()){ 
			return false;
		}
	}
	return true;
}

//转化时间格式为：00:00:00
function stampToTime(nTimeSeconds){
	var strtime,szFTime;
	szFTime="";
	strtime=nTimeSeconds%60;//秒
	if(strtime>=10){
		szFTime=":" + strtime + szFTime;
	}else{
		szFTime=":0" + strtime + szFTime;
	}
	strtime=parseInt(nTimeSeconds/60,10)%60;//分
	if(strtime>=10){
		szFTime=":" + strtime + szFTime;
	}else{
		szFTime=":0" + strtime + szFTime;
	}
	strtime=parseInt(parseInt(nTimeSeconds/60,10)/60,10)%60;//时
	strtime=strtime>=10?strtime:"0"+strtime;
	szFTime=strtime + szFTime;
	return szFTime;
}

//单击table某行改变背景色
//var lastobj="";
//var lastClassName = "";
function clickHandler(obj){
	//if(lastobj){
	//	lastobj.className = lastClassName;
	//}
	//lastClassName=obj.className;
	for(var i=1;i<=rowId;i++){
		if(document.getElementById("tr"+i)){
			document.getElementById("tr"+i).className="data";
		}
	}
	obj.className="selected";
	//lastobj=obj;
}

//LTrim(string):去除左边的空格
function LTrim(str){
	var whitespace = new String(" \t\n\r");
	var s = new String(str);
	if (whitespace.indexOf(s.charAt(0)) != -1){
		var j=0, i = s.length;
		while (j < i && whitespace.indexOf(s.charAt(j)) != -1){
			j++;
		}
		s = s.substring(j, i);
	}
	return s;
}

//RTrim(string):去除右边的空格
function RTrim(str){
	var whitespace = new String(" \t\n\r");
	var s = new String(str);
	if (whitespace.indexOf(s.charAt(s.length-1)) != -1){
		var i = s.length - 1;
		while (i >= 0 && whitespace.indexOf(s.charAt(i)) != -1){
			i--;
		}
		s = s.substring(0, i+1);
	}
	return s;
}

//Trim(string):去除前后空格
function trim(str){
	return RTrim(LTrim(str));
}

//十进制转换成二进制
function toBin(intNum) {
	var answer = "";
	if(/\d+/.test(intNum)) {
		while(intNum != 0) {
			answer = Math.abs(intNum%2)+answer;
			intNum = parseInt(intNum/2);
		}
		if(answer.length == 0)
			answer = "0";
		return answer;
	}else{
		return 0;
	}
}

//设置页面显示消息
function setPageMsg(msg){
	document.getElementById("errinfo").innerHTML=msg;
	setTimeout(clearShowMsg, 3000);
}

//隐藏页面显示消息
function clearShowMsg(){
	document.getElementById("errinfo").innerHTML="";
}

function enableChannel(szEle, sapnEle, nCount){
	for(i=1;i<=nCount;i++){
		$("#"+szEle+i).attr("disabled","");
		$("#"+szEle+i).attr("style","visibility: ''");
		$("#"+sapnEle+i).attr("style","visibility: ''");
	}
}

//加密
function encrypt(str, pwd) {
	if (pwd == null || pwd.length <= 0) {
		alert("Please enter a password with which to encrypt the message.");
		return null;
	}
	var prand = "";
	for (var i = 0; i < pwd.length; i++) {
		prand += pwd.charCodeAt(i).toString();
	}
	var sPos = Math.floor(prand.length / 5);
	var mult = parseInt(prand.charAt(sPos) + prand.charAt(sPos * 2) + prand.charAt(sPos * 3) + prand.charAt(sPos * 4) + prand.charAt(sPos * 5));
	var incr = Math.ceil(pwd.length / 2);
	var modu = Math.pow(2, 31) - 1;
	if (mult < 2) {
		alert("Algorithm cannot find a suitable hash. Please choose a different password.  Possible considerations are to choose a more complex or longer password.");
		return null;
	}
	var salt = Math.round(Math.random() * 1000000000) % 100000000;
	prand += salt;
	while (prand.length > 10) {
		prand = (parseInt(prand.substring(0, 10)) + parseInt(prand.substring(10, prand.length))).toString();
	}
	prand = (mult * prand + incr) % modu;
	var enc_chr = "";
	var enc_str = "";
	for (var i = 0; i < str.length; i++) {
		enc_chr = parseInt(str.charCodeAt(i) ^ Math.floor((prand / modu) * 255));
		if (enc_chr < 16) {
			enc_str += "0" + enc_chr.toString(16);
		} else {
			enc_str += enc_chr.toString(16);
		}
		prand = (mult * prand + incr) % modu;
	}
	salt = salt.toString(16);
	while (salt.length < 8) {
		salt = "0" + salt;
	}
	enc_str += salt;
	return enc_str;
}

//解密
function decrypt(str, pwd) {
	if (str == null || str.length < 8) {
		alert("A salt value could not be extracted from the encrypted message because it's length is too short. The message cannot be decrypted.");
		return;
	}
	if (pwd == null || pwd.length <= 0) {
		alert("Please enter a password with which to decrypt the message.");
		return;
	}
	var prand = "";
	for (var i = 0; i < pwd.length; i++) {
		prand += pwd.charCodeAt(i).toString();
	}
	var sPos = Math.floor(prand.length / 5);
	var mult = parseInt(prand.charAt(sPos) + prand.charAt(sPos * 2) + prand.charAt(sPos * 3) + prand.charAt(sPos * 4) + prand.charAt(sPos * 5));
	var incr = Math.round(pwd.length / 2);
	var modu = Math.pow(2, 31) - 1;
	var salt = parseInt(str.substring(str.length - 8, str.length), 16);
	str = str.substring(0, str.length - 8);
	prand += salt;
	while (prand.length > 10) {
		prand = (parseInt(prand.substring(0, 10)) + parseInt(prand.substring(10, prand.length))).toString();
	}
	prand = (mult * prand + incr) % modu;
	var enc_chr = "";
	var enc_str = "";
	for (var i = 0; i < str.length; i += 2) {
		enc_chr = parseInt(parseInt(str.substring(i, i + 2), 16) ^ Math.floor((prand / modu) * 255));
		enc_str += String.fromCharCode(enc_chr);
		prand = (mult * prand + incr) % modu;
	}
	return enc_str;
}


var videoIp;//登录设备的IP
var videoDataPort;//设备参数设置端口
var videoStreamPort;//设备视频流端口
var videoUserName;//用户名
var videoPwd;//密码

//初始化系统配置的视频播放
function initConfVideoPlayer(){
	videoIp= $p("ip").value;
	videoDataPort= $p("dataPort").value;
	videoStreamPort= $p("streamPort").value;
	videoUserName= $p("userName").value;
	videoPwd = $p("password").value;
	ipcObj=document.getElementById("ipc");
	openConfIpc();
}

//开启配置页面的视频
function openConfIpc(){
	var screenFormat='{"type":0,"count":1,"splitData":[{"id":1, "x":1, "y":1, "wndCount":-1}]}';
	ipcObj.SetSplitDef(screenFormat);//定义分屏格式
	if(ipcObj.Login(videoIp, videoStreamPort, videoDataPort,  videoUserName, videoPwd)==0){
		alert(ocx_msg2);
		return;
	}
	ipcObj.SetSplitScreen(parent.childHandleID ,1);//设置分屏
	ipcObj.StartStream(0, 0,  parent.childHandleID);
}

//退出控件
function ocxPageClose(ipcObj, hID){
	if(ipcObj!=null && ipcObj.object!=null){
		ipcObj.Exit(hID);
	}
}

//设置控件对象的disabled样式
function setObjStyle(idList, status){
	if(idList=="")return;
	var objArray=idList.split(",");
	for(var i=0;i<objArray.length;i++){
		if($s(objArray[i])){
			$s(objArray[i]).disabled=status;
			if(status && ($s(objArray[i]).type=="text" || $s(objArray[i]).type=="checkbox" || $s(objArray[i]).type=="password")){
				$s(objArray[i]).style.backgroundColor="#d4d0c8";
			}else{
				$s(objArray[i]).style.backgroundColor="#ffffff";
			}
		}
	}
}

//设置通道select值
function setChnSelectValue(){
	if($p("chnCount").value>1){
		$s("trParamChnNum").style.display="block";
		$s("param_chnNum").length=0;
		for(var i=0;i<$p("chnCount").value;i++){
			$s("param_chnNum").options[i]=new Option("Channel "+(i+1), i);
		}
	}
}

//通道改变时重新获取数据
function changeChnNum(selectVal){
	$s("errinfo").innerHTML="";
	getCurrentParam(selectVal);
}

//获取参数配置页面json格式的对象
function getJsonParamObj(paramIpcObj, paramType, paramChnNum, paramHandleId){
	var jsonParamObj=paramIpcObj.getJSONDataForParam(paramType, paramChnNum, paramHandleId);
	//alert(jsonParamObj);
	try{
		jsonParamObj=eval("("+jsonParamObj+")");
	}catch(e){
		$s("errinfo").innerHTML=get_data_error;
		if($s("savesumbit")){
			$s("savesumbit").disabled=true;
		}
		return "";
	}
	if(jsonParamObj.Req_Err_NO!=0){
		$s("errinfo").innerHTML=error_num+jsonParamObj.Req_Err_NO;
		if($s("savesumbit")){
			$s("savesumbit").disabled=true;
		}
		return "";
	}
	return jsonParamObj;
}

//获取参数配置页面json格式的对象
function setJsonParamObj(paramIpcObj, paramType, paramJsonData, paramChnNum, paramHandleId){
	var temp=paramIpcObj.setJSONDataForParam(paramType, paramJsonData, paramChnNum, paramHandleId);
	if(temp==0){
		$s("errinfo").innerHTML=saveError;
	}else{
		setPageMsg(sys_mod_msg2);
	}
}

//设置等待界面
function setWaitBarPositionWithObject(objOwner, strVisible){
	var obj	= objOwner.document.getElementById("WaitBar");
	if(obj!=null){
		obj.style.visibility	= strVisible;
		if(strVisible=="visible"){
			obj.style.left 		= (parseInt(objOwner.document.body.offsetWidth,10) - parseInt(obj.offsetWidth,10)) / 2;
			obj.style.top 		= (parseInt(objOwner.document.body.offsetHeight,10) - parseInt(obj.offsetHeight,10)) / 2;
		}
	}
}

//验证布防时间的有效性
function validateTime(bh, bm, eh, em, day, order){
	if(bh=="" && bm=="" && eh=="" && em==""){//都为空则不验证
		document.getElementById("bh"+day+"_"+order).value="0";
		document.getElementById("bm"+day+"_"+order).value="0";
		document.getElementById("eh"+day+"_"+order).value="0";
		document.getElementById("em"+day+"_"+order).value="0";
	}else{
		if(bh==""){ bh="0";}
		if(bm==""){ bm="0";}
		if(eh==""){ eh="0";}
		if(em==""){ em="0";}
		if(!isTimeNum(bh) || !isTimeNum(bm) || !isTimeNum(eh) || !isTimeNum(em)){
			alert(gsq_msg1);return false;
		}
		bh=parseInt(bh,10);
		bm=parseInt(bm,10);
		eh=parseInt(eh,10);
		em=parseInt(em,10);
		if(bh>=24 || eh>=24){
			alert(gsq_msg2);return false;
		}
		if(bm>59 || em>59){
			alert(gsq_msg3);return false;
		}
		if(bh>eh){
			alert(b_e_date_msg);return false;
		}
		if(bh==eh && bm>em){
			alert(b_e_date_msg);return false;
		}
		document.getElementById("bh"+day+"_"+order).value=bh;
		document.getElementById("bm"+day+"_"+order).value=bm;
		document.getElementById("eh"+day+"_"+order).value=eh;
		document.getElementById("em"+day+"_"+order).value=em;
	}
	return true;
}

//启用时间段	checkbox
function enabledTimeChk(obj){
	var temp=obj.id.substring(2, obj.id.length);
	if(obj.checked){//启用时间段
		setObjStyle("bh"+temp+",bm"+temp+",eh"+temp+",em"+temp, false);
		obj.value="1";
		$s("bh"+temp).focus();
	}else{
		setObjStyle("bh"+temp+",bm"+temp+",eh"+temp+",em"+temp, true);
		obj.value="0";
	}
}

//启用全天		checkbox
function fullTimeChk(obj){
	var temp=obj.id.substring(obj.id.length-1, obj.id.length);
	if(obj.checked){//启用全天录像
		$s("ck"+temp+"_1").checked=false;
		$s("ck"+temp+"_2").checked=false;
		setObjStyle("ck"+temp+"_1,ck"+temp+"_2", true);
		enabledTimeChk($s("ck"+temp+"_1"));
		enabledTimeChk($s("ck"+temp+"_2"));

		if(temp==7){
			setObjStyle("fullTime0,fullTime1,fullTime2,fullTime3,fullTime4,fullTime5,fullTime6", true);
			for(var i=0;i<7;i++){
				$s("fullTime"+i).checked=false;
				fullTimeChk($s("fullTime"+i));
				setObjStyle("ck"+i+"_1,ck"+i+"_2", true);
			}
		}
		obj.value="1";
	}else{
		if(obj.disabled){
			$s("ck"+temp+"_1").checked=false;
			$s("ck"+temp+"_2").checked=false;
		}
		setObjStyle("ck"+temp+"_1,ck"+temp+"_2", false);
		enabledTimeChk($s("ck"+temp+"_1"));
		enabledTimeChk($s("ck"+temp+"_2"));

		if(temp==7){
			for(var i=0;i<7;i++){
				setObjStyle("ck"+i+"_1,ck"+i+"_2", false);
				fullTimeChk($s("fullTime"+i));
			}
			setObjStyle("fullTime0,fullTime1,fullTime2,fullTime3,fullTime4,fullTime5,fullTime6", false);
		}
		obj.value="0";
	}
}