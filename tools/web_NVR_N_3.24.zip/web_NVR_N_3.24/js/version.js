var version="V3.23_N";
var companyUrl="";
var companyZH="";
var companyEN="";
var phoneNumZH="";
var phoneNumEN="";
