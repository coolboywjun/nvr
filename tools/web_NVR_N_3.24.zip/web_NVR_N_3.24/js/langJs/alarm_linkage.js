function changeTheLanguage(type){
	setLanguage(type);
	if(type==0){//英文
		switch (parseInt(parent.currentAlarmType))
		{
			case 0:
				title1="Motion Detection";break;
			case 1:
				title1="Lost Alarm";break;
			case 2:
				title1="Privacy Zone Alarm Setting";break;
			case 3:
				title1="Probe Detection";break;
			case 6:
				title1="PIR Alarm";break;
		}
		title2="Alarm Trigger";

		//$s("linkage").innerHTML="Alarm Linkage";
		/*$s("inputChn").innerHTML="Channel";
		$s("paramChnNum").innerHTML="Channel Number";
		$s("alarmType").innerHTML="Alarm Type";
		var alarmTypeSel=$s("alarm_type");
		alarmTypeSel.options[0].text="Alarm Motion";
		alarmTypeSel.options[1].text="Lost Alarm";
		alarmTypeSel.options[2].text="Hide Alarm";
		alarmTypeSel.options[3].text="IO Alarm";*/

		$s("linkageType").innerHTML="Trigger Action";
		var linkageTypeSel=$s("linkage_type");
		linkageTypeSel.options[0].text="Record";
		linkageTypeSel.options[1].text="Output";
		linkageTypeSel.options[2].text="Capture";

		$s("videoTime").innerHTML="Record Time(s)";
		$s("videoS").innerHTML="";
		$s("linkageEmail").innerHTML="Send E-mail";
		$s("beepTime").innerHTML="Audio Alarm(s)";
		$s("beepS").innerHTML="";
		$s("captureInterval").innerHTML="Interval(s)";
		$s("intervalS").innerHTML="";
		$s("captureTimes").innerHTML="Capture Pieces";
		$s("outputTimes").innerHTML="Output(s)";

		$s("channelConfig").innerHTML="Channel Config";
		$s("linkageConfig").innerHTML="Action Config";

		$s("labelAll").innerHTML="Select All";
		$s("labelContrary").innerHTML="Select Inverse";
		
		$s("gotoAlarm").innerHTML = "Alarm Setting";
		$s("savesumbit").value="Save";
	}else if(type==1){//中文
		switch (parseInt(parent.currentAlarmType))
		{
			case 0:
				title1="移动侦测报警";break;
			case 1:
				title1="视频丢失报警";break;
			case 2:
				title1="遮挡报警";break;
			case 3:
				title1="IO报警";break;
			case 6:
				title1="人体检测报警";break;
		}
		title2="联动配置";

		//$s("linkage").innerHTML="报警联动";
		/*$s("inputChn").innerHTML="输入通道";
		$s("paramChnNum").innerHTML="通道号";
		$s("alarmType").innerHTML="报警类型";
		var alarmTypeSel=$s("alarm_type");
		alarmTypeSel.options[0].text="移动侦测报警";
		alarmTypeSel.options[1].text="视频丢失报警";
		alarmTypeSel.options[2].text="遮挡报警";
		alarmTypeSel.options[3].text="IIO报警";*/

		$s("linkageType").innerHTML="联动通道类型";
		var linkageTypeSel=$s("linkage_type");
		linkageTypeSel.options[0].text="联动录像";
		linkageTypeSel.options[1].text="联动输出";
		linkageTypeSel.options[2].text="联动抓拍";

		$s("videoTime").innerHTML="录像时长";
		$s("videoS").innerHTML=" 秒";
		$s("linkageEmail").innerHTML="联动E-mail";
		$s("beepTime").innerHTML="联动蜂鸣时间";
		$s("beepS").innerHTML=" 秒";
		$s("captureInterval").innerHTML="联动抓拍间隔";
		$s("intervalS").innerHTML=" 秒";
		$s("captureTimes").innerHTML="联动抓拍次数";
		$s("outputTimes").innerHTML="输出时间";

		$s("channelConfig").innerHTML="通道配置";
		$s("linkageConfig").innerHTML="联动配置";

		$s("labelAll").innerHTML="全选";
		$s("labelContrary").innerHTML="反选";
		
		$s("gotoAlarm").innerHTML = "报警设置";
		$s("savesumbit").value="保存";
	}else if(type==2){//韩文
		switch (parseInt(parent.currentAlarmType))
		{
			case 0:
				title1="모션감지 알람";break;
			case 1:
				title1="영상신호손실 알람";break;
			case 2:
				title1="비디오차단 알람";break;
			case 3:
				title1="IO 알람";break;
			case 6:
				title1="인체 검출 신고";break;
		}
		title2="알람설정";

		//$s("linkage").innerHTML="报警联动";
		/*$s("inputChn").innerHTML="输入通道";
		$s("paramChnNum").innerHTML="通道号";
		$s("alarmType").innerHTML="报警类型";
		var alarmTypeSel=$s("alarm_type");
		alarmTypeSel.options[0].text="모션감지 알람";
		alarmTypeSel.options[1].text="영상신호손실 알람";
		alarmTypeSel.options[2].text="비디오차단 알람";
		alarmTypeSel.options[3].text="IO 알람";*/

		$s("linkageType").innerHTML="알람채널 형태";
		var linkageTypeSel=$s("linkage_type");
		linkageTypeSel.options[0].text="알람녹화";
		linkageTypeSel.options[1].text="알람입력";
		linkageTypeSel.options[2].text="알람캡쳐";

		$s("videoTime").innerHTML="녹화기간";
		$s("videoS").innerHTML=" 초";
		$s("linkageEmail").innerHTML="이메일발송";
		$s("beepTime").innerHTML="부저";
		$s("beepS").innerHTML=" 초";
		$s("captureInterval").innerHTML="알람캡쳐 간격";
		$s("intervalS").innerHTML=" 초";
		$s("captureTimes").innerHTML="알람캡쳐 횟수";
		$s("outputTimes").innerHTML="알람출력 지속시간";

		$s("channelConfig").innerHTML="채널설정";
		$s("linkageConfig").innerHTML="알람설정";

		$s("labelAll").innerHTML="모두 선택";
		$s("labelContrary").innerHTML="역선택";
		
		$s("gotoAlarm").innerHTML = "알람설정";
		$s("savesumbit").value="저장";
	}
}
