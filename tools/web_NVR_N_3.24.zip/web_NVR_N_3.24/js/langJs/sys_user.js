function changeTheLanguage(type){
	setLanguage(type);
	if(type==0){//英文
		$s("sysUser").innerHTML="User Management";
		$s("sysUserName").innerHTML="User Name";
		$s("sysPassword").innerHTML="Old Password";
		$s("sysUserPwd").innerHTML="New Password";
		$s("sysUserPwd2").innerHTML="Confirm Password";
		
		$s("StrNotice").innerHTML="<span style=\"color:#FF0000; font-weight:700;\">Note : </span><br>User Name, Password should only use letters, numbers, underscores and dots,<br> from 6 to 16 characters. Please login again after modifying.";

		$s("savesumbit").value="Save";
	}else if(type==1){//中文
		$s("sysUser").innerHTML="用户设置";
		$s("sysUserName").innerHTML="用户名";
		$s("sysPassword").innerHTML="旧密码";
		$s("sysUserPwd").innerHTML="新密码";
		$s("sysUserPwd2").innerHTML="确认密码";
		
		$s("StrNotice").innerHTML="<span style=\"color:#FF0000; font-weight:700;\">注意:</span>用户名、密码必须是字母、数字、下划线或点(.)组成的一个1至16个字符的字符串，请注意大小写。<br>修改用户名或密码，请重新登录。";

		$s("savesumbit").value="保存";
	}else if(type==2){//韩文
		$s("sysUser").innerHTML="사용자 계정";
		$s("sysUserName").innerHTML="사용자 이름";
		$s("sysPassword").innerHTML="구 비밀번호";
		$s("sysUserPwd").innerHTML="신규 비밀번호";
		$s("sysUserPwd2").innerHTML="비밀번호 확인";
		
		$s("StrNotice").innerHTML="<span style=\"color:#FF0000; font-weight:700;\">주의:</span>사용자 이름, 비밀번호는 문자, 숫자, '_', '.'를 사용할 수 있으며 16자로 제한됨. 수정후에 로그인 다시 하시기 바랍니다.";

		$s("savesumbit").value="저장";

	}
}
