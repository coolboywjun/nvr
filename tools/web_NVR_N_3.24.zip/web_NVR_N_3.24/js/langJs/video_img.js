function changeTheLanguage(type){
	setLanguage(type);
	if(type==0){//英文
		$s("videoImg").innerHTML="Image";
		$s("paramChnNum").innerHTML="Channel Number";

		childFrame.document.getElementById("videoImgBri").innerHTML="Brightness";
		childFrame.document.getElementById("videoImgCon").innerHTML="Contrast";
		childFrame.document.getElementById("videoImgHue").innerHTML="Grey";
		childFrame.document.getElementById("videoImgSat").innerHTML="Saturation";
		childFrame.document.getElementById("videoImgSha").innerHTML="Sharpness";
		childFrame.document.getElementById("defaultBtn").value="Reset";
		$s("tdJB").style.width = "900px";
		$s("videoImgBaseP").innerHTML="Image Setting";
		$s("btnMirror").value="Mirror";
		$s("btnFlip").value="Flip";
		$s("pwdFreqLabel").innerHTML="Anti Flickering";

		$s("videoImgHighP").innerHTML="Advanced Setting";
		$s("zdgqLabel").innerHTML="Auto Iris";
		$s("bgbcSliderLabel").innerHTML="BLC";
		//$s("hdjzLabel").innerHTML="Dead Pixel Correction";
		$s("kdtLabel").innerHTML="WDR";
		$s("kdtSliderLabel").innerHTML="WDR";
		$s("bgmsLabel").innerHTML="Auto Exposure";
		
		//$s("jzLabel").innerHTML="3D Denoise";
		//$s("kyjz1Label").innerHTML="Airspace Denoise Strength 1";
		//$s("kyjz2Label").innerHTML="Airspace Denoise Strength 2";
		//$s("syjzLabel").innerHTML="Time domain Denoise Strength";
		$s("bphLabel").innerHTML="White Balance";
		$s("sdRedLabel").innerHTML="Red";
		$s("sdBlueLabel").innerHTML="Blue";

		var pwdFreqSelect=$s("pwdFreqSelect");
		pwdFreqSelect.options[0].text="Close";

		var bphSelect=$s("bphSelect");
		bphSelect.options[0].text="Automatic";
		bphSelect.options[1].text="Manual";
		bphSelect.style.width = "83px";
		
		$s("kdtSelect").style.width="60px";
		var kdtSelect=$s("kdtSelect");
		kdtSelect.options[0].text="Close";
		kdtSelect.options[1].text="Open";

		var bgmsSelect=$s("bgmsSelect");
		bgmsSelect.options[0].text="Noise";
		bgmsSelect.options[1].text="Frame Rate";
		bgmsSelect.options[2].text="Gain";
	}else if(type==1){//中文
		$s("videoImg").innerHTML="图像参数";
		$s("paramChnNum").innerHTML="通道号";

		childFrame.document.getElementById("videoImgBri").innerHTML="亮度";
		childFrame.document.getElementById("videoImgCon").innerHTML="对比度";
		childFrame.document.getElementById("videoImgHue").innerHTML="灰度";
		childFrame.document.getElementById("videoImgSat").innerHTML="饱和度";
		childFrame.document.getElementById("videoImgSha").innerHTML="锐度";
		childFrame.document.getElementById("defaultBtn").value="恢复默认";
		$s("videoImgBaseP").innerHTML="图像配置";
		$s("btnMirror").value="镜像";
		$s("btnFlip").value="翻转";
		$s("pwdFreqLabel").innerHTML="抗闪烁";

		$s("videoImgHighP").innerHTML="高级配置";
		$s("zdgqLabel").innerHTML="自动光圈";
		$s("bgbcSliderLabel").innerHTML="曝光补偿";
		$s("kdtLabel").innerHTML="宽动态强度";
		$s("kdtSliderLabel").innerHTML="宽动态";
		$s("bgmsLabel").innerHTML="曝光模式";
		
		$s("bphLabel").innerHTML="白平衡";
		$s("sdRedLabel").innerHTML="红色";
		$s("sdBlueLabel").innerHTML="蓝色";

		var pwdFreqSelect=$s("pwdFreqSelect");
		pwdFreqSelect.options[0].text="关闭";

		var bphSelect=$s("bphSelect");
		bphSelect.options[0].text="自动";
		bphSelect.options[1].text="手动";
		
		var kdtSelect=$s("kdtSelect");
		kdtSelect.options[0].text="关闭";
		kdtSelect.options[1].text="开启";

		var bgmsSelect=$s("bgmsSelect");
		bgmsSelect.options[0].text="噪声优先";
		bgmsSelect.options[1].text="帧率优先";
		bgmsSelect.options[2].text="增益优先";
	}else if(type==2){//韩文
		$s("videoImg").innerHTML="이미지";
		$s("paramChnNum").innerHTML="채널 번호";

		childFrame.document.getElementById("videoImgBri").innerHTML="Brightness";
		childFrame.document.getElementById("videoImgCon").innerHTML="Contrast";
		childFrame.document.getElementById("videoImgHue").innerHTML="Chroma";
		childFrame.document.getElementById("videoImgSat").innerHTML="Saturation";
		childFrame.document.getElementById("videoImgSha").innerHTML="Sharpness";
		childFrame.document.getElementById("defaultBtn").value="기본값복원";
		$s("videoImgBaseP").innerHTML="영상설정";
		$s("btnMirror").value="좌우반전";
		$s("btnFlip").value="상하반전";
		$s("pwdFreqLabel").innerHTML="깜박임 방지";

		$s("videoImgHighP").innerHTML="고급설정";
		$s("zdgqLabel").innerHTML="자동조리개";
		$s("bgbcSliderLabel").innerHTML="노출보정";
		$s("kdtLabel").innerHTML="WDR 레벨";
		$s("kdtSliderLabel").innerHTML="WDR";
		$s("bgmsLabel").innerHTML="노출 방식";
		
		$s("bphLabel").innerHTML="화이트밸런스";
		$s("sdRedLabel").innerHTML="붉은색";
		$s("sdBlueLabel").innerHTML="파란색";

		var pwdFreqSelect=$s("pwdFreqSelect");
		pwdFreqSelect.options[0].text="닫기";

		var bphSelect=$s("bphSelect");
		bphSelect.options[0].text="자동";
		bphSelect.options[1].text="수동";
		
		var kdtSelect=$s("kdtSelect");
		kdtSelect.options[0].text="닫기";
		kdtSelect.options[1].text="활성화";

		var bgmsSelect=$s("bgmsSelect");
		bgmsSelect.options[0].text="노이즈제거 우선";
		bgmsSelect.options[1].text="영상전송속도 우선";
		bgmsSelect.options[2].text="Gain 처리우선";

	}
}