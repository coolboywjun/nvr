function changeTheLanguage(type){
	setLanguage(type);
	if(type==0){//英文
		$s("upnp").innerHTML="UPNP Setting";
		$s("upnpOpen").innerHTML="Enable UPNP";
		$s("upnpModel").innerHTML="Use Pattern";
		$s("upnpEthno").innerHTML="Network Card";
		$s("upnpAddr").innerHTML="Server Address";
		$s("upnpDataport").innerHTML="Device Port";
		$s("upnpHttpport").innerHTML="Web Port";
		$s("upnpDataState").innerHTML="Device Port Mapping Status";
		$s("upnpHttpState").innerHTML="Web Port Mapping Status";
		$s("upnpReftime").innerHTML="Update Cycle";
		$s("upnpH").innerHTML="Hour";

		$s("upnpTalkport").innerHTML="Talk Port";
		$s("upnpCmdport").innerHTML="Signalling Port";
		$s("upnpTalkState").innerHTML="Talk Port Mapping Status";
		$s("upnpCmdState").innerHTML="Signalling Port Mapping Status";

		var upnp_model=document.getElementById("upnp_model");
		upnp_model.options[0].text="Fixed Pattern";
		upnp_model.options[1].text="Auto Pattern";

		var upnp_ethno=document.getElementById("upnp_ethno");
		upnp_ethno.options[0].text="Ethernet";
		upnp_ethno.options[1].text="WIFI";
		upnp_ethno.options[2].text="3G";
		$s("savesumbit").value="Save";
	}else if(type==1){//中文
		$s("upnp").innerHTML="UPNP服务";
		$s("upnpOpen").innerHTML="启用UPNP";
		$s("upnpModel").innerHTML="模式";
		$s("upnpEthno").innerHTML="网卡类型";
		$s("upnpAddr").innerHTML="主机地址";
		$s("upnpDataport").innerHTML="数据映射端口";
		$s("upnpHttpport").innerHTML="HTTP映射端口";
		$s("upnpDataState").innerHTML="数据映射端口状态";
		$s("upnpHttpState").innerHTML="HTTP映射端口状态";
		$s("upnpReftime").innerHTML="刷新间隔";
		$s("upnpH").innerHTML="小时";

		$s("upnpTalkport").innerHTML="对讲端口";
		$s("upnpCmdport").innerHTML="命令端口";
		$s("upnpTalkState").innerHTML="对讲端口映射状态";
		$s("upnpCmdState").innerHTML="命令端口映射状态";

		var upnp_model=document.getElementById("upnp_model");
		upnp_model.options[0].text="指定";
		upnp_model.options[1].text="自动";

		var upnp_ethno=document.getElementById("upnp_ethno");
		upnp_ethno.options[0].text="有线";
		upnp_ethno.options[1].text="无线";
		upnp_ethno.options[2].text="3G";
		$s("savesumbit").value="保存";

	}else if(type==2){//韩文
		$s("upnp").innerHTML="UPNP 설정";
		$s("upnpOpen").innerHTML="UPNP 활성화";
		$s("upnpModel").innerHTML="사용자 패턴";
		$s("upnpEthno").innerHTML="네트워크 방식";
		$s("upnpAddr").innerHTML="서버 IP";
		$s("upnpDataport").innerHTML="장비 포트";
		$s("upnpHttpport").innerHTML="웹 포트";
		$s("upnpDataState").innerHTML="장비 포트 맵핑 상태";
		$s("upnpHttpState").innerHTML="웹 포트 맵핑 상태";
		$s("upnpReftime").innerHTML="업데이트 주기";
		$s("upnpH").innerHTML="시간";

		$s("upnpTalkport").innerHTML="토크백 포트";
		$s("upnpCmdport").innerHTML="명령 포트";
		$s("upnpTalkState").innerHTML="토크백 포트 맵핑 상태";
		$s("upnpCmdState").innerHTML="명령 포트 맵핑 상태";

		var upnp_model=document.getElementById("upnp_model");
		upnp_model.options[0].text="지정";
		upnp_model.options[1].text="자동";

		var upnp_ethno=document.getElementById("upnp_ethno");
		upnp_ethno.options[0].text="유선";
		upnp_ethno.options[1].text="무선";
		upnp_ethno.options[2].text="3G";
		$s("savesumbit").value="저장";
	}else if(type==3){//俄罗斯
		$s("upnp").innerHTML="UPNP настройки";
		$s("upnpOpen").innerHTML="Включить UPNP";
		$s("upnpModel").innerHTML="Исп. шаблон";
		$s("upnpEthno").innerHTML="Сетевая карта";
		$s("upnpAddr").innerHTML="Адрес сервера";
		$s("upnpDataport").innerHTML="Порт устройства";
		$s("upnpHttpport").innerHTML="Web порт";
		$s("upnpDataState").innerHTML="Статус порта устройства";
		$s("upnpHttpState").innerHTML="Статус WEB порта";
		$s("upnpReftime").innerHTML="Цикл обновления";
		$s("upnpH").innerHTML="Час";

		$s("upnpTalkport").innerHTML="Порт разговора";
		$s("upnpCmdport").innerHTML="Сигнальный порт";
		$s("upnpTalkState").innerHTML="Статус порта разговора";
		$s("upnpCmdState").innerHTML="Статус сигнального порта";

		var upnp_model=document.getElementById("upnp_model");
		upnp_model.options[0].text="Фикс. шаблон";
		upnp_model.options[1].text="Авто шаблон";

		var upnp_ethno=document.getElementById("upnp_ethno");
		upnp_ethno.options[0].text="Провод.";
		upnp_ethno.options[1].text="Беспров.";
		upnp_ethno.options[2].text="3G";
		$s("savesumbit").value="Сохр.";

	}
}
