function changeTheLanguage(type){
	setLanguage(type);
	if(type==0){//英文
		$s("policy").innerHTML="Video Plan";
		$s("paramChnNum").innerHTML="Channel Number";
		$s("policyREC").innerHTML="Record Section";
		$s("tdTime1").innerHTML="Record Section 1";
		$s("tdTime2").innerHTML="Record Section 2";
		$s("tdFulltime").innerHTML="Full-time";
		
		$s("tdEveryday").innerHTML="Everyday";
		$s("tdSun").innerHTML="Sunday";
		$s("tdMon").innerHTML="Monday";
		$s("tdTue").innerHTML="Tuesday";
		$s("tdWed").innerHTML="Wednesday";
		$s("tdThu").innerHTML="Thursday";
		$s("tdFri").innerHTML="Friday";
		$s("tdSat").innerHTML="Saturday";

		$s("policyParam").innerHTML="Record Parameter";
		$s("policyFull").innerHTML="Auto Cover";
		$s("Tdbitrate").innerHTML="Stream";
		$s("recordTimeTd").innerHTML="Pre-Recorded Time";
		$s("labelTime").innerHTML="Second";
		$s("bitrate").style.width="115px";
		$s("savesumbit").value="Save";
	}else if(type==1){//中文
		$s("policy").innerHTML="录像计划";
		$s("paramChnNum").innerHTML="通道号";
		$s("policyREC").innerHTML="录像时间";
		$s("tdTime1").innerHTML="录像时间段1";
		$s("tdTime2").innerHTML="录像时间段2";
		$s("tdFulltime").innerHTML="全天录像";
		
		$s("tdEveryday").innerHTML="每&nbsp;&nbsp;&nbsp;天";
		$s("tdSun").innerHTML="星期天";
		$s("tdMon").innerHTML="星期一";
		$s("tdTue").innerHTML="星期二";
		$s("tdWed").innerHTML="星期三";
		$s("tdThu").innerHTML="星期四";
		$s("tdFri").innerHTML="星期五";
		$s("tdSat").innerHTML="星期六";

		$s("policyParam").innerHTML="录像参数";
		$s("policyFull").innerHTML="自动覆盖";
		$s("Tdbitrate").innerHTML="码流选择";
		$s("recordTimeTd").innerHTML="预录时长";
		$s("labelTime").innerHTML="秒";
		$s("savesumbit").value="保存";
	}else if(type==2){//韩文
		$s("policy").innerHTML="녹화계획";
		$s("paramChnNum").innerHTML="채널 번호";
		$s("policyREC").innerHTML="녹화시간";
		$s("tdTime1").innerHTML="녹화 영역1";
		$s("tdTime2").innerHTML="녹화 영역2";
		$s("tdFulltime").innerHTML="종일녹화";
		
		$s("tdEveryday").innerHTML="매일";
		$s("tdSun").innerHTML="일요일";
		$s("tdMon").innerHTML="월요일";
		$s("tdTue").innerHTML="화요일";
		$s("tdWed").innerHTML="수요일";
		$s("tdThu").innerHTML="목요일";
		$s("tdFri").innerHTML="금요일";
		$s("tdSat").innerHTML="토요일";

		$s("policyParam").innerHTML="녹화값";
		$s("policyFull").innerHTML="자동 오버레이";
		$s("Tdbitrate").innerHTML="스트림";
		$s("recordTimeTd").innerHTML="사전 녹화시간";
		$s("labelTime").innerHTML="초";
		$s("savesumbit").value="저장";
	}else if(type==3){//俄罗斯
		$s("policy").innerHTML="Расписание";
		$s("paramChnNum").innerHTML="Номер канала";
		$s("policyREC").innerHTML="Секция запись";
		$s("tdTime1").innerHTML="Секция запись 1";
		$s("tdTime2").innerHTML="Секция запись 2";
		$s("tdFulltime").innerHTML="Все время";
		
		$s("tdEveryday").innerHTML="Каждый день";
		$s("tdSun").innerHTML="Воскресенье";
		$s("tdMon").innerHTML="Понедельник";
		$s("tdTue").innerHTML="Вторник";
		$s("tdWed").innerHTML="Среда";
		$s("tdThu").innerHTML="Четверг";
		$s("tdFri").innerHTML="Пятница";
		$s("tdSat").innerHTML="Суббота";

		$s("policyParam").innerHTML="Параметры записи";
		$s("policyFull").innerHTML="Автоперезапись";
		$s("Tdbitrate").innerHTML="Поток";
		$s("recordTimeTd").innerHTML="Предзапись время";
		$s("labelTime").innerHTML="Секунд";
		$s("savesumbit").value="Сохр.";
	}
}
