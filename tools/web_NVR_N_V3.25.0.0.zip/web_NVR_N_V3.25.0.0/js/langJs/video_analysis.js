function changeTheLanguage(type){
	setLanguage(type);
	if(type==0){//英文
		$s("videoAnalysis").innerHTML="Video Diagnosis";
		$s("openVideoAnalysis").innerHTML="Enable Video Diagnosis";
		$s("analysisTime").innerHTML="Time Of Diagnosis";
		$s("tdTimeBT").innerHTML="Begin Time";
		$s("tdTimeET").innerHTML="End Time";
		$s("tdTimeEnable").innerHTML="Enable";
		$s("tdTime1").innerHTML="Time1";
		$s("tdTime2").innerHTML="Time2";
		$s("tdTime3").innerHTML="Time3";
		$s("tdTime4").innerHTML="Time4";
		$s("abnormityType").innerHTML="Exception Types";
		$s("tdAbnormityLevel").innerHTML="Sensitivity";
		$s("tdAbnormityTime").innerHTML="Time";
		$s("tdAbnormityEnable").innerHTML="Enable";
		$s("abnormity0").innerHTML="Abnormal Brightness";
		$s("abnormity1").innerHTML="Abnormal Definition";
		$s("abnormity2").innerHTML="Abnormal noise";
		$s("abnormity3").innerHTML="Colour Cast";
		$s("abnormity4").innerHTML="Scene change";
		
		$s("savesumbit").value="Save";
	}else if(type==1){//中文		
		$s("videoAnalysis").innerHTML="视频诊断";
		$s("openVideoAnalysis").innerHTML="启用视频诊断";
		$s("analysisTime").innerHTML="诊断时间";
		$s("tdTimeBT").innerHTML="开始时间";
		$s("tdTimeET").innerHTML="结束时间";
		$s("tdTimeEnable").innerHTML="启用";
		$s("tdTime1").innerHTML="时间段1";
		$s("tdTime2").innerHTML="时间段2";
		$s("tdTime3").innerHTML="时间段3";
		$s("tdTime4").innerHTML="时间段4";
		$s("abnormityType").innerHTML="异常类型";
		$s("tdAbnormityLevel").innerHTML="灵敏度";
		$s("tdAbnormityTime").innerHTML="时长";
		$s("tdAbnormityEnable").innerHTML="启用";
		$s("abnormity0").innerHTML="亮度异常";
		$s("abnormity1").innerHTML="清晰度异常";
		$s("abnormity2").innerHTML="噪声异常";
		$s("abnormity3").innerHTML="偏色";
		$s("abnormity4").innerHTML="场景变换";

		$s("savesumbit").value="保存";
	}else if(type==2){//韩文
		$s("videoAnalysis").innerHTML="지능형 감지";
		$s("openVideoAnalysis").innerHTML="사용가능";
		$s("analysisTime").innerHTML="판독 시간";
		$s("tdTimeBT").innerHTML="시작시간";
		$s("tdTimeET").innerHTML="종료시간";
		$s("tdTimeEnable").innerHTML="사용";
		$s("tdTime1").innerHTML="시간1";
		$s("tdTime2").innerHTML="시간2";
		$s("tdTime3").innerHTML="시간3";
		$s("tdTime4").innerHTML="시간4";
		$s("abnormityType").innerHTML="오작동 시간";
		$s("tdAbnormityLevel").innerHTML="민감도";
		$s("tdAbnormityTime").innerHTML="시간";
		$s("tdAbnormityEnable").innerHTML="사용";
		$s("abnormity0").innerHTML="비정상 조도";
		$s("abnormity1").innerHTML="비정상 해상도";
		$s("abnormity2").innerHTML="비정상 노이즈";
		$s("abnormity3").innerHTML="비정상 색상";
		$s("abnormity4").innerHTML="화면 변경";

		$s("savesumbit").value="저장";
	}else if(type==3){//俄罗斯
		$s("videoAnalysis").innerHTML="Диагностика";
		$s("openVideoAnalysis").innerHTML="Включить видеодиагностику";
		$s("analysisTime").innerHTML="Время устранения неполадок";
		$s("tdTimeBT").innerHTML="Время начала";
		$s("tdTimeET").innerHTML="Время окончания";
		$s("tdTimeEnable").innerHTML="Включить";
		$s("tdTime1").innerHTML="Время1";
		$s("tdTime2").innerHTML="Время2";
		$s("tdTime3").innerHTML="Время3";
		$s("tdTime4").innerHTML="Время4";
		$s("abnormityType").innerHTML="Исключения";
		$s("tdAbnormityLevel").innerHTML="Чувствительность";
		$s("tdAbnormityTime").innerHTML="Время";
		$s("tdAbnormityEnable").innerHTML="Включить";
		$s("abnormity0").innerHTML="Аномальная яркость";
		$s("abnormity1").innerHTML="Аномальное определение";
		$s("abnormity2").innerHTML="Аномальный шум";
		$s("abnormity3").innerHTML="Цветовой оттенок";
		$s("abnormity4").innerHTML="Смена сцены";

		$s("savesumbit").value="Сохр.";
	}
}