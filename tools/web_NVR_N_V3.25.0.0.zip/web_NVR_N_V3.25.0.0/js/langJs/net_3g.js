function changeTheLanguage(type){
	setLanguage(type);
	if(type==0){//英文
		$s("net3G").innerHTML="3G Setting";
		$s("open3GTd").innerHTML="Opened 3G";
		$s("close3GTd").innerHTML="Closed 3G";

		$s("refurbish").value="Refresh";
		$s("refurbish").style.marginLeft="120px";
	}else if(type==1){//中文
		$s("net3G").innerHTML="3G服务";
		$s("open3GTd").innerHTML="已开启3G";
		$s("close3GTd").innerHTML="已关闭3G";

		$s("refurbish").value="刷新";
	}else if(type==2){//韩文
		$s("net3G").innerHTML="3G 세팅";
		$s("open3GTd").innerHTML="오픈 3G";
		$s("close3GTd").innerHTML="닫은 3G";

		$s("refurbish").value="재시도";
		$s("refurbish").style.marginLeft="120px";
	}else if(type==3){//俄罗斯
		$s("net3G").innerHTML="3G настройки";
		$s("open3GTd").innerHTML="Вкл. 3G";
		$s("close3GTd").innerHTML="Выкл. 3G";

		$s("refurbish").value="Сохр.";
	}
}
