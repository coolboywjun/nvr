function changeTheLanguage(type){
	setLanguage(type);
	if(type==0){//英文
		$s("platform").innerHTML="HXHT Platform Setting";
		$s("devicePUID").innerHTML="Device PUID";
		$s("serverAddr").innerHTML="Server IP";
		$s("serverPort").innerHTML="Server Port";
		$s("localVideoPort").innerHTML="Local Video Port";
		$s("localAudioPort").innerHTML="Local Audio	Port";
		$s("localMsgPort").innerHTML="Local Message Port";
		$s("localPlayPort").innerHTML="Local Playback Port";
		$s("maxConnectCount").innerHTML="Max Video Channels";
		$s("picUpload").innerHTML="Enable Picture Upload";
		$s("mapPort").innerHTML="Enable Mapping Port";

		$s("videoModel").innerHTML="NAT Penetration";
		var video_model=$s("video_model");
		video_model.options[0].text="Close";
		video_model.options[1].text="Open";

		$s("videoTransMode").innerHTML="Video Transmission Mode";
		var video_model=$s("video_TransMode");
		video_model.options[0].text="Normal";
		video_model.options[1].text="TIANYI Platform";

		$s("savesumbit").value="Save";
	}else if(type==1){//中文
		$s("platform").innerHTML="互信互通平台服务";
		$s("devicePUID").innerHTML="设备PUID";
		$s("serverAddr").innerHTML="服务器地址";
		$s("serverPort").innerHTML="服务器端口";
		$s("localVideoPort").innerHTML="本地视频端口";
		$s("localAudioPort").innerHTML="本地音频端口";
		$s("localMsgPort").innerHTML="本地消息端口";
		$s("localPlayPort").innerHTML="本地回放端口";
		$s("maxConnectCount").innerHTML="最大视频连接数";
		$s("picUpload").innerHTML="启用照片上传";
		$s("mapPort").innerHTML="自动映射服务端口";

		$s("videoModel").innerHTML="NAT穿透功能";
		var video_model=$s("video_model");
		video_model.options[0].text="关闭";
		video_model.options[1].text="开启";

		$s("videoTransMode").innerHTML="视频传输模式";
		var video_model=$s("video_TransMode");
		video_model.options[0].text="普通模式";
		video_model.options[1].text="天翼平台模式";

		$s("savesumbit").value="保存";
	}else if(type==2){//韩文
		$s("platform").innerHTML="플랫폼 서비스";
		$s("devicePUID").innerHTML="장비 PUID";
		$s("serverAddr").innerHTML="서버 주소";
		$s("serverPort").innerHTML="서버 포트";
		$s("localVideoPort").innerHTML="로컬 비디오 포트";
		$s("localAudioPort").innerHTML="로컬 오디오 포트";
		$s("localMsgPort").innerHTML="지역 뉴스 포트";
		$s("localPlayPort").innerHTML="로컬 재생 포트";
		$s("maxConnectCount").innerHTML="비디오 연결의 최대 수";
		$s("picUpload").innerHTML="활성화 사진 업로드";
		$s("mapPort").innerHTML="자동 매핑 서비스 포트";

		$s("videoModel").innerHTML="NAT 통과 기능";
		var video_model=$s("video_model");
		video_model.options[0].text="가까운";
		video_model.options[1].text="열려있는";

		$s("videoTransMode").innerHTML="비디오 전송 모드";
		var video_model=$s("video_TransMode");
		video_model.options[0].text="일반 모드";
		video_model.options[1].text="플랫폼 모델";

		$s("savesumbit").value="저장";

	}else if(type==3){//俄罗斯
		$s("platform").innerHTML="HXHT настройки";
		$s("devicePUID").innerHTML="PUID устройства";
		$s("serverAddr").innerHTML="Сервер IP";
		$s("serverPort").innerHTML="Сервер Порт";
		$s("localVideoPort").innerHTML="Лок. видео порт";
		$s("localAudioPort").innerHTML="Лок. аудио порт";
		$s("localMsgPort").innerHTML="Лок.порт сообщений";
		$s("localPlayPort").innerHTML="Лок.порт воспроизв";
		$s("maxConnectCount").innerHTML="Макс.число каналов";
		$s("picUpload").innerHTML="Вкл. выгрузку картинки";
		$s("mapPort").innerHTML="Вкл. сопоставление порта";

		$s("videoModel").innerHTML="Прохождение NAT";
		var video_model=$s("video_model");
		video_model.options[0].text="Закрыть";
		video_model.options[1].text="Открыть";

		$s("videoTransMode").innerHTML="Режим передачи видео";
		var video_model=$s("video_TransMode");
		video_model.options[0].text="Номально";
		video_model.options[1].text="TIANYI Платформа";

		$s("savesumbit").value="Сохр.";
	}
}
