function changeTheLanguage(type){
	setLanguage(type);
	if(type==0){//英文
		chnType1="Net";
		chnType2="Local";

		$s("chnConf").innerHTML="通道号";
		$s("chnInfo").innerHTML="通道信息";
		$s("devChnNum").innerHTML="通道号";
		$s("devChnName").innerHTML="通道名称";
		$s("devChnStatus").innerHTML="启用";
		$s("devChnType").innerHTML="通道类型";
		$s("devInfo").innerHTML="设备信息";
		$s("devIp").innerHTML="设备IP";
		$s("devPort").innerHTML="设备端口";
		$s("devType").innerHTML="设备类型";

		$s("tdDevIp").innerHTML="设备ip地址";
		$s("tdDevChnCount").innerHTML="设备通道数";
		$s("tdDevPort").innerHTML="设备端口";
		$s("tdDevChn").innerHTML="通道号";
		$s("tdDevUser").innerHTML="用户名";
		$s("tdEnable").innerHTML="启用DNS";
		$s("tdDevPwd").innerHTML="密码";
		$s("tdDevControl").innerHTML="传输协议";
		$s("tdDevAudio").innerHTML="启用音频";
		
		$s("searchBtn").value="Search";
		$s("savesumbit").value="Save";
	}else if(type==1){//中文
		chnType1="网络";
		chnType2="本地";
		
		$s("chnConf").innerHTML="通道号";
		$s("chnInfo").innerHTML="通道信息";
		$s("devChnNum").innerHTML="通道号";
		$s("devChnName").innerHTML="通道名称";
		$s("devChnStatus").innerHTML="启用";
		$s("devChnType").innerHTML="通道类型";
		$s("devInfo").innerHTML="设备信息";
		$s("devIp").innerHTML="设备IP";
		$s("devPort").innerHTML="设备端口";
		$s("devType").innerHTML="设备类型";

		$s("tdDevIp").innerHTML="设备ip地址";
		$s("tdDevChnCount").innerHTML="设备通道数";
		$s("tdDevPort").innerHTML="设备端口";
		$s("tdDevChn").innerHTML="通道号";
		$s("tdDevUser").innerHTML="用户名";
		$s("tdEnable").innerHTML="启用DNS";
		$s("tdDevPwd").innerHTML="密码";
		$s("tdDevControl").innerHTML="传输协议";
		$s("tdDevAudio").innerHTML="启用音频";

		$s("searchBtn").value="设备查询";
		$s("savesumbit").value="保存";
	}else if(type==2){//韩文
		chnType1="네트워크";
		chnType2="지방의";
		
		$s("chnConf").innerHTML="채널 번호";
		$s("chnInfo").innerHTML="채널 정보";
		$s("devChnNum").innerHTML="채널 번호";
		$s("devChnName").innerHTML="채널 이름";
		$s("devChnStatus").innerHTML="사용";
		$s("devChnType").innerHTML="채널 유형";
		$s("devInfo").innerHTML="장치 정보";
		$s("devIp").innerHTML="장치 IP";
		$s("devPort").innerHTML="장치 포트";
		$s("devType").innerHTML="设备类型";

		$s("tdDevIp").innerHTML="장비의 IP 주소";
		$s("tdDevChnCount").innerHTML="장치 채널";
		$s("tdDevPort").innerHTML="장치 포트";
		$s("tdDevChn").innerHTML="채널 번호";
		$s("tdDevUser").innerHTML="사용자";
		$s("tdEnable").innerHTML="DNS를 사용";
		$s("tdDevPwd").innerHTML="암호";
		$s("tdDevControl").innerHTML="전송 프로토콜";
		$s("tdDevAudio").innerHTML="오디오 활성화";

		$s("searchBtn").value="장비 조회";
		$s("savesumbit").value="저장";
	}else if(type==3){//俄罗斯
		chnType1="Сеть";
		chnType2="Локально";
		
		$s("chnConf").innerHTML="Номер канала";
		$s("chnInfo").innerHTML="Канал инф.";
		$s("devChnNum").innerHTML="Номер канала";
		$s("devChnName").innerHTML="Имя канала";
		$s("devChnStatus").innerHTML="Включить";
		$s("devChnType").innerHTML="Тип канала";
		$s("devInfo").innerHTML="Инфо об устр";
		$s("devIp").innerHTML="Устройство IP";
		$s("devPort").innerHTML="Порт";
		$s("devType").innerHTML="Тип устройства";

		$s("tdDevIp").innerHTML="IP-адрес устройства";
		$s("tdDevChnCount").innerHTML="Номер канала";
		$s("tdDevPort").innerHTML="Порт";
		$s("tdDevChn").innerHTML="Номер канала";
		$s("tdDevUser").innerHTML="Имя пользователя";
		$s("tdEnable").innerHTML="DNS";
		$s("tdDevPwd").innerHTML="Пароль";
		$s("tdDevControl").innerHTML="Протоколы";
		$s("tdDevAudio").innerHTML="Вкл. Звук";

		$s("searchBtn").value="Поиск";
		$s("savesumbit").value="Сохр.";
	}

}
