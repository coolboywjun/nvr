function changeTheLanguage(type){
	setLanguage(type);
	if(type==0){//英文
		tempWidth=530;

		$s("sysUpgrade").innerHTML="Device Upgrade";
		$s("sysUpgradeFile").innerHTML="Upgrade File";
		$s("sysUpgradeFile").style.paddingTop="3px";
		$s("DivConfirm").innerHTML="Enter Your Password";
		$s("Tdpsw").innerHTML="Password :";
		$s("pixel").innerHTML="Bad Pixel Check:";
		$s("iris").innerHTML="Iris Check:";
		$s("pixelNote").innerHTML="Block the lens or shut down the shutter before checking bad pixel. During the check, frame rate will drop, and will be restored after the check.";
		$s("irisNote").innerHTML=" Ensure the stability of the camera's lighting condition when checking Iris.";

		$s("browse").value="Browse";
		$s("upgrade").value="Upgrade";
		$s("defaultBtn").value="Reset";
		$s("rebootBtn").value="Reboot";
		$s("btnsubmit").value="Confirm";
		$s("defectBtn").value="Bad Pixel Check";
		$s("defectIrisBtn").value="Iris Check";
	}else if(type==1){//中文
		tempWidth=523;

		$s("sysUpgrade").innerHTML="系统升级";
		$s("sysUpgradeFile").innerHTML="选择升级文件";
		$s("DivConfirm").innerHTML="请输入你的登录密码";
		$s("Tdpsw").innerHTML="密码：";
		$s("pixel").innerHTML="坏点校正：";
		$s("iris").innerHTML="光圈校正：";
		$s("pixelNote").innerHTML="启动坏点校正功能前，需先遮黑镜头或关闭快门，在坏点检测过程中，图像会自动降帧，这属正常现象。校正完成后，图像会自动恢复正常。";
		$s("irisNote").innerHTML="做光圈校正时必须确保外部环境的亮度稳定。";

		$s("browse").value="浏览";
		$s("upgrade").value="升级";
		$s("defaultBtn").value="恢复出厂值";
		$s("rebootBtn").value="重启设备";
		$s("btnsubmit").value="确认";
		$s("defectBtn").value="坏点校正";
		$s("defectIrisBtn").value="光圈校正";
	}else if(type==2){//韩文
		tempWidth=523;

		$s("sysUpgrade").innerHTML="업그레이드";
		$s("sysUpgradeFile").innerHTML="업그레이드 파일";
		$s("DivConfirm").innerHTML="패스워드를 입력하세요";
		$s("Tdpsw").innerHTML="패스워드 :";
		$s("pixel").innerHTML="불량화소체크 : ";
		$s("iris").innerHTML="조리개체크 : ";
		$s("pixelNote").innerHTML="불량 교정 기능을 가동하기 전 렌즈의 까만 덮개 부분 혹은 셔터를 닫아주시고 불량을 검사하는 과정 중 화면의 프레임이 자동적으로 떨어질 수 있고, 이 현상은 지극히 정상적인 현상입니다. 교정 완료 후 영상은 다시 정상적으로 회복될 것 입니다.";
		$s("irisNote").innerHTML="조리개 교정 시 외부 환경의 밝기가 안정적으로 유지될 수 있게 해주시기 바랍니다";

		$s("browse").value="열기";
		$s("browseBtn").style.left="530px";
		$s("upgrade").value="업그레이드";
		$s("defaultBtn").value="기본 설정";
		$s("rebootBtn").value="리부팅";
		$s("btnsubmit").value="확인";
		$s("defectBtn").value="불량화소체크";
		$s("defectIrisBtn").value="조리개체크";

	}else if(type==3){//俄罗斯
		tempWidth=570;

		$s("sysUpgrade").innerHTML="Обновление";
		$s("sysUpgradeFile").innerHTML="Файл обновления";
		$s("DivConfirm").innerHTML="Введите пароль";
		$s("Tdpsw").innerHTML="Пароль : ";
		$s("pixel").innerHTML="Битые пиксели проверка:";
		$s("iris").innerHTML="Диафрагма проверка:";
		$s("pixelNote").innerHTML="Необходимо закрыть объектив для проверки битых пикселей. Возможно снижение к/с, после проверки будет восстановлено.";
		$s("irisNote").innerHTML="Для проверки работы диафрагмы нужен постоянный свет.";

		$s("browse").value="Обзор";
		$s("upgrade").value="Обновление";
		$s("defaultBtn").value="Сброс";
		$s("rebootBtn").value="Рестарт";
		$s("btnsubmit").value="Подтвердить";
		$s("defectBtn").value="ТестПикселей";
		$s("defectIrisBtn").value="ТестДиафр.";
	}
}
