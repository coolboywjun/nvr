function changeTheLanguage(type){
	if(type==0){//英文
		try{
			$s("aboutEdition").innerHTML="Web Version :";
			$s("aboutCopyRight").innerHTML="Copyright :";
			$s("aboutCompany").innerHTML=companyEN;
			$s("aboutCompanyUrl").innerHTML="Company Website :";
			$s("aboutURL").innerHTML=companyUrl;
			$s("aboutURL").href=companyUrl;
			$s("tdPhone").style.width="145px";
			$s("aboutPhoneNum").innerHTML="Technical Service :";
			$s("aboutNumFormat").innerHTML=phoneNumEN;
		}catch(e){}

		$s("btn").value="OK";
	}else if(type==1){//中文
		try{
			$s("aboutEdition").innerHTML="产品版本:";
			$s("aboutCopyRight").innerHTML="版权所有:";
			$s("aboutCompany").innerHTML=companyZH;
			$s("aboutCompanyUrl").innerHTML="公司网址:";
			$s("aboutURL").innerHTML=companyUrl;
			$s("aboutURL").href=companyUrl;
			$s("aboutPhoneNum").innerHTML="技术服务热线:";
			$s("aboutNumFormat").innerHTML=phoneNumZH;
		}catch(e){}

		$s("btn").value="确定";
	}else if(type==2){//韩文
		try{
			$s("aboutEdition").innerHTML="Web 버전 :";
			$s("aboutCopyRight").innerHTML="Copyright :";
			$s("aboutCompany").innerHTML=companyEN;
			$s("aboutCompanyUrl").innerHTML="Company Website :";
			$s("aboutURL").innerHTML=companyUrl;
			$s("aboutURL").href=companyUrl;
			$s("tdPhone").style.width="145px";
			$s("aboutPhoneNum").innerHTML="Technical Service :";
			$s("aboutNumFormat").innerHTML=phoneNumEN;
		}catch(e){}

		$s("btn").value="OK";
	}else if(type==3){//俄罗斯
		try{
			$s("aboutEdition").innerHTML="Web версия :";
			$s("aboutCopyRight").innerHTML="Авт. Права :";
			$s("aboutCompany").innerHTML=companyEN;
			$s("aboutCompanyUrl").innerHTML="Сайт :";
			$s("aboutURL").innerHTML=companyUrl;
			$s("aboutURL").href=companyUrl;
			$s("tdPhone").style.width="145px";
			$s("aboutPhoneNum").innerHTML="Тех. сервис :";
			$s("aboutNumFormat").innerHTML=phoneNumEN;
		}catch(e){}

		$s("btn").value="OK";
	}
	
}
