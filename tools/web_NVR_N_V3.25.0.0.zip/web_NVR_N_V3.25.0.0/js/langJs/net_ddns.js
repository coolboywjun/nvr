function changeTheLanguage(type){
	setLanguage(type);
	if(type==0){//英文
		$s("ddns").innerHTML="DDNS Setting";
		$s("ddnsOpen").innerHTML="Enable DDNS";
		$s("ddnsType").innerHTML="Provider";
		$s("ddnsPort").innerHTML="Server Port";
		$s("ddnsAccount").innerHTML="Domain";
		$s("ddnsUser").innerHTML="User Name";
		$s("ddnsPwd").innerHTML="Password";
		$s("ddnsOnline").innerHTML="Update Cycle";
		$s("ddnsH").innerHTML="Hour";

		$s("savesumbit").value="Save";
	}else if(type==1){//中文
		$s("ddns").innerHTML="DDNS服务";
		$s("ddnsOpen").innerHTML="启用DDNS";
		$s("ddnsType").innerHTML="服务提供商";
		$s("ddnsPort").innerHTML="服务器端口";
		$s("ddnsAccount").innerHTML="主机域名";
		$s("ddnsUser").innerHTML="注册名";
		$s("ddnsPwd").innerHTML="密码";
		$s("ddnsOnline").innerHTML="刷新间隔";
		$s("ddnsH").innerHTML="小时";

		$s("savesumbit").value="保存";
	}else if(type==2){//韩文
		$s("ddns").innerHTML="DDNS 설정";
		$s("ddnsOpen").innerHTML="DDNS 활성화";
		$s("ddnsType").innerHTML="제공자";
		$s("ddnsPort").innerHTML="서버 포트";
		$s("ddnsAccount").innerHTML="도메인";
		$s("ddnsUser").innerHTML="사용자 이름";
		$s("ddnsPwd").innerHTML="비밀번호";
		$s("ddnsOnline").innerHTML="업데이트 주기";
		$s("ddnsH").innerHTML="시간";

		$s("savesumbit").value="저장";
	}else if(type==3){//俄罗斯
		$s("ddns").innerHTML="DDNS настройки";
		$s("ddnsOpen").innerHTML="Включить DDNS";
		$s("ddnsType").innerHTML="Провайдер";
		$s("ddnsPort").innerHTML="Серверный порт";
		$s("ddnsAccount").innerHTML="Домен";
		$s("ddnsUser").innerHTML="Имя пользователя";
		$s("ddnsPwd").innerHTML="Пароль";
		$s("ddnsOnline").innerHTML="Цикл обновления";
		$s("ddnsH").innerHTML="Час";

		$s("savesumbit").value="Сохр.";
	}
}
