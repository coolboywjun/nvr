function changeTheLanguage(type){
	setLanguage(type);
	if(type==0){//英文
		$s("info").innerHTML="System Setting";
		//$s("infoDeviceName").innerHTML="Device Type";
		$s("infoChnCount").innerHTML="Channels";
		$s("companyInfo").innerHTML="Manufacturer Information";
		$s("makeDate").innerHTML="Release Date";
		$s("devVersion").innerHTML="Device Version";
		$s("infoHw").innerHTML="Hardware";
		$s("devType").innerHTML="Device Type";
		$s("devMachineType").innerHTML="Device Style";
		$s("infoAlarmIn").innerHTML="Alarm Inputs";
		$s("infoAlarmOut").innerHTML="Alarm Outputs";
		$s("infoRs485").innerHTML="485 Ports";
		$s("infoRs232").innerHTML="232 Ports";

		$s("savesumbit").value="Save";
	}else if(type==1){//中文
		$s("info").innerHTML="设备信息";
		//$s("infoDeviceName").innerHTML="设备名称";
		$s("infoChnCount").innerHTML="通道数";
		$s("companyInfo").innerHTML="厂家信息";
		$s("makeDate").innerHTML="编译日期";
		$s("devVersion").innerHTML="设备版本";
		$s("infoHw").innerHTML="硬件版本";
		$s("devType").innerHTML="设备类型";
		$s("devMachineType").innerHTML="设备机器类型";
		$s("infoAlarmIn").innerHTML="告警输入路数";
		$s("infoAlarmOut").innerHTML="告警输出路数";
		$s("infoRs485").innerHTML="RS485数";
		$s("infoRs232").innerHTML="RS232数";

		$s("savesumbit").value="保存";
	}else if(type==2){//韩文
		$s("info").innerHTML="기본 정보";
		//$s("infoDeviceName").innerHTML="장비 타입";
		$s("infoChnCount").innerHTML="비디오 출력 채널";
		$s("companyInfo").innerHTML="회사정보";
		$s("makeDate").innerHTML="날짜";
		$s("devVersion").innerHTML="장비버전";
		$s("infoHw").innerHTML="H/W 버전";
		$s("devType").innerHTML="장비종류";
		$s("devMachineType").innerHTML="제품종류";
		$s("infoAlarmIn").innerHTML="알람 입력 채널";
		$s("infoAlarmOut").innerHTML="알람 출력 채널";
		$s("infoRs485").innerHTML="RS485 포트";
		$s("infoRs232").innerHTML="RS232 포트";

		$s("savesumbit").value="저장";
	}else if(type==3){//俄罗斯
		$s("info").innerHTML="Сист. Настройки";
		//$s("infoDeviceName").innerHTML="Тип";
		$s("infoChnCount").innerHTML="Каналов";
		$s("companyInfo").innerHTML="Производитель";
		$s("makeDate").innerHTML="Дата выпуска";
		$s("devVersion").innerHTML="Версия устройства";
		$s("infoHw").innerHTML="Аппаратная";
		$s("devType").innerHTML="Тип";
		$s("devMachineType").innerHTML="Стиль";
		$s("infoAlarmIn").innerHTML="Трев. Входы";
		$s("infoAlarmOut").innerHTML="Трев. Выходы";
		$s("infoRs485").innerHTML="485 порты";
		$s("infoRs232").innerHTML="232 порты";

		$s("savesumbit").value="Сохр.";
	}
}