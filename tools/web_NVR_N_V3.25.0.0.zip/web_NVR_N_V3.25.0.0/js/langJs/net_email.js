function changeTheLanguage(type){
	setLanguage(type);
	if(type==0){//英文
		$s("email").innerHTML="Email Setting";
		$s("emailServer").innerHTML="SMTP Server";
		$s("emailPort").innerHTML="SMTP Port";
		$s("emailSend").innerHTML="Sender Address";
		$s("emailUsername").innerHTML="SMTP User Name";
		$s("emailPassword").innerHTML="SMTP Password";
		$s("emailRecv1").innerHTML="Receiver Address 1";
		$s("emailRecv2").innerHTML="Receiver Address 2";
		$s("emailRecv3").innerHTML="Receiver Address 3";
		$s("emailSsl").innerHTML="SSL";

		$s("savesumbit").value="Save";
	}else if(type==1){//中文
		$s("email").innerHTML="EMAIL服务";
		$s("emailServer").innerHTML="SMTP服务器";
		$s("emailPort").innerHTML="SMTP端口";
		$s("emailSend").innerHTML="邮件发送地址";
		$s("emailUsername").innerHTML="SMTP用户名";
		$s("emailPassword").innerHTML="SMTP密码";
		$s("emailRecv1").innerHTML="邮件接收地址1";
		$s("emailRecv2").innerHTML="邮件接收地址2";
		$s("emailRecv3").innerHTML="邮件接收地址3";
		$s("emailSsl").innerHTML="使用SSL";

		$s("savesumbit").value="保存";
	}else if(type==2){//韩文
		$s("email").innerHTML="이메일 설정";
		$s("emailServer").innerHTML="SMTP 서버";
		$s("emailPort").innerHTML="SMTP 포트";
		$s("emailSend").innerHTML="발신자 주소";
		$s("emailUsername").innerHTML="SMTP 사용자 이름";
		$s("emailPassword").innerHTML="SMTP 비밀번호";
		$s("emailRecv1").innerHTML="수신자 주소1";
		$s("emailRecv2").innerHTML="수신자 주소2";
		$s("emailRecv3").innerHTML="수신자 주소3";
		$s("emailSsl").innerHTML="SSL";

		$s("savesumbit").value="저장";
	}else if(type==3){//俄罗斯
		$s("email").innerHTML="Настройки Email";
		$s("emailServer").innerHTML="SMTP Сервер";
		$s("emailPort").innerHTML="SMTP Порт";
		$s("emailSend").innerHTML="Адрес отправителя";
		$s("emailUsername").innerHTML="Имя";
		$s("emailPassword").innerHTML="Пароль";
		$s("emailRecv1").innerHTML="Адрес получателя 1";
		$s("emailRecv2").innerHTML="Адрес получателя 2";
		$s("emailRecv3").innerHTML="Адрес получателя 3";
		$s("emailSsl").innerHTML="SSL";

		$s("savesumbit").value="Сохр.";
	}
}
