var version="V3.25.0_N";
var companyUrl="";
var companyZH="";
var companyEN="";
var phoneNumZH="";
var phoneNumEN="";
