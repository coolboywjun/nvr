var handleID;			//控件登录成功后的句柄
var childHandleID;		//子页面控件登录成功后的句柄
var wndIndex=0;			//分屏窗口序列号
var selectChnNum=-1;	//当前选中窗口的通道号，默认无通道号-1
var systemCapability;	//能力集
var systemDevInfo;		//设备信息
var currentStreamType;	//当前码流
var currentAlarmType=-1;//当前报警类型
var currentAlarmTypeChn=-1;//当前报警类型通道

var totalPreviewCount=0;	//当前开始视频数
var totalRecordCount=0		//当前录像数
var totalTalkCount=0;		//当前对讲数
var totalAudioCount=0;		//当前监听数

var isUpgradeFlag=false;	//用于判断是否正在升级
var loginSuccess=false;
var hasCapability=true;
var previewLoadDone=false;
var caretaker="看守位";		//看守位

var set_language="";	//0：英文，1：中文

var srcAvailHeight;
var srcAvailWidth;
var minHeight;			//最小高度
var minPercent=0.60;	//最小高度比

var versionTopWidth=180;
var versionMainWidth=0;

//初始化菜单
function initMenu(){
	if(!previewLoadDone){
		alert(browser_error);
		closeFunction();
		//window.open("login.asp", "", "width="+screen.width+", height="+screen.height
		//	+", top=0, left=0, toolbar=yes, menubar=yes, scrollbars=yes, Resizable=yes,location=yes,status=yes");
		return;
	}
	checkOuttime();

	imgOffset=dd.elements.track.x;//初始化设置图片偏移量
	//$s("chnCount").value=16;
	if($s("chnCount").value>1){//多通道
		$s("chnListFlag").value="1";
		$w("alarmImgTd").style.display="none";
		$w("td5").style.display="none";
		$w("recordImgId").style.display="none";
		$w("td1").style.display="none";
	}

	if($s("devType").value==3){//nvr
		$s("sub6-5").style.display="block";
	}

	if(screen.height<750)//分辨率高度小于750
		minPercent=0.85;
	else if(750<=screen.height && screen.height<=800)
		minPercent=0.75;

	/*var versionInfo = navigator.appVersion;
	var start = versionInfo.indexOf("MSIE");
	var verionNumber=versionInfo.slice(start+5, versionInfo.length);
	verionNumber=verionNumber.slice(0, verionNumber.indexOf("."));
	if(verionNumber=="10"){
		versionTopWidth=220;
		$s("yuntaiDD").style.marginLeft=0;
		versionMainWidth=16;
	}*/
	
	minHeight=parseInt(screen.availHeight*minPercent)+126;//页面最小高度
	timingResize();

	isUpgradeFlag=false;

	init();
}

//定时获取窗口大小，并调整
function timingResize(){
	if(srcAvailHeight!=document.body.clientHeight){//实时设置高度
		srcAvailHeight=document.body.clientHeight;
		if(srcAvailHeight<minHeight){
			srcAvailHeight=minHeight;
		}
		$s("main").style.height=parent.document.body.clientHeight-103;
		if(document.getElementById("videoPre").name=="1"){
			document.getElementById("leftpreview").style.height=srcAvailHeight-126;
			$w("videoId").style.height=srcAvailHeight-165;
			document.getElementById("rightList").style.height=srcAvailHeight-159;
		}else{
			document.getElementById("leftmenu").style.height=srcAvailHeight-126;
			document.getElementById("setpanel").style.height=srcAvailHeight-165;
			document.getElementById("rightList").style.height=srcAvailHeight-159;
		}
	}
	if(srcAvailWidth!=document.body.clientWidth){//实时设置宽度
		srcAvailWidth=document.body.clientWidth;
		if(srcAvailWidth<1000){
			srcAvailWidth=1000;
		}
		$s("topbg").style.width=srcAvailWidth;
		$s("toplogo").style.width=srcAvailWidth;
		$s("main").style.width=srcAvailWidth-versionMainWidth;
		$s("mainMenuBtn").style.marginLeft=srcAvailWidth-versionTopWidth;
		var tempWidth=0;
		if(document.getElementById("videoPre").name=="1"){
			if($s("chnListFlag").value=="1" && $w("showChnListImg").value=="1")//多通道，并且显示列表
				tempWidth=184;
		}
		$s("container").style.width=srcAvailWidth-210-tempWidth;
		$w("rbannercontact").style.width=srcAvailWidth-230-tempWidth;
		$s("rbannercontact").style.width=srcAvailWidth-230-tempWidth;
	}
	setTimeout(timingResize, 10);
}


var ptzIpc=null;//控件对象
var HighSpeedIRBall;//高速球参数对象

//初始化
function init(){
	if($s("chnListFlag").value=="1"){
		$s("rightChnList").style.display="block";
		$w("chnListDiv").style.display="block";
		$w("showChnListImg").title=chnListmsg1;
	}

	$("#leftmenu").hide();
	//$("#leftpreview").show();
	$s("leftpreview").style.visibility="";
	$("#setpanel").hide();
	$("#previewpanel").show();

	document.getElementById("thumbdIi15v").style.display="block";
	document.getElementById("trackdIi15v").style.display="block";
	document.getElementById("track2dIi15v").style.display="block";
	
	ptzIpc=$w("ipc");

	//初始化预置号
	var preset=document.getElementById("preset");
	preset.length=0;
	if($s("fastBallFlag").value=="0"){//不是高速球
		$s("ptzSetting").style.display="none";
		for(var i=1;i<=255;i++){
			preset.options[i-1]=new Option(i, i);
		}
	}else{//高速球
		$s("ptzSetting").style.display="block";
		preset.options[0]=new Option(caretaker, -1);
		for(var i=1;i<=255;i++){
			preset.options[i]=new Option(i, i);
		}
		initGSQctrl();//初始化高速球
		hookCheckbox();//初始化所有checkbox
		getJsonData();
	}
	
	setSelectMap();//初始化下拉框数据
	////////////////////////////////////////设置通道列表
	var tableData="";
	var typeName="Channel ";
	for(var i=1;i<=$s("chnCount").value;i++){
		tableData+="<tr><td><img src='images/chnList/chnList-6.jpg' id='previewImg"+i+"' onclick='previewImgClick("+(i-1)+", this)' name='0'/></td>"
			+"<td><img src='images/chnList/chnList-7.jpg' id='recordImg"+i+"' onclick='enableManualREC("+(i-1)+", this)' name='0'/></td><td>"+typeName+i+"</td></tr>";
	}
	//alert(tableData);
	$s("chnListTable").innerHTML="<table width='130px' border=0>"+tableData+"</table>";
	
	////////////////////////////////////////end设置通道列表
}

function previewImgClick(chn, obj){
	var curWnd=ptzIpc.GetChnNumFromWnd(wndIndex, handleID);//获取当前窗口的通道号
	if(obj.name=="0" && curWnd!=-1){
		enableStream(curWnd, document.getElementById("previewImg"+(curWnd+1)));
	}
	enableStream(chn, obj);
}

//开启/关闭视频流
function enableStream(chn, obj){
	//alert(chn+" "+obj.id);
	if(obj.name=="0"){
		//alert(chn+" "+wndIndex);
		ptzIpc.StartStream(chn, wndIndex,  handleID);//开启视频流
		obj.src="images/chnList/chnList-4.jpg";
		obj.name=1;
	}else{
		if(ptzIpc.IsAudio(chn, handleID)){//停止监听
			//alert("监听");
			ptzIpc.StopAudio(chn, handleID);
		}
		if(ptzIpc.IsTalk(0, handleID)){//停止对讲
			//alert("对讲");
			ptzIpc.StopTalk(0, handleID);
		}

		ptzIpc.StopStream(chn, handleID);
		obj.src="images/chnList/chnList-6.jpg";//关闭视频流
		obj.name="0";
		if(ptzIpc.IsRec(chn, handleID)){//停止录像
			//ptzIpc.StopREC(chn, handleID);
			enableManualREC(chn, document.getElementById("recordImg"+(chn+1)));
		}
		if(selectChnNum==chn){
			/*$w("btn_talk").src="images/web_37.jpg";
			$w("btn_talk").name="1";
			$w("btn_audio").src="images/web_28.jpg";
			$w("btn_audio").name="1";*/
			selectChnNum=-1;
		}
	}
}

//开启/关闭手动录像
function enableManualREC(chn, obj){
	if(obj.name=="0"){
		if(ptzIpc.IsStartStream(chn, handleID)==0){
			return;
		}
		ptzIpc.StartREC(chn, handleID);//开启录像
		/*totalRecordCount++;
		obj.src="images/chnList/chnList-5.jpg";
		obj.name=1;*/
	}else{
		ptzIpc.StopREC(chn, handleID);
		/*totalRecordCount--;
		obj.src="images/chnList/chnList-7.jpg";//关闭录像
		obj.name="0";*/
	}
}

var ptzFlag=0;				//0：开启云台控制	1：关闭云台控制		用于解决云台onmouseout问题
//云台控制
function ptzControl(pthis,isUp){
	if(selectChnNum==-1){
		return;
	}
	var nSpeed=parseInt(document.getElementById('sliderDragVal').value);//速度
	if(isUp){
		if(ptzFlag==1){
			clearTimeout(durationTimeout);
			var data='{"type":'+0+',"value":'+0+'}';
			ptzIpc.setJSONDataForCtrl("PTZ", data, selectChnNum, handleID);
			ptzFlag=0;
		}
	}else{
		if(ptzFlag==0){
			ptzFlag=1;
			durationCtrl(parseInt(pthis.value), nSpeed);
		}
	}
}

var durationTimeout;
function durationCtrl(ptzVal, nSpeed){
	var data='{"type":'+ptzVal+',"value":'+nSpeed+'}';
	ptzIpc.setJSONDataForCtrl("PTZ", data, selectChnNum, handleID);
	durationTimeout=setTimeout("durationCtrl("+ptzVal+","+nSpeed+")", 2000);
}

//云台自动
function ptzAutoClick(obj){
	if(selectChnNum==-1){
		return;
	}
	var autoValue=obj.value;
	var nSpeed=parseInt(document.getElementById('sliderDragVal').value);//速度
	if(autoValue=="1"){//自动
		obj.src="images3/web3_113.jpg";
		obj.value="0";
	}else {//停止
		obj.src="images/web_113.jpg";
		obj.value="1";
	}
	var data='{"type":'+autoValue+',"value":'+nSpeed+'}';
	ptzIpc.setJSONDataForCtrl("PTZ", data, selectChnNum, handleID);
}

//预置号
function presetConf(type){
	if(selectChnNum==-1){
		return;
	}
	var index=document.getElementById("preset").value;//预置位索引
	if(index=="0"){//预置号不能为0
		alert(preset_msg);
		return;
	}else if(index=="-1"){//看守位
		/*var nSpeed=parseInt(document.getElementById('sliderDragVal').value);//速度
		if(type==18){//设置看守位
			ptzIpc.PtzCtrl(selectChnNum, 1002, nSpeed);
		}else if(type==20){//调用看守位
			ptzIpc.PtzCtrl(selectChnNum, 1003, nSpeed);
		}*/
		return;
	}else{
		var data='{"type":'+type+',"value":'+index+'}';
		ptzIpc.setJSONDataForCtrl("PTZ", data, selectChnNum, handleID);
	}
}

var subTime;
function subTimeout(objVal){//云台速度-
	if(objVal>=1){
		objVal=objVal-1;
		setSliderVal(objVal);
		ptzIpc.SetPTZSpeed(objVal, handleID);
		document.getElementById('sliderDragVal').value=objVal;
	}else{
		clearTimeout(subTime);
		return;
	}
	subTime=setTimeout("subTimeout("+objVal+")", 200);
}
var addTime;
function addTimeout(objVal){//云台速度+
	if(objVal>=0 && objVal<100){
		objVal=objVal+1;
		setSliderVal(objVal);
		ptzIpc.SetPTZSpeed(objVal, handleID);
		document.getElementById('sliderDragVal').value=objVal;
	}else{
		clearTimeout(addTime);
		return;
	}
	addTime=setTimeout("addTimeout("+objVal+")", 200);
}

//关于
function aboutMenuClick(){
	var strFeatures="dialogWidth:400px; dialogHeight:320px; resizable:no; help:no; center:yes; status:no; scroll:no; maximize:no; minimize:no;";
	window.showModalDialog("about.htm", set_language, strFeatures);
}

function escKeyDownMain(){
	/*if (document.getElementById("videoPre").name=="1" && event.keyCode == 27){//esc键，退出/开启 全屏
		var ctrlType=$w("ipc").GetFullScreenType(handleID);//获取全屏操作类型
		if(ctrlType==1 || ctrlType==3){
			$w("ipc").FullScreen(-1, 8, handleID);//退出全屏
			$w("ipc").FullScreen(-1, 4, handleID);
		}
	}*/
}

function getJsonData(){
	if(loginSuccess){
		ptzIpc.JSONReq('{"HighSpeedIRBall":""}');//获取json数据,登录成功后才能获取高速球数据
		return;
	}
	setTimeout(getJsonData, 100);
}

//云台控制切换
function switchCtrl(currentObj, otherObj, currentCtrl, otherCtrl){
	currentCtrl.style.display="block";
	otherCtrl.style.display="none";

	currentObj.className="currentPTZsetting";
	otherObj.className="otherPTZsetting";

	$s("topbg").focus();
}

//实现层移动
var curObj='';//div窗口对象
var pX;
var pY;
document.onmouseup=MUp;
document.onmousemove=MMove;
function MDown(objId){
	curObj=objId;
	document.all(curObj).setCapture();
	pX=event.x-document.all(curObj).style.pixelLeft;
	pY=event.y-document.all(curObj).style.pixelTop;
}
function MMove(){
	if(curObj!=''){
		document.all(curObj).style.left=event.x-pX;
		document.all(curObj).style.top=event.y-pY;
		if(document.all(curObj).style.left.substring(0,document.all(curObj).style.left.length-2)<0){//左边框
			document.all(curObj).style.left=0;
		}
		if(document.all(curObj).style.top.substring(0,document.all(curObj).style.top.length-2)<0){//顶边框
			document.all(curObj).style.top=0;
		}
		document.getElementById(curObj+"Frame").style.top = document.all(curObj).style.top;
		document.getElementById(curObj+"Frame").style.left = document.all(curObj).style.left;
	}
}
function MUp(){
	if(curObj!=''){
		document.all(curObj).releaseCapture();
		curObj='';
	}
}

//初始化高速球窗口位置
function gsqBtnSet(divObj, frameObj ,yHeight){
	var curDivObj=document.getElementById(divObj);
	var iframeDivObj=document.getElementById(frameObj);//iframe层遮挡select,object,slider
	tmptop = event.y-yHeight;
	tmpleft= event.x-150;
	curDivObj.style.display='';
	curDivObj.style.left=tmpleft + "px";
	curDivObj.style.top=tmptop + "px";
	iframeDivObj.style.width = curDivObj.offsetWidth;
	iframeDivObj.style.height = curDivObj.offsetHeight;
	iframeDivObj.style.top = curDivObj.style.top;
	iframeDivObj.style.left = curDivObj.style.left;
	iframeDivObj.style.zIndex = curDivObj.style.zIndex - 1;
	iframeDivObj.style.display = "block";
	curDivObj.style.visibility='visible';
}

//设置扫描控制
function clickScanCtrl(){
	var scanTemp=document.getElementById("smkzSelect").value;
	if(scanTemp==0){
		for(var i=1;i<=16;i++){//获取巡航扫描数据
			//alert(HighSpeedIRBall.CruiseNode[i-1].Enable+" "+HighSpeedIRBall.CruiseNode[i-1].DurationSec+" "+HighSpeedIRBall.CruiseNode[i-1].Speed);
			document.getElementById("chk"+i).checked=HighSpeedIRBall.CruiseNode[i-1].Enable;
			document.getElementById("sec"+i).value=HighSpeedIRBall.CruiseNode[i-1].DurationSec;
			document.getElementById("speed"+i).value=HighSpeedIRBall.CruiseNode[i-1].Speed;
		}
		gsqBtnSet('cruiseScan', 'cruiseScanFrame', 150);//巡航组扫描
	}else if(scanTemp==1){//获取自动扫描数据
		document.getElementById("autoScanSpeed").value=HighSpeedIRBall.Setting.AutoScanSpeed;
		document.getElementById("autoScanChk").checked=false;
		gsqBtnSet('autoScan', 'autoScanFrame', 0);//自动扫描
	}else if(scanTemp==2){//获取AB两点扫描数据
		document.getElementById("ABpointScanSpeed").value=HighSpeedIRBall.Setting.ABScanSpeed;
		document.getElementById("ABpointScanChk").checked=false;
		gsqBtnSet('ABpointScan', 'ABpointScanFrame', 0);//AB两点扫描
	}
}

//停止扫描控制
function stopScanCtrl(){
	var data='{"type":'+17+',"value":'+0+'}';
	ptzIpc.setJSONDataForCtrl("PTZ", data, selectChnNum, handleID);
}

//开始扫描控制
function startScanCtrl(){
	var nSpeed=parseInt(document.getElementById('sliderDragVal').value);//速度
	var scanTemp=document.getElementById("smkzSelect").value;
	if(scanTemp==0){
		ptzIpc.PtzCtrl(selectChnNum, 1001, nSpeed);//巡航组扫描
	}else if(scanTemp==1){
		ptzIpc.PtzCtrl(selectChnNum, 1005, nSpeed);//自动扫描
	}else if(scanTemp==2){
		ptzIpc.PtzCtrl(selectChnNum, 1009, nSpeed);//AB两点扫描
	}
}

//获取闲置动作参数
function xzdzSetVal(){
	if(document.getElementById("xzdzSelect").value==HighSpeedIRBall.Setting.IdleActionIndex.toString())
		document.getElementById("freeTime").value=HighSpeedIRBall.Setting.IdleSec.toString();
	else document.getElementById("freeTime").value=30;
}

//获取报警动作参数
function bjdzSetVal(){
	if(document.getElementById("bjdzSelect").value==HighSpeedIRBall.Alarm.ActionIndex.toString())
		document.getElementById("alarmTime").value=HighSpeedIRBall.Alarm.DurationSec.toString();
	else document.getElementById("alarmTime").value=30;
}

//获取定时动作参数
function dsdzSetVal(){
	for(var i=1;i<=8;i++){
		document.getElementById("bh_"+i).value=HighSpeedIRBall.Ontime[i-1].BeginHour;
		document.getElementById("bm_"+i).value=HighSpeedIRBall.Ontime[i-1].BeginMin;
		document.getElementById("eh_"+i).value=HighSpeedIRBall.Ontime[i-1].EndHour;
		document.getElementById("em_"+i).value=HighSpeedIRBall.Ontime[i-1].EndMin;
		document.getElementById("actionSelect"+i).value=HighSpeedIRBall.Ontime[i-1].ActionIndex;
	}
}

//重置定时动作
function resetTimeAction(){
	for(var i=1;i<=8;i++){
		document.getElementById("bh_"+i).value=0;
		document.getElementById("bm_"+i).value=0;
		document.getElementById("eh_"+i).value=0;
		document.getElementById("em_"+i).value=0;
		document.getElementById("actionSelect"+i).value=0;
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////初始化高速球控件
function initGSQctrl(){
	var autoScanSpeed=document.getElementById("autoScanSpeed");//自动扫描
	autoScanSpeed.length=0;
	var ABpointScanSpeed=document.getElementById("ABpointScanSpeed");//AB两点扫描
	ABpointScanSpeed.length=0;
	for(var i=10;i<=80;i++){
		autoScanSpeed.options[(i-10)]=new Option(i, i);
		ABpointScanSpeed.options[(i-10)]=new Option(i, i);
	}
	var freeTime=document.getElementById("freeTime");//闲置动作
	freeTime.length=0;
	var alarmTime=document.getElementById("alarmTime");//报警动作
	alarmTime.length=0;
	for(var i=3;i<=240;i++){
		alarmTime.options[(i-3)]=new Option(i, i);
		if(i>=30){
			freeTime.options[(i-30)]=new Option(i, i);
		}
	}
	var tempSec;
	var tempSpeed;
	for(var i=1;i<=16;i++){
		tempSec=document.getElementById("sec"+i);//巡航扫描-秒
		tempSec.length=0;
		for(var m=3;m<=240;m++){
			tempSec.options[(m-3)]=new Option(m, m);
		}
		tempSpeed=document.getElementById("speed"+i);//巡航扫描-速度
		tempSpeed.length=0;
		for(var n=10;n<=120;n++){
			tempSpeed.options[(n-10)]=new Option(n, n);
		}
	}
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////高速球数据提交
function cruiseScanSubmit(){//设置自动巡航:设备通道号,预置点索引(1~20),是否启用,停留时长(秒,3~240秒),移动速度(10~120)
	var tempChk;
	var tempSec;
	var tempSpeed;
	for(var i=1;i<=16;i++){
		tempSec=document.getElementById("sec"+i).value;
		tempSpeed=document.getElementById("speed"+i).value;
		if(document.getElementById("chk"+i).checked)
			tempChk=1;
		else
			tempChk=0;
		ptzIpc.PtzCruise(selectChnNum, (i-1), tempChk, tempSec, tempSpeed);
		HighSpeedIRBall.CruiseNode[i-1].Enable=tempChk;
		HighSpeedIRBall.CruiseNode[i-1].DurationSec=parseInt(tempSec,10);
		HighSpeedIRBall.CruiseNode[i-1].Speed=parseInt(tempSpeed,10);
	}
	document.getElementById("cruiseScanClose").click();
}

function autoScanSubmit(){//设置自动扫描:设备通道号,是否设置为垂直位置,移动速度(10~80)
	var tempChk;
	if(document.getElementById("autoScanChk").checked)
		tempChk=1;
	else tempChk=0;
	ptzIpc.PtzAutoScan(selectChnNum, tempChk, document.getElementById("autoScanSpeed").value);
	HighSpeedIRBall.Setting.AutoScanSpeed=parseInt(document.getElementById("autoScanSpeed").value,10);
	document.getElementById("autoScanClose").click();
}

function ABpointScanSubmit(){//设置AB两点扫描:设备通道号,是否设置为垂直位置,移动速度(10~80)
	var tempChk;
	if(document.getElementById("ABpointScanChk").checked)
		tempChk=1;
	else tempChk=0;
	ptzIpc.PtzABScan(selectChnNum, tempChk, document.getElementById("ABpointScanSpeed").value);
	HighSpeedIRBall.Setting.ABScanSpeed=parseInt(document.getElementById("ABpointScanSpeed").value,10);
	document.getElementById("ABpointScanClose").click();
}

function freeActionSubmit(){//设置闲置动作:设备通道号,动作索引号,停留时长(秒,30~240秒)
	ptzIpc.PtzSetIdle(selectChnNum, document.getElementById("xzdzSelect").value, document.getElementById("freeTime").value);
	HighSpeedIRBall.Setting.IdleActionIndex=parseInt(document.getElementById("xzdzSelect").value,10);
	HighSpeedIRBall.Setting.IdleSec=parseInt(document.getElementById("freeTime").value,10);
	document.getElementById("freeActionClose").click();
}

function alarmActionSubmit(){//设置报警动作:设备通道号,报警类型(固定为0),动作索引号,持续秒数(3~240)
	ptzIpc.PtzSetAlarm(selectChnNum, 0, document.getElementById("bjdzSelect").value, document.getElementById("alarmTime").value);
	HighSpeedIRBall.Alarm.ActionIndex=parseInt(document.getElementById("bjdzSelect").value,10);
	HighSpeedIRBall.Alarm.DurationSec=parseInt(document.getElementById("alarmTime").value,10);
	document.getElementById("alarmActionClose").click();
}

function timeActionSubmit(){//定时设置:设备通道号,定时索引号(0~7),动作索引号,定时开始小时值,定时开始分钟值,定时结束小时值,定时结束分钟值
	for(var i=1;i<=8;i++){
		if(!validateTime(trim(document.getElementById("bh_"+i).value), trim(document.getElementById("bm_"+i).value),
					trim(document.getElementById("eh_"+i).value), trim(document.getElementById("em_"+i).value), i)){
			return;
		}
	}
	for(var i=0;i<8;i++){
		ptzIpc.PtzSetOntime(selectChnNum, i, document.getElementById("actionSelect"+(i+1)).value, 
			document.getElementById("bh_"+(i+1)).value, document.getElementById("bm_"+(i+1)).value, document.getElementById("eh_"+(i+1)).value, document.getElementById("em_"+(i+1)).value);
		HighSpeedIRBall.Ontime[i].BeginHour=parseInt(document.getElementById("bh_"+(i+1)).value,10);
		HighSpeedIRBall.Ontime[i].BeginMin=parseInt(document.getElementById("bm_"+(i+1)).value,10);
		HighSpeedIRBall.Ontime[i].EndHour=parseInt(document.getElementById("eh_"+(i+1)).value,10);
		HighSpeedIRBall.Ontime[i].EndMin=parseInt(document.getElementById("em_"+(i+1)).value,10);
		HighSpeedIRBall.Ontime[i].ActionIndex=parseInt(document.getElementById("actionSelect"+(i+1)).value,10);
	}
	document.getElementById("timeActionClose").click();
}

//验证定时时间的有效性
function validateTime(bh, bm, eh, em, order){
	//alert("*"+bh+" "+bm+" "+eh+" "+em+"*");
	if(bh=="" && bm=="" && eh=="" && em==""){//都为空则不验证
		document.getElementById("bh_"+order).value="0";
		document.getElementById("bm_"+order).value="0";
		document.getElementById("eh_"+order).value="0";
		document.getElementById("em_"+order).value="0";
	}else{
		if(bh==""){ bh="0";}
		if(bm==""){ bm="0";}
		if(eh==""){ eh="0";}
		if(em==""){ em="0";}
		if(!isTimeNum(bh) || !isTimeNum(bm) || !isTimeNum(eh) || !isTimeNum(em)){
			alert(order+" - "+gsq_msg1);return false;
		}
		bh=parseInt(bh,10);
		bm=parseInt(bm,10);
		eh=parseInt(eh,10);
		em=parseInt(em,10);
		if(bh>24 || eh>24){
			alert(order+" - "+gsq_msg2);return false;
		}
		if(bm>59 || em>59){
			alert(order+" - "+gsq_msg3);return false;
		}
		if(bh>eh){
			alert(order+" - "+date_msg1);return false;
		}
		if(bh==eh && bm>em){
			alert(order+" - "+date_msg1);return false;
		}
		document.getElementById("bh_"+order).value=bh;
		document.getElementById("bm_"+order).value=bm;
		document.getElementById("eh_"+order).value=eh;
		document.getElementById("em_"+order).value=em;
	}
	return true;
}

function closePage(){
	setTimeout(closeFunction ,3000);
}

function closeFunction(){
	window.opener=null;
	window.open("",'_self',"");
	window.close();
}

//设置checkbox
function gsqAutoChk(obj, type){
	if(obj.checked){
		ptzIpc.PtzCtrl(0, type, 1);
	}else{
		ptzIpc.PtzCtrl(0, type, 0);
	}
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////