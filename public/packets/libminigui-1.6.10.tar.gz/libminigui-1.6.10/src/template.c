/*
** $Id: template.c 7363 2007-08-16 05:11:52Z xgwang $
** 
** template.c: a template for source code of MiniGUI
** 
** Copyright (C) 2003 ~ 2007 Feynman Software.
**
** Current maintainer: <your name>
**
** Create date: 2003-xx-xx by <your name>
*/

#include "template.h"

