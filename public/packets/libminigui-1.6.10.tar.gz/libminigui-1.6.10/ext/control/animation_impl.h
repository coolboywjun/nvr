/*
** $Id: animation_impl.h 7367 2007-08-16 05:25:35Z xgwang $: 
**
** Copyright (C) 2004~2007 Feynman Software.
**
** Create date: 2004/7/14
*/


#ifndef __ANIMATION_IMPL_H_
#define __ANIMATION_IMPL_H_

#ifdef  __cplusplus
extern  "C" {
#endif

BOOL RegisterAnimationControl (void);
void AnimationControlCleanup (void);

#ifdef  __cplusplus
}
#endif

#endif // __ANIMATION_IMPL_H_

