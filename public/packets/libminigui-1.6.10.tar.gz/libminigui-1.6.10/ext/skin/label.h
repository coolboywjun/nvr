/*
** $Id: label.h 7372 2007-08-16 05:33:55Z xgwang $
**
** label.h: skin normal lable interfaces.
**
** Copyright (C) 2002 ~ 2007 Feynman Software, all rights reserved.
**
** Use of this source package is subject to specific license terms
** from Beijing Feynman Software Technology Co., Ltd.
**
** URL: http://www.minigui.com
*/

#ifndef _MGUI_LABEL_H
#define _MGUI_LABEL_H

#ifdef _EXT_SKIN

extern skin_item_ops_t *NRMLABEL_OPS;

#endif /* _EXT_SKIN */

#endif /* _MGUI_LABEL_H */
