/*
** $Id: template.h 7366 2007-08-16 05:23:35Z xgwang $
**
** XXX.h: <Description for this file>
**
** Copyright (C) 2003-2007 Feynman Software.
**
*/

#ifndef GUI_XXX_H
    #define GUI_XXX_H

#ifdef __cplusplus
extern "C" {
#endif  /* __cplusplus */


#ifdef __cplusplus
}
#endif  /* __cplusplus */

#endif /* GUI_XXX_H */

