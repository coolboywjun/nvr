void glib_plugin_test(void) { }
