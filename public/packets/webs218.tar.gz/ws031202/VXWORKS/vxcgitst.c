#include	<envLib.h>
#include	<stdio.h>

void vxcgitst_cgientry(int argc, char **argv)
{
printf("\r\n");
envShow(NULL);
}
