For current WebServer startup instructions and other information 
specific to Release 2.1, please refer to the release.htm file
(Release Notes). 
